#!/bin/bash
# sleep 1s
gnome-terminal -- bash -c "source devel/setup.bash; pm2 start /usr/local/web/code/njcontrol/server/index.js; rosrun  location  com2ros"

sleep 1s
gnome-terminal -- bash -c "source devel/setup.bash;roslaunch hmi  start.launch ;exec bash"
sleep 1s
gnome-terminal -- bash -c "source devel/setup.bash;rosrun control  lat_node ;exec bash"
sleep 1s 
# gnome-terminal -- bash -c "source devel/setup.bash;rosrun control  lon_node ;exec bash"
# sleep 1s 
# gnome-terminal -- bash -c "source devel/setup.bash;rosrun control  tool_node ;exec bash"

