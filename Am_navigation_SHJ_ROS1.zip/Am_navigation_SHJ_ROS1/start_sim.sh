#!/bin/bash
sleep 1s
#gnome-terminal -- bash -c "source devel/setup.bash;roslaunch hmi  start_sim.launch ;exec bash"
source devel/setup.bash
roslaunch hmi  start_sim.launch

