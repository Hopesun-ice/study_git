#ifndef _FARMRTK_H
#define _FARMRTK_H

#include "std_msgs/String.h"
#include "common/Pathpoint.h"
#include "common/Path.h"
#include "common/Pose.h"
#include <sstream>
#include <fstream>
#include <std_msgs/Bool.h>
#include <ros/package.h>

class TrajectoryPoint{   // 读取的路径点格式
    public:
      double x;
      double y;
      double time;
      double curvature;
      int gear;
      int toos;
      float v;
      float heading;
};

class RTKPlanner{
  public:
    static RTKPlanner* p_planner;
    static double carx;
    static double cary;
    std_msgs::Bool car_stop_flag;
    std::vector<TrajectoryPoint> complete_rtk_trajectory ; // 完整路径的数组

    RTKPlanner():count(0), 
                 start(0),
                 end(0),
                 closestpoint(0),
                 localization_received(false),
                 replan(false),
                 dist_first(true),
                 last_path_flag(false),
                 complete_path(false){car_stop_flag.data = false;}; //true就是发布整条路径   false就是发布 部分路径
                
                 
    ~RTKPlanner(){};

    static void localization_callback(const common::Pose& msg);

    std::vector<std::string> Split(const std::string& str,
                                const std::string& delims);  // 读取csv文件

    void CalPath(common::Path& plan);   // 根据位置信息和时间信息计算坐标

    void ReadTrajectoryFile(const std::string& filename);  // 读取文件

    void restart();
    
    int closest_dist();

    int closest_time();
  private:
    int count;
    int start;
    int end;
    int closestpoint;
    double starttime;
    bool localization_received ;
    const int SEARCH_INTERVAL = 1000;   // 搜索范围
    const int PUBLISH_NUMS = 1000;      // 发布路径长度
    bool replan;
    bool dist_first;
    bool complete_path;
    bool last_path_flag;
    
    
};


#endif