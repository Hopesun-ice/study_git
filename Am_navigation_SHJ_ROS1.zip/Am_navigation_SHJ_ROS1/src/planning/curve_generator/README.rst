======
Farm Path Library
======


Installation
======

Install from source 

.. code-block:: console

    $ sudo python setup.py install


Demo
======

.. code-block:: console

	$ python demos/wp_genetor.py

	$ python demos/runway_gene.py

	$ python demos/circle_gene.py

	$ python demos/draw_line.py


