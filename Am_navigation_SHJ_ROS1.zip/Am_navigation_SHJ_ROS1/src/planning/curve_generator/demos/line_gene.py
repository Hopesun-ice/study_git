#!/usr/bin/env python
#coding=utf-8

import numpy as np
from tools import curve_painter

#  农田路径固定参数
rho = 4         # turning radius
length = 90
cols = 0
width = 2 * rho
wp = []
laps = 1         

# 根据任务调整的参数,固定速度
reverse = 0
speed = 0.5
time_step = 0.01
step_size = time_step*speed
start = [692977.9457303582 ,4048374.9784814199  , 0,-1.41]  # [x, y, z, theta] 
ep = [[ 0, 0, 0],
     [ length, 0, 0]]


if __name__ == "__main__":
    path_planner = curve_painter(rho = rho,      # 转弯半径
                                 length = length,  # 直线段路径长度
                                 cols = cols,     # 直道的数量
                                 width = width,    # 直道间的宽度
                                 reverse = reverse,  # 0 不允许倒车（鱼泡形），1 允许倒车（鱼尾形）
                                 speed = speed,  # 行驶速度
                                 time_step = time_step,  # 时间间隔
                                 start = start, # [x, y, z, theta] 起点，决定路径的朝向和位置
                                 wp = wp,
                                 ep = ep,
                                 route = "/home/nvidia/Am_navigation_TLJ_ROS1/src/planning/data/line.csv",
                                 fig_dir = "fig/runway.png",
                                 laps = laps)
    path_planner.gene_path()

