#!/usr/bin/env python
#coding=utf-8

from tools import curve_painter

if __name__ == "__main__":
    length = 30
    path_planner = curve_painter(rho = 6,      # 转弯半径
                                 length = length,  # 直线段路径长度
                                 cols = 3,     # 直道的数量
                                 width = 3,    # 直道间的宽度

                                 speed = 0.5,  #用于数据采样
                                 speed_low = 0.5,  # 曲线行驶速度
                                 speed_high = 1,  # 直线行驶速度
                                 speed_change_dis = 3,  # 速度变化缓冲距离
                                 speed_low_dis = 3,  # 速度直线低速缓冲距离

                                 time_step = 0.01,  # 时间间隔
                                 dis = 2,  #    693170.7646928440 4048953.2658
                                 start = [  693163.8191380585, 4048827.1901692678 ,
                                                  28.4326358097, 
                                          -3.09], # [x, y, z, theta] 起点，决定路径的朝向和位置
                                 wp = [],
                                 ep = [[ 0, 0, 0],
                                      [length, 0, 0]])
    path_planner.gene_path()

