#coding=utf-8

import numpy as np
from tools import curve_painter

#  农田路径固定参数
rho = 8         # turning radius
length = 20
cols = 0
width = 2 * rho
wp = []
laps = 1         

# 根据任务调整的参数,固定速度
reverse = 0
speed = 0.8
time_step = 0.01
step_size = time_step*speed
start = [692989.9285989905 ,4048350.5015020221 ,	28.2750274258, -1.41]  # [x, y, z, theta]
ep = [[ 0, 0, 0],
     [ 0, 0, -0.001]]


if __name__ == "__main__":
    path_planner = curve_painter(rho = rho,      # 转弯半径
                                 length = length,  # 直线段路径长度
                                 cols = cols,     # 直道的数量
                                 width = width,    # 直道间的宽度
                                 reverse = reverse,  # 0 不允许倒车（鱼泡形），1 允许倒车（鱼尾形）
                                 speed = speed,  # 行驶速度
                                 time_step = time_step,  # 时间间隔
                                 start = start, # [x, y, z, theta] 起点，决定路径的朝向和位置
                                 wp = wp,
                                 ep = ep,
                                 route = "data/circle.csv",
                                 fig_dir = "fig/circle.png",
                                 laps = laps)
    path_planner.gene_path()

