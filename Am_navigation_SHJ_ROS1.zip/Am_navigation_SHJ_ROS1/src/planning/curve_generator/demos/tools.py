#coding=utf-8

import curve
import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import math
import dubins
import csv
import numpy as np
import numpy.linalg as LA

class curve_painter(object):
    
    def __init__(self, 
              rho = 1, 
              length = 10, 
              cols = 5, 
              width = 3, 
              left_right = 0, 
              reverse = 1, 
              speed = 0.5,
              speed_low = 0.5, 
              speed_high = 1, 
              speed_change_dis = 1,
              speed_low_dis = 1,
              time_step = 0.01, 
              start = [0, 0, 0, 0], 
              dis = 2,
              wp=[], 
              ep=[],
              route = "/home/nvidia/Am_navigation_TLJ_ROS1/src/planning/data/wp.csv",
              fig_dir = "fig/wp.png",
              laps = 0):
        #  农田路径固定参数
        self.rho = rho          # 转弯半径
        self.length = length    # 直线段路径长度
        self.cols = cols        # 直道的数量
        self.width = width      # 直道间的宽度
        self.left_right = 1 # 朝左运行还是朝右运行， 0:left  1:right
        self.dis = dis

        # 根据任务调整的参数,固定速度
        self.reverse = reverse     # 0 不允许倒车（鱼泡形），1 允许倒车（鱼尾形）
        self.speed = speed         
        self.speed_low = speed_low         
        self.speed_high = speed_high         
        self.speed_change_dis = speed_change_dis        
        self.speed_low_dis = speed_low_dis         
        self.time_step = time_step # 时间间隔
        self.step_size = time_step * speed # 步长
        self.start =  start # [x, y, z, theta] 起点，决定路径的朝向和位置
        self.acc = 0       # 加速度
        self.s = 0         # 总路径长度
        self.T = 0         # 时间
        self.throttle = 0  # 油门
        self.laps = laps   # 转圈标志位
        # self.tools = 0 # jiju

        # 路径点存储数组
        self.wp = wp
        self.ep = ep
        self.route = route 
        self.fig_dir = fig_dir
 
   

        # 文件头
        self.header = ['x','y', 'z', 'speed', 'acceleration', 'curvature', 'curvature_change_rate', 'time', 'theta', 'gear', 's', 'throttle', 'brake', 'steering','tools']


    #逆时针旋转
    def Nrotate(self, angle, valuex, valuey, pointx, pointy):
        valuex = np.array(valuex)
        valuey = np.array(valuey)
        nRotatex = (valuex - pointx) * math.cos(angle) - (valuey - pointy) * math.sin(angle) + pointx
        nRotatey = (valuex - pointx) * math.sin(angle) + (valuey - pointy) * math.cos(angle) + pointy
        return round(nRotatex, 2), round(nRotatey, 2)

    def get_point(self, center, radius, orin):
        x = center[0] + radius * np.cos(orin)
        y = center[1] + radius * np.sin(orin)
        return (x,y)


    def plot_car(self, q):
        a = self.get_point(q[:-1], self.step_size*200, q[2])
        b = self.get_point(q[:-1], self.step_size/2*200, q[2]+150./180.*np.pi)
        c = self.get_point(q[:-1], self.step_size/2*200, q[2]-150./180.*np.pi)
        tri = np.array([a,b,c,a])
        plt.plot(tri[:,0], tri[:,1], 'g-')

    def PJcurvature(x,y):
        """
        input  : the coordinate of the three point
        output : the curvature and norm direction
        refer to https://github.com/Pjer-zhang/PJCurvature for detail
        """
        t_a = LA.norm([x[1]-x[0],y[1]-y[0]])
        t_b = LA.norm([x[2]-x[1],y[2]-y[1]])
        
        M = np.array([
            [1, -t_a, t_a**2],
            [1, 0,    0     ],
            [1,  t_b, t_b**2]
        ])

        a = np.matmul(LA.inv(M),x)
        b = np.matmul(LA.inv(M),y)

        kappa = 2*(a[2]*b[1]-b[2]*a[1])/(a[1]**2.+b[1]**2.)**(1.5)
        return kappa
    
    # 将路径点可视化，并且生成路径数据
    def plot_path(self, q0, q1):
        if self.reverse == 0:
            qs = curve.dubins_path_sample(q0, q1, self.rho, self.step_size)
            print("q0:",q0,"  q1:",q1,"self.step_size:",self.step_size)
            print("row:",len(qs)," col:",len(qs[0]))
            print(qs[0])
            print(qs[1])
            print(qs[2])
            print(qs[5])
        else:
            qs = curve.path_sample(q0, q1, self.rho, self.step_size, self.left_right)
        xs = []     # x坐标
        ys = []     # y坐标
        zs = []     # z坐标
        ss = []     # 速度
        accs = []   # 加速度
        cs = []     # 曲率
        crs = []    # 曲率变化率
        Ts = []     # 时间
        ts = []     # 转角
        gs = []     # 档位,1前进，2后退
        ls = []     # 路径长度
        ths = []    # 油门
        brs = []    # 刹车
        sts = []    # 转向
        tools = []  # 机具
        for q in qs:
            sqx, sqy = self.Nrotate(self.start[3], q[0], q[1], 0, 0)  # 旋转坐标
            #print(sqx)
            if (sqx <= 0 and sqx >= -self.length):
                
                tools.append(1)
            else:
                tools.append(0)

            xs.append(sqx + self.start[0])
            ys.append(sqy + self.start[1])
            #xs.append(sqx)
            #ys.append(sqy)
            zs.append(self.start[2])

            if (sqx <= (0-self.speed_low_dis-self.speed_change_dis) and sqx >= (-self.length + self.speed_low_dis + self.speed_change_dis)):
                ss.append(self.speed_high)
                print(self.speed_high)
            elif (sqx > (0-self.speed_low_dis) or sqx < (-self.length + self.speed_low_dis)):
                ss.append(self.speed_low)
                print(self.speed_low)
            elif (sqx <= (0-self.speed_low_dis) and sqx >= (0-self.speed_low_dis - self.speed_change_dis)):               
                 ss.append(self.speed_low + ((self.speed_high -self.speed_low)/self.speed_change_dis)* ((0-self.speed_low_dis)-sqx)) 
            elif (sqx >= (-self.length + self.speed_low_dis) and sqx <= (-self.length + self.speed_low_dis + self.speed_change_dis)):
                 ss.append(self.speed_low + ((self.speed_high -self.speed_low)/self.speed_change_dis)* (sqx -(-self.length + self.speed_low_dis))) 

            accs.append(0)
            cs.append(q[4])   # 需要规划算法生成
            crs.append((q[-1]-cs[-2])/self.time_step if len(cs) > 1 else 0)
            self.T = self.T + self.time_step
            Ts.append(self.T)
            ts.append(q[2] + self.start[3])   # 更新朝向
            gs.append(q[3])            # 需要规划算法生成
            self.s = self.s + self.step_size
            ls.append(self.s)
            ths.append(0.0)            # 需要标定数据
            brs.append(0.0) 
            sts.append(0.0)
          
            #print(q)
        plt.plot(xs, ys, 'b-')
        # plt.plot(xs, ys, 'r.')

        for i in range(len(xs)):
            self.wp.append([xs[i], ys[i], zs[i], ss[i], accs[i], cs[i], crs[i], Ts[i], ts[i], gs[i], ls[i], ths[i], brs[i], sts[i],tools[i]])    
        
        self.plot_car([xs[0], ys[0], ts[0]])
        self.plot_car([xs[-1], ys[-1], ts[-1]])

    def gene_path(self):
        # 处理路径端点
        print("self.laps:",self.laps)
        print("self.ep:",self.ep)
        if (self.laps == 0):
            self.gene_ep()
            for i in range(1, len(self.ep)):
                self.plot_path(self.ep[i-1], self.ep[i])
        else:
            for l in range(self.laps):
                for i in range(1, len(self.ep)):
                    self.plot_path(self.ep[i-1], self.ep[i])  # 根据端点生成路径
        print("Successful generate the path!")

        # 输出数据
        t = open(self.route, mode='w')
        writer = csv.writer(t)
        writer.writerow(self.header)
        for p in self.wp:
            writer.writerow(p)
        print("The path data was saved as %s" % self.route)

        # 保存路径图片
        plt.axis('equal')   # 将路径点进行显示
        plt.savefig(self.fig_dir)
        print("The path picture was saved as %s" % self.fig_dir)
        plt.show()

    def gene_ep(self):
       # print("self.cols: ",self.cols)
        if self.reverse == 0 or 2 * self.rho <= self.width: 
	    for i in range(1, self.cols):
	        if (i % 2) == 0:    # 向前走，方向和起点相同
	            self.ep.append([self.ep[-1][0], self.ep[-1][1] + (0.5 - self.left_right)*2*self.width, 0])
	            self.ep.append([self.ep[-1][0] + self.length, self.ep[-1][1] , 0])
	        else:               # 向后走，方向和起点不同
	            self.ep.append([self.ep[-1][0] , self.ep[-1][1] + (0.5 - self.left_right)*2*self.width, -np.pi])
	            self.ep.append([self.ep[-1][0] - self.length, self.ep[-1][1], -np.pi])
        elif self.reverse == 1 and 2 * self.rho > self.width: 
            for i in range(1, self.cols):
	        #if (i % 2) == 0:    # 向前走，方向和起点相同 2 4
                #    self.ep.append([self.ep[-1][0] - self.rho, self.ep[-1][1] + self.rho, 0.5 * np.pi])
		#    self.ep.append([self.ep[-1][0] , self.ep[-1][1] - 2 * self.rho +  self.width , 0.5 *np.pi])
                #    #print('111',self.ep)
		#    self.ep.append([self.ep[-1][0] + self.rho  , self.ep[-1][1] + self.rho, 0])                
		#    self.ep.append([self.ep[-1][0] + self.length, self.ep[-1][1] , 0])
                #    #print('222',self.ep)
                #else:               # 向后走，方向和起点不同 1 3 5
		#    self.ep.append([self.ep[-1][0] + self.rho, self.ep[-1][1] + self.rho, 0.5*np.pi])
		#    self.ep.append([self.ep[-1][0] , self.ep[-1][1] - 2* self.rho + self.width , 0.5*np.pi])
		#
		#    self.ep.append([self.ep[-1][0] - self.rho  , self.ep[-1][1] + self.rho, -np.pi])
		#    self.ep.append([self.ep[-1][0] - self.length, self.ep[-1][1], -np.pi])



	        if (i % 2) == 0:    # 向前走，方向和起点相同 2 4
                    self.ep.append([self.ep[-1][0] - self.rho, self.ep[-1][1] + (0.5 - self.left_right)*2 * self.rho, (0.5 - self.left_right)*2 * 0.5 * np.pi])
                    self.ep.append([self.ep[-1][0], self.ep[-1][1] + (0.5 - self.left_right)* 2 * self.dis, (0.5 - self.left_right)*2 * 0.5 * np.pi])
                    self.ep.append([self.ep[-1][0] , self.ep[-1][1] - 2 * self.rho* (0.5 - self.left_right)*2 +  self.width*(0.5 - self.left_right)*2 -2 * (0.5 - self.left_right)* 2 * self.dis , (0.5 - self.left_right)*2 * 0.5 *np.pi])                  
		    self.ep.append([self.ep[-1][0] , self.ep[-1][1] + (0.5 - self.left_right)* 2 * self.dis , (0.5 - self.left_right)*2 * 0.5 *np.pi])
                    
                    #print('111',self.ep)
		    self.ep.append([self.ep[-1][0] + self.rho  , self.ep[-1][1] + self.rho * (0.5 - self.left_right)*2 , 0])                
		    self.ep.append([self.ep[-1][0] + self.length, self.ep[-1][1] , 0])
                    #print('222',self.ep)
                else:               # 向后走，方向和起点不同 1 3 5
		    self.ep.append([self.ep[-1][0] + self.rho, self.ep[-1][1] + (0.5 - self.left_right) * 2 * self.rho , (0.5 - self.left_right) * 2 * 0.5 * np.pi])
                    self.ep.append([self.ep[-1][0], self.ep[-1][1] + (0.5 - self.left_right)*2 *self.dis, (0.5 - self.left_right)*2 *0.5*np.pi])

		    self.ep.append([self.ep[-1][0], self.ep[-1][1] - 2 * (0.5 - self.left_right) * 2 * self.rho + (0.5 - self.left_right) * 2 * self.width - 2 * (0.5 - self.left_right) * 2 * self.dis, (0.5 - self.left_right) * 2 * 0.5*np.pi])

                    self.ep.append([self.ep[-1][0], self.ep[-1][1] + (0.5 - self.left_right) * 2 * self.dis , (0.5 - self.left_right)*2 * 0.5*np.pi])
		
		    self.ep.append([self.ep[-1][0] - self.rho  , self.ep[-1][1] + (0.5 - self.left_right)*2 *self.rho, -(0.5 - self.left_right)*2 *np.pi])
		    self.ep.append([self.ep[-1][0] - self.length, self.ep[-1][1], -(0.5 - self.left_right)*2 *np.pi])



        print(self.ep)


