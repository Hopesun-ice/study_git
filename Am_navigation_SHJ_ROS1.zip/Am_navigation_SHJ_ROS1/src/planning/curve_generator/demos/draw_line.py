import matplotlib
import matplotlib.pyplot as plt
import numpy as np

if __name__ == "__main__":
    wp = np.loadtxt("data/wp.txt")
    fig_dir = "fig/wp.png"
    print(wp)
    x = [p[0] for p in wp]
    y = [p[1] for p in wp]
    plt.plot(x, y, 'b-')
    plt.plot(x, y, 'r.')
    plt.axis('equal')
    plt.savefig(fig_dir)
    print("The path picture was saved as %s" % fig_dir)
    plt.show()

