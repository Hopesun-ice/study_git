#ifndef SPACES_REEDS_SHEPP_STATE_SPACE_
#define SPACES_REEDS_SHEPP_STATE_SPACE_

#include <boost/math/constants/constants.hpp>
#include <cassert>

enum DubinsPathType
{
    LSL = 0,
    LSR = 1,
    RSL = 2,
    RSR = 3,
    RLR = 4,
    LRL = 5
} ;
class DubinsPath{
    public:
        /* the initial configuration */
        double qi[3];        
        /* the lengths of the three segments */
        double param[3];     
        /* model forward velocity / model angular velocity */
        double rho;          
        /* the path type described */
        DubinsPathType type; 
};

#define EDUBOK        (0)   /* No error */
#define EDUBCOCONFIGS (1)   /* Colocated configurations */
#define EDUBPARAM     (2)   /* Path parameterisitation error */
#define EDUBBADRHO    (3)   /* the rho value is invalid */
#define EDUBNOPATH    (4)   /* no connection between configurations with this word */

typedef int (*DubinsPathSamplingCallback)(double q[5], void* user_data);

int dubins_shortest_path(DubinsPath* path, double q0[3], double q1[3], double rho);


double dubins_path_length(DubinsPath* path);


double dubins_segment_length(DubinsPath* path, int i);

double dubins_segment_length_normalized( DubinsPath* path, int i );

DubinsPathType dubins_path_type(DubinsPath* path);

int dubins_path_sample(DubinsPath* path, double t, double q[5]);

int dubins_path_sample_many(DubinsPath* path, 
                            double stepSize, 
                            DubinsPathSamplingCallback cb, 
                            void* user_data);

int dubins_extract_subpath(DubinsPath* path, double t, DubinsPath* newpath);



typedef int (*CurvePathSamplingCallback)(double q[5], void* user_data);
typedef int (*CurvePathTypeCallback)(int t, void* user_data);

class CurveStateSpace
{
public:

    /** \brief The Reeds-Shepp path segment types */
    enum CurvePathSegmentType { RS_NOP=0, RS_LEFT=1, RS_STRAIGHT=2, RS_RIGHT=3 };

    /** \brief Reeds-Shepp path types */
    static const CurvePathSegmentType CurvePathType[18][5];
    
    /** \brief Complete description of a Curve path */
    class CurvePath
    {
    public:
        CurvePath(const CurvePathSegmentType* type=CurvePathType[0],
            double t=std::numeric_limits<double>::max(), double u=0., double v=0.,
            double w=0., double x=0.);
        
        double length() const { return totalLength_; }

        /** Path segment types */
        const CurvePathSegmentType* type_;
        /** Path segment lengths */
        double length_[5];
        /** Total length */
        double totalLength_;
    };

    CurveStateSpace(double turningRadius, int left_right) : rho_(turningRadius), lr_(left_right) {}

    double distance(double q0[3], double q1[3]);

    void type(double q0[3], double q1[3], CurvePathTypeCallback cb, void* user_data);

    void sample(double q0[3], double q1[3], double step_size, CurvePathSamplingCallback cb, void* user_data);

    /** \brief Return the shortest Reeds-Shepp path from SE(2) state state1 to SE(2) state state2 */
    CurvePath Curve(double q0[3], double q1[3]);

protected:
    void interpolate(double q0[3], CurvePath &path, double seg, double s[5]);

    /** \brief Turning radius */
    double rho_;

    int lr_;
};

#endif
