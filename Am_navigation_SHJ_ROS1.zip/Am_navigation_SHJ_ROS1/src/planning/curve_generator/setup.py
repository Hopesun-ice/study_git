from distutils.core import setup, Extension
import os
try:
	from Cython.Distutils import build_ext
except:
	use_cython = False
else:
	use_cython = True

cmdclass = {}
ext_modules = []

sources = []
if use_cython:
	sources = ["curve/src/curve.cpp", "curve/curve.pyx"]
	cmdclass.update({ 'build_ext' : build_ext })
else:
	sources = ["curve/src/curve.cpp", "curve/curve.cpp"]
	
ext_modules = [
    Extension("curve",
        sources = sources,
        language="c++",
        include_dirs = ["curve/include"])
    ]

def read(filename):
    path = os.path.join(os.path.dirname(__file__), filename)
    contents = open(path).read()
    return contents

setup( 
	name = "curve",
    version      = "0.1.1",
    description  = "Code to calculate analytic Smart farm path",
    long_description = read('README.rst'),
    author       = "Feng Zhen",
    author_email = "fengzhen202014764@163.com",
    license      = "BSD",
    cmdclass     = cmdclass,
    ext_modules  = ext_modules,
	)
