#include "planning/planning.h"
#include "ros/ros.h"

int max(int a , int b){
  if (a < b){return b;} 
  else {return a;}
}

int min(int a, int b){
  if (a > b){return b;}
  else {return a;}
}
// 功能型函数，不用在意
std::vector<std::string> RTKPlanner::Split(const std::string& str,
                               const std::string& delims) {
  std::vector<std::string> tokens;
  std::string::size_type last_index = str.find_first_not_of(delims, 0);
  std::string::size_type index = str.find_first_of(delims, last_index);

  while (std::string::npos != index || std::string::npos != last_index) {
    tokens.push_back(str.substr(last_index, index - last_index));
    last_index = str.find_first_not_of(delims, index);
    index = str.find_first_of(delims, last_index);
  }
  return tokens;
}
// 读取文件，功能型函数，不用在意
void RTKPlanner::ReadTrajectoryFile(const std::string& filename) {
  std::ifstream file_in(filename.c_str());

  if (!file_in.is_open()) {
    ROS_ERROR("RTKPlanner cannot open trajectory file: [%s]", filename.c_str());
    return;
  }
 
  std::string line;
  // 跳过表头
  getline(file_in, line);
  while (true) {
    getline(file_in, line);
    if (line == "") {
      break;
    }
    std::vector<std::string>  tokens = Split(line, ",");
    if (tokens.size() < 11) {
      ROS_ERROR("RTKPlanner parse line failed; the data dimension does not match.");
      ROS_ERROR("[%s]", line.c_str());
      continue;
    }
    TrajectoryPoint point;
    point.x = std::atof(tokens[0].c_str());
    point.y = std::atof(tokens[1].c_str());
    point.time = std::atof(tokens[7].c_str());
    point.curvature = std::atof(tokens[5].c_str());
    point.gear = std::atof(tokens[9].c_str());
    point.heading =  std::atof(tokens[8].c_str());
    point.toos = std::atof(tokens[14].c_str()); 
    point.v =  std::atof(tokens[3].c_str()); 
    complete_rtk_trajectory.push_back(point);
  
    car_stop_flag.data = false;
  }
  file_in.close();
}

// 获取定位的信息 只要x,y坐标信息
void RTKPlanner::localization_callback(const common::Pose& msg){
  carx = msg.x;
  cary = msg.y;
  static int printf_num = 0;
  printf_num++;
  if(printf_num>20){
      printf_num = 0;
  }
  p_planner->localization_received = true;
}

// 重新规划  在程序开始的时候执行了一次 目前 重规划的函数 好像就是重新确定确定一下起点和终点
void RTKPlanner::restart(){
  //ROS_INFO("Before replan self.start=%d, self.closestpoint=%d",start, closestpoint);
  //ROS_INFO("Replan!");

  closestpoint = closest_dist();  // 获取最近点
  start = max(closestpoint - 1, 0);   // 限制下范围
  starttime = ros::Time::now().toSec();   
  end = min(start + PUBLISH_NUMS, complete_rtk_trajectory.size()-1); // 限制下范围
 // ROS_INFO("replan_start: %d, replan_end: %d, at time: %f", start, end, starttime);
 // ROS_INFO("finish replan at time %f, self.closestpoint=%d" ,starttime, closestpoint);
}

// 找最近的点
int RTKPlanner::closest_dist(){
  double shortest_dist_sqr = DBL_MAX;//double的最大值
  //寻找最近点的过程就是从start这个点的前后 SEARCH_INTERVAL/2个点里进行寻找
  int search_start = max((start),0);
  int search_end = min(start + SEARCH_INTERVAL/2, complete_rtk_trajectory.size());
  //假设最近点就是开始点 search_start
  int closest_dist_point = search_start;
  //static bool  flag_jiandain = false;
    //std::cout<<"search_start: "<<search_start<<"    search_end:  "<<search_end<<std::endl;
  for(int i = search_start;i<search_end;i++){
    if( complete_rtk_trajectory[i].gear !=complete_rtk_trajectory[i+1].gear  ){
      if(i - search_start <10){ search_end = min(start + SEARCH_INTERVAL/2, complete_rtk_trajectory.size());break;}
      else { search_end = i;break;}
     // flag_jiandain = true;
    }
  }
 // std::cout<<"search_start: "<<search_start<<"    search_end:  "<<search_end<<std::endl;
  //在搜索范围内 循环一次 寻找最近点 
  for (int i = search_start; i < search_end; i++){
    double dist_sqr = (carx - complete_rtk_trajectory[i].x)*(carx - complete_rtk_trajectory[i].x)
                    +(cary - complete_rtk_trajectory[i].y)*(cary - complete_rtk_trajectory[i].y);
    //如果找到的点比之前的最近点更近，就更新最近点  不过感觉这里用小于号更好
    if (dist_sqr <= shortest_dist_sqr){
      closest_dist_point = i;
      shortest_dist_sqr = dist_sqr;
    }  
  }
  return closest_dist_point;
}

// 找时间上最近的点
int RTKPlanner::closest_time(){
  //开始点 start   开始时间上最近的点 从开始点开始寻找
  int closest_time_point = start;
  //time_elapsed：流逝的时间
  double time_elapsed = ros::Time::now().toSec() - starttime;
  double time_diff = complete_rtk_trajectory[closest_time_point].time - complete_rtk_trajectory[closestpoint].time;
  while ((time_diff < time_elapsed) && (closest_time_point < complete_rtk_trajectory.size()-1)){
    closest_time_point++;
    time_diff = complete_rtk_trajectory[closest_time_point].time - 
                complete_rtk_trajectory[closestpoint].time;
  }  
  return closest_time_point;
}

// 计算路径  这里是调用的主要函数
void RTKPlanner::CalPath(common::Path& plan)
{
  common::Pathpoint p;   // 路径点 包括 x ，y ，gear ，k，time
  std::vector<common::Pathpoint> data; // 需要发布的路径的数据
  //complete_rtk_trajectory是存的离线规划的所有路径点
  if (complete_rtk_trajectory.empty() || complete_rtk_trajectory.size() < 2) {
   // ROS_ERROR("RTKReplayPlanner doesn't have a recorded trajectory or "
   //           "the recorded trajectory doesn't have enough valid trajectory "
   //           "points.");
    return;  // 路径点太少，报错
  }
  
  /*这段代码是不是 存在一定的问题   当发布的路径为整条的跑道路径的时候  起点和终点是重合的  这样直接就判定到终点了*/
  //这个地方  确实有问题
  uint32_t len = complete_rtk_trajectory.size() - 1;
  double xgdiff_sqr = sqrt((complete_rtk_trajectory[len].x - carx)*(complete_rtk_trajectory[len].x - carx));
  double ygdiff_sqr = sqrt((complete_rtk_trajectory[len].y - cary)*(complete_rtk_trajectory[len].y - cary));
  //if (xgdiff_sqr + ygdiff_sqr < 0.2  && last_path_flag){  
  if (xgdiff_sqr + ygdiff_sqr < 0.2){  
    //为什么还要有这个last_path_flag标志位呢 他都对离线路径点的最后一个点和当前的pose坐距离判断了
    // 噢 这个last_path_flag就是为了防止起点和终点重合 误把起点判断成终点
      car_stop_flag.data = true;
      
      ROS_WARN("finished planning because the car arrived the goal!");   // 到终点报个信
      return;
  }
  // //首先获取定位信息  判断是否有定位信息
  if (!localization_received) {      
      ROS_WARN("locaization not received yet when publish_planningmsg");
      return;
  }

  //暂时没搞清楚这个 std_msgs/Header的作用是什么
  plan.header.frame_id = "planning";
  plan.header.stamp = ros::Time::now(); // 一些时间方面的信息，无关紧要
  plan.header.seq = count++; 

 // ROS_INFO("publish_planningmsg: before adjust start: start = %d, end = %d", start, end);

  if (complete_path){      // 发布整条路径不用那么麻烦了
    start = 0;
    end = complete_rtk_trajectory.size() - 1;
  }
  //目前还不太清楚 重规划到底有什么作用 是什么意思
  else if ((count <= 1) || (replan)){    // 需要重新规划就重规划
 //   ROS_INFO("trigger replan: replan_=%d, count=%d" , replan, count );
    restart();
  }
  else{    // 复刻apollo5.5代码
    int time_point = closest_time();
    int dist_point = closest_dist();
    //ROS_INFO("closest_time_point: %d, closest_dist_point: %d", time_point, dist_point);
    
    if (dist_first){
      static int start_last = 0;
      start = dist_point;
      // if(start <start_last){start = start_last;}
   //    std::cout << "start: " << start << " start_last" << start_last << std::endl;
      start_last = start;
     
      }
    else {start = time_point;}
    end = min(start + PUBLISH_NUMS, complete_rtk_trajectory.size()-1);          
   

    double xdiff_sqr = (complete_rtk_trajectory[start].x - carx)
                  *(complete_rtk_trajectory[start].x - carx);
    double ydiff_sqr = (complete_rtk_trajectory[start].y - cary)
                  *(complete_rtk_trajectory[start].y - cary);
    if (sqrt(xdiff_sqr + ydiff_sqr) > 10.0){
      ROS_INFO("trigger replan: distance larger than 2.0");
      restart();
    }
  }
  if(start + PUBLISH_NUMS > complete_rtk_trajectory.size()-1 ){
    last_path_flag = true;
  }
  // 求解出一系列的轨迹点并发布。  common::PathPoint data
  ROS_INFO("trajectory start point: %d, end point: %d", start, end);
  
  for (int i = start; i <= end; i++){
    p.x = complete_rtk_trajectory[i].x;
    p.y = complete_rtk_trajectory[i].y;
    p.time = complete_rtk_trajectory[i].time;
    p.curvature = complete_rtk_trajectory[i].curvature;
    p.gear = complete_rtk_trajectory[i].gear;
    p.toos = complete_rtk_trajectory[i].toos;
    p.v =  complete_rtk_trajectory[i].v;
    p.heading = complete_rtk_trajectory[i].heading;
    data.push_back(p);
    plan.path = data;
     std::cout<<"plan.x: "<< p.x<< "  "<<"plan.y"<<p.y<<std::endl;
  }
}