#include"ros/ros.h"
#include <planning/planning.h>
#include <nav_msgs/Path.h>
#include <geometry_msgs/Quaternion.h>
#include <geometry_msgs/PoseStamped.h>
#include <visualization_msgs/Marker.h>
#include <ros/package.h>
#include<common/RoadOrFarmland.h>
double RTKPlanner::carx = 0;
double RTKPlanner::cary = 0;
RTKPlanner* RTKPlanner::p_planner = nullptr;
bool flag_farmland = false;
bool flag_farmland_End = false;
//  显示功能，没有实质内容
void compath2rviz(ros::Publisher& marker_pub, RTKPlanner& planner)
{
    // %Tag(MARKER_INIT)%
    visualization_msgs::Marker points, line_strip, line_list;
    points.header.frame_id = line_strip.header.frame_id = line_list.header.frame_id = "/map";
    points.header.stamp = line_strip.header.stamp = line_list.header.stamp = ros::Time::now();
    points.ns = line_strip.ns = line_list.ns = "points_and_lines";
    points.action = line_strip.action = line_list.action = visualization_msgs::Marker::ADD;
    points.pose.orientation.w = line_strip.pose.orientation.w = line_list.pose.orientation.w = 1.0;
    // %EndTag(MARKER_INIT)%

    // %Tag(ID)%
    points.id = 0;
    line_strip.id = 1;
    line_list.id = 2;
    // %EndTag(ID)%

    // %Tag(TYPE)%
    points.type = visualization_msgs::Marker::POINTS;
    line_strip.type = visualization_msgs::Marker::LINE_STRIP;
    line_list.type = visualization_msgs::Marker::LINE_LIST;
    // %EndTag(TYPE)%

    // %Tag(SCALE)%
    // POINTS markers use x and y scale for width/height respectively
    points.scale.x = 0.2;
    points.scale.y = 0.2;

    // LINE_STRIP/LINE_LIST markers use only the x component of scale, for the line width
    line_strip.scale.x = 0.1;
    line_list.scale.x = 0.1;
    // %EndTag(SCALE)%

    // %Tag(COLOR)%
    // Points are green
    points.color.g = 1.0f;
    points.color.a = 1.0;

    // Line strip is blue
    line_strip.color.b = 1.0;
    line_strip.color.a = 1.0;

    // Line list is red
    line_list.color.r = 1.0;
    line_list.color.a = 1.0;
    // %EndTag(COLOR)%

    // %Tag(HELIX)%
    // Create the vertices for the points and lines
    for (uint32_t i = 0; i < planner.complete_rtk_trajectory.size(); i += 1)
    {
      geometry_msgs::Point p;
      p.x = planner.complete_rtk_trajectory[i].x;
      p.y = planner.complete_rtk_trajectory[i].y;
      p.z = 0;

      points.points.push_back(p);
      line_strip.points.push_back(p);

      // The line list needs two points for each line
      line_list.points.push_back(p);
      p.z += 1.0;
      line_list.points.push_back(p);
    }
// %EndTag(HELIX)%

    marker_pub.publish(points);
    marker_pub.publish(line_strip);
    marker_pub.publish(line_list);
}

// 显示功能没有实质内容
void path2rviz(ros::Publisher& plan_show_pub, RTKPlanner& planner, common::Path& plan)
{
    nav_msgs::Path path;
    path.header.stamp=ros::Time::now();
    path.header.frame_id="/map";
    for (uint32_t i = 0; i < plan.path.size(); ++i)
    {
        geometry_msgs::PoseStamped this_pose_stamped;
        this_pose_stamped.pose.position.x = plan.path[i].x - planner.complete_rtk_trajectory[0].x;
        this_pose_stamped.pose.position.y = plan.path[i].y - planner.complete_rtk_trajectory[0].y;

        //geometry_msgs::Quaternion goal_quat = tf::createQuaternionMsgFromYaw(1);
        this_pose_stamped.pose.orientation.x = 0;
        this_pose_stamped.pose.orientation.y = 0;
        this_pose_stamped.pose.orientation.z = 0;
        this_pose_stamped.pose.orientation.w = 1;

        this_pose_stamped.header.stamp=ros::Time::now();
        this_pose_stamped.header.frame_id="/map";

        path.poses.push_back(this_pose_stamped);
    }
    plan_show_pub.publish(path);
}

void RoadOrFarmLandCallback(const common::RoadOrFarmland::ConstPtr& msg)
{
    if ( msg->RoadOrFarmLand == false &&!flag_farmland_End)
    {
         std::cout<<"Road path End "<<std::endl;
         flag_farmland = true;
    }
}






int main(int argc, char **argv)
{
    ros::init(argc, argv, "planner");

    ros::NodeHandle n;
    // 发布节点
    ros::Publisher plan_pub = n.advertise<common::Path>("plan",2000);  //发布路径信息
    ros::Publisher plan_show_pub = n.advertise<nav_msgs::Path>("trajectory",1, true);
    ros::Publisher marker_pub = n.advertise<visualization_msgs::Marker>("visualization_marker", 10);
    ros::Publisher car_stop_pub = n.advertise<std_msgs::Bool>("Topic_Car_stop",1);

    ros::Publisher FarmLandEnd_pub = n.advertise<common::RoadOrFarmland>("FarmLandEnd",1);

    // 路径规划节点的对象
    RTKPlanner planner;

    RTKPlanner::p_planner = &planner;
    common::RoadOrFarmland msg_RoadOrFarmland;

    ros::Subscriber sub = n.subscribe("pose", 1, planner.localization_callback);    // 接受定位信息
    ros::Subscriber sub_RoadOrFarmland = n.subscribe("RoadOrFarmLand", 1000, RoadOrFarmLandCallback);
    
    ros::Rate loop_rate(10);
    //注意这个路径  
    std::string res = ros::package::getPath(std::string("planning"));
    res.append("/data/RoadPath.csv");   // 这是农田内的发布的路径！ 

    planner.ReadTrajectoryFile(res);
    common::Path plan_copy_1;     // 发布的规划路径
    common::Path plan_copy;     // 发布的规划路径
   
    while (ros::ok())
    {
        
       std::cout << flag_farmland<<std::endl;
       if(flag_farmland && !flag_farmland_End )
       {
        //计算路径——发布路径——显示路径
        common::Path plan;     // 发布的规划路径
        car_stop_pub.publish(planner.car_stop_flag);  //这个停车标志位是不是得放到田垄那里阿
        //在CalPath中求解发布的系列路径点并完成话题的发布
        planner.CalPath(plan);
        plan_copy.path.clear();
        static int num_point =0;
        plan_copy.path.clear();
        for(int i = 0;i<plan.path.size();i++){
          
            if(plan.path[i].gear!=plan.path[i+1].gear){
              if(i>20){
                    for(int j = 0;j<i;j++){
                         plan_copy.path.push_back(plan.path[j]);
                    }
                   // std::cout<<"i: "<<i<<"     plan.path[i].gear:"<<plan.path[i].gear<<"      plan.path[i+1].gear"<<plan.path[i+1].gear<<std::endl;
                     // ROS_WARN("111111111111111111111111111111111111111111111111111111111111111111111111   !!!");
                     break;
                 }
                 else{
                    for(int j=i+1;j<plan.path.size();j++){
                          plan_copy.path.push_back(plan.path[j]);
                     }
        //             // std::cout<<"i: "<<i<<"     plan.path[i].gear:"<<plan.path[i].gear<<"      plan.path[i+1].gear"<<plan.path[i+1].gear<<std::endl;
        //             // ROS_WARN("222222222222222222222222222222222222222222222222222222222222222222222222   !!!");
                     break;
                }
             }
             if(i == plan.path.size()-2){
                 for(int j = 0;j<plan.path.size();j++ ){
                       plan_copy.path.push_back(plan.path[j]);
                 }
              // std::cout<<"i: "<<i<<"     plan.path[i].gear:"<<plan.path[i].gear<<"      plan.path[i+1].gear"<<plan.path[i+1].gear<<std::endl;
        //         // ROS_WARN("3333333333333333333333333333333333333333333333333333333333333333333333333  !!!");
                 break;
             }
         }
        static  bool  num = true;
         if(num &&  !plan_copy.path.empty()){
             for(int i = 0;i<plan_copy.path.size();i++){
             plan_copy_1.path.push_back(plan_copy.path[i]);
          }
        //        std::cout<< plan_copy.path.size()<< "  "<<plan_copy_1.path.size()<<std::endl;
                num  = false;
         }

         if(!plan_copy.path.empty()  && !plan_copy_1.path.empty() ){
           // std::cout<<"plan_copy.path.size(): "<< plan_copy.path.size()<< "  "<<"     plan_copy_1.path.size(): "<<plan_copy_1.path.size()<<std::endl;
            // std::cout<<"plan_copy.path.front().time: "<< plan_copy.path.front().time<< "  "<<"   plan_copy_1.path.front().time: "<<plan_copy_1.path.front().time<<std::endl;
             if(  plan_copy.path.front().time >= plan_copy_1.path.front().time  ){
                             plan_pub.publish(plan_copy);
                             
                             path2rviz(plan_show_pub, planner, plan_copy);
                     }
             else
                     {
                              ROS_WARN("plan_copy___1   !!!");
                             plan_pub.publish(plan_copy);
                                 path2rviz(plan_show_pub, planner, plan_copy);
                     }
          std::cout<<std::endl;
        }

         if(!plan_copy_1.path.empty() &&   plan_copy.path.front().time >= plan_copy_1.path.front().time  ){
                   plan_copy_1.path.clear();
                 for(int i = 0;i<plan_copy.path.size();i++){
                    plan_copy_1.path.push_back(plan_copy.path[i]);
                 }
            }
            msg_RoadOrFarmland.RoadOrFarmLand =true ;
            msg_RoadOrFarmland.FarmlandEnd =false ;
        compath2rviz(marker_pub, planner);  //显示功能 无实际意义
       }
      
       if(planner.car_stop_flag.data)   // 这里直接能进。
       {
            flag_farmland_End = true;
            flag_farmland = false;
            msg_RoadOrFarmland.RoadOrFarmLand =false ;
            msg_RoadOrFarmland.FarmlandEnd =true ;
       }
       
       FarmLandEnd_pub.publish(msg_RoadOrFarmland);
       ros::spinOnce();
       loop_rate.sleep();
    }
 //return 0;
    
}
