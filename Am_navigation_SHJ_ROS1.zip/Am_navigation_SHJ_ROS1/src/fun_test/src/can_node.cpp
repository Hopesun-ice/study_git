#include "ros/ros.h"
#include "fun_test/can.h"
#include <sys/select.h>
#include <sys/time.h>
#include <common/Cmd_control.h>
#include <std_msgs/Float32.h>
#include <common/Pose.h>
#include  "common/common.h"
#include <vector>
#include "std_msgs/Float32.h"
int num = 0;
unsigned char *rec_lat_data;Can_Bus test;
double angel_qianlun = 0;
/*备注�?
cmd_lon_data（纵向指令）：字�?1：各种使�?  2�?(00空当)  (01前进) (02后退)   字节5�?6是转速：5是低位，6是高位（注意这个要和车内的的档位结合�?
cmd_lat_data（横向指令）�? 字节1�?2：方向盘转速控制（最�?256实际上第二个字节根本用不到），字�?3�?4是正反转的选择 第四个字节也用不上， 01：正  02反转
*/
unsigned char cmd_lon_data[8] ={0x55,0x01,0x00,0x00,0x00,0x00,0x00,0x00};
unsigned char cmd_lat_data[8] ={0x00,0x00,0x01,0x00,0x00,0x01,0x64,0x00};

//测试使用
unsigned char cmd_lon_data_test[8] ={0x55,0x01,0x00,0x00,0x20,0x00,0x00,0x00};
unsigned char cmd_lat_data_test_z[8] ={0x0f,0x00,0x01,0x00,0x00,0x01,0x64,0x00};
unsigned char cmd_lat_data_test_f[8] ={0x0f,0x00,0x02,0x00,0x00,0x01,0x64,0x00};

//jiju
static  unsigned char   cmd_toos[] = {0xff,0xff,0xff,0xff,0xff,0x01,0x01,0x00};


void delta_callback( const std_msgs::Float32  & delta){
    angel_qianlun = delta.data;
}

void test_steer(){
    static int print_num;
     for(int i = 0;i<10;i++){
            test.Can_Write(0x200,8,cmd_lat_data_test_z,false,test.s_can0);//false 代表标准�?
            usleep(20*1000);
            print_num++;
            std::cout<<print_num<<std::endl;
    }
   print_num = 0;
 
    // static int num = 1;
    // if(num){
    //     cmd_lon_data_test[4] = (1000*8)%256;     cmd_lon_data_test[5] = (1000*8) /256;
    //     test.Can_Write(0x0CFF01F1,8,cmd_lon_data_test,true,test.s_can1);
    //      std::cout<< "123"<<std::endl;
    //      usleep(100000);
    // }  
}
void  test_taisheng_init(){
    static unsigned char   arr_1 [] = {0x00,0x00,0xfa,0xfa,0xfa,0x00,0x00,0x00};
    static  unsigned char  arr_2 [] = {0x00,0x00,0xfa,0xfa,0xfa,0x00,0x01,0x00};
    static  unsigned char  arr_3 [] = {0x00,0x00,0xfa,0xfa,0xfa,0x00,0x01,0x00};
    static  unsigned char  arr_4 [] = {0x00,0x00,0xfa,0xfa,0xfa,0x01,0x01,0x00};
    static  unsigned char  arr_5 [] = {0x00,0x00,0xfa,0xfa,0xfa,0x00,0x01,0x00};
    static  int init_num = 10, init_num1 = 10;
    while(init_num ){
             test.Can_Write(0x18FF9dF1,8,arr_1,true,test.s_can1);
             for(int i = 0;i<8;i++){
                std::cout<<"   "<<(int)arr_1[i];
             }
             std::cout<<std::endl;  std::cout<<std::endl;
              usleep(100000);
            test.Can_Write(0x18FF9dF1,8,arr_2,true,test.s_can1);
                for(int i = 0;i<8;i++){
                std::cout<<"   "<<(int)arr_2[i];
             }
             std::cout<<std::endl;  std::cout<<std::endl;
            init_num --;
             std::cout<< "Enable_bit-----0------>1"<<std::endl;
    }
    while(! init_num && init_num1){
        test.Can_Write(0x18FF9dF1,8,arr_3,true,test.s_can1);
         usleep(100000);
             for(int i = 0;i<8;i++){
                std::cout<<"   "<<(int)arr_3[i];
             }
             std::cout<<std::endl;  std::cout<<std::endl;
        test.Can_Write(0x18FF9dF1,8,arr_4,true,test.s_can1);
                usleep(100000);
                    for(int i = 0;i<8;i++){
                std::cout<<"   "<<(int)arr_4[i];
             }
             std::cout<<std::endl;  std::cout<<std::endl;
        test.Can_Write(0x18FF9dF1,8,arr_5,true,test.s_can1);
            for(int i = 0;i<8;i++){
                std::cout<<"   "<<(int)arr_5[i];
             }
             std::cout<<std::endl;  std::cout<<std::endl;
        init_num1 --;
         std::cout<< "stop----->up---->stop"<<std::endl;
    }      
       for(int i = 0;i<50;i++){
         test.Can_Write(0x18FF9dF1,8,arr_4,true,test.s_can1);
         usleep(100000);
         std::cout<< "inti-----------------taishegng"<<std::endl;
   }
}
void  test_taisheng(){

    static  unsigned char  arr_sheng [] = {0x48,0x01,0xfa,0xfa,0xfa,0x01,0x01,0x00};
    static  unsigned char  arr_x [] = {0xc0,0x03,0xfa,0xfa,0xfa,0x02,0x01,0x00};
     static  unsigned char arr_s [] = {0xc0,0x00,0xfa,0xfa,0xfa,0x00,0x01,0x00};

   for(int i = 0;i<30;i++){
         test.Can_Write(0x18FF9dF1,8,arr_sheng,true,test.s_can1);
         usleep(100000);
   }
    for(int i = 0;i<30;i++){
         test.Can_Write(0x18FF9dF1,8,arr_s,true,test.s_can1);
         usleep(100000);
   }
    for(int i = 0;i<50;i++){
        test.Can_Write(0x18FF9dF1,8,arr_x,true,test.s_can1);
        usleep(100000);
}
    for(int i = 0;i<30;i++){
         test.Can_Write(0x18FF9dF1,8,arr_s,true,test.s_can1);
         usleep(100000);
   }
   
   
     std::cout<< "123"<<std::endl;
}

void  test_PTO(){

    static  unsigned char  arr_b [] = {0x55,0x01,0x00,0x00,0x00,0x00,0x00,0x01};
    static  unsigned char  arr_s [] = {0x55,0x01,0x00,0x00,0x00,0x00,0x00,0x00};

   for(int i = 0;i<30;i++){
         test.Can_Write(0x0CFF01F1,8,arr_b,true,test.s_can1);
         usleep(100000);
   }
    for(int i = 0;i<30;i++){
         test.Can_Write(0x0CFF01F1,8,arr_s,true,test.s_can1);
         usleep(100000);
   }
std::cout<< "123"<<std::endl;
}

void test_pwm(){
    static  unsigned char  pwm_1 [] = {0x21,0x06,0x23,0x51,0x01,0xF4,0xAA,0xAA};
    static  unsigned char  pwm_2 [] = {0x21,0x06,0x23,0x52,0x02,0xF4,0xAA,0xAA};
     static  unsigned char  pwm_12 [] = {0x21,0x10,0x23,0x50,0x00,0x02,0x04,0x01,0xf4,0x01,0xf4,0xaa,0xaa};
    for(int i = 0;i<500;i+=100){
        pwm_1[5] = i%256;
        pwm_1[4] = i/256;
        //  pwm_2[5] = (999-i)%256;
        //  pwm_2[4] = (999-i)/256;
    //    test.Can_Write(0,8,pwm_2,false,test.s_can0);
       
        test.Can_Write(0,8,pwm_1,false,test.s_can0);
       
        usleep(30*1000);
        std::cout<< "111111111"<<std::endl;
    }
    // for(int i = 0;i<1000;i+=50){
    //     pwm_2[5] = i%256;
    //     pwm_2[4] = i/256;
    //     usleep(30*1000);
    //     test.Can_Write(0,8,pwm_2,false,test.s_can0);
    // }
    // test.Can_Write(0,13,pwm_12,false,test.s_can0);
    // usleep(30*1000);
}
int main(int argc, char** argv)
{
     ros::init(argc,argv,"Can_Node" );
     ros::NodeHandle n;
    test.Can_Init_can0();
    test.Can_Init_can1();
    // test_taisheng_init();
    ros::Rate r(50);
    while(1){

        test_pwm();
        // test_steer();
        // test_taisheng();
        // test_PTO();
       r.sleep();
        ros::spinOnce();
    }
    close(test.s_can0);
    close(test.s_can1);
    return 0;
}