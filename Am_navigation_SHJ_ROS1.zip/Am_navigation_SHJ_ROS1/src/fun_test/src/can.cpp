#include "fun_test/can.h"
Can_Bus::Can_Bus(std::string sel_can){
    this->sel_can = sel_can;
}
Can_Bus::~Can_Bus(){
    close(s_can0);
     close(s_can1);
}
void Can_Bus::Can_Init_can0(){
    struct  sockaddr_can  addr;
    struct ifreq ifr;
    struct can_filter rfilter[1];
    s_can0 = socket(PF_CAN, SOCK_RAW, CAN_RAW); //创建套接字
    strcpy(ifr.ifr_name, "can0" );
    ioctl(s_can0, SIOCGIFINDEX, &ifr); //指定 can0 设备
    addr.can_family = AF_CAN;
    addr.can_ifindex = ifr.ifr_ifindex;
    bind(s_can0, (struct sockaddr *)&addr, sizeof(addr)); //将套接字与 can0 绑定
     //定义接收规则，只接收表示符等于 0x11 的报文
   // rfilter[0].can_id = 0x11;
    //rfilter[0].can_mask = CAN_SFF_MASK;
    int loopbacke = 0;
    //设置过滤规则
   // setsockopt(s_can0, SOL_CAN_RAW, CAN_RAW_FILTER, &rfilter, sizeof(rfilter));
    setsockopt(s_can0,SOL_CAN_RAW,CAN_RAW_LOOPBACK,&loopbacke,sizeof(loopbacke));
    //这句话 很重要 设置read函数 为非阻塞
    fcntl(s_can0,F_SETFL,FNDELAY);
}
void Can_Bus::Can_Init_can1(){
    struct  sockaddr_can  addr;
    struct ifreq ifr;
    struct can_filter rfilter[1];
    s_can1 = socket(PF_CAN, SOCK_RAW, CAN_RAW); //创建套接字
    strcpy(ifr.ifr_name, "can1" );
    ioctl(s_can1, SIOCGIFINDEX, &ifr); //指定 can0 设备
    addr.can_family = AF_CAN;
    addr.can_ifindex = ifr.ifr_ifindex;
    bind(s_can1, (struct sockaddr *)&addr, sizeof(addr)); //将套接字与 can0 绑定
     //定义接收规则，只接收表示符等于 0x11 的报文
   // rfilter[0].can_id = 0x11;
    //rfilter[0].can_mask = CAN_SFF_MASK;
    int loopbacke = 0;
    //设置过滤规则
   // setsockopt(s_can0, SOL_CAN_RAW, CAN_RAW_FILTER, &rfilter, sizeof(rfilter));
    setsockopt(s_can1,SOL_CAN_RAW,CAN_RAW_LOOPBACK,&loopbacke,sizeof(loopbacke));
    //这句话 很重要 设置read函数 为非阻塞
    fcntl(s_can1,F_SETFL,FNDELAY);
}
bool  Can_Bus::Can_Write(int Id,int Can_Dlc,unsigned char* data,bool EX,int  s_can){
    if(EX){
        frame_can1[0].can_id = Id | CAN_EFF_FLAG;//注意  后面|一下 这个 CAN_EFF_FLAG 代表 发送的扩展真
    }else{
        frame_can1[0].can_id = Id ;
    }
    
    frame_can1[0].can_dlc = Can_Dlc;
    for(int i = 0;i<Can_Dlc;i++){
        frame_can1[0].data[i] = data[i];
    }
    int nbytes = write(s_can,&frame_can1[0],sizeof(frame_can1[0]));
 
    if(nbytes != sizeof(frame_can1[0])){
        std::cout<< "Send  Error !"<<std::endl;
        return false;
    }
    else{
        return true;
    }
}
void Can_Bus:: Can_Read(unsigned  char * rec_data,uint64_t * id_len){
    int nbytes = read(s_can0,&frame[1],sizeof(frame[1]));
    if(nbytes>0){
        std::cout<< "ID: "<<frame[1].can_id<< "   date_len:"<<(int)frame[1].can_dlc<< "    date: ";
        id_len[0] = frame[1].can_id;
        id_len[1] = frame[1].can_dlc;
        for(int i = 0;i<frame[1].can_dlc;i++){
            rec_data[i] = frame[1].data[i];
            std::cout<<(int)frame[1].data[i]<< "  ";  
        }
        std::cout<<std::endl;
    }
}