﻿#include <stdio.h>
#include <string.h>
#include <fstream>  
#include <iostream>
using namespace std;
int main() {
    ofstream out;
    out.open("test.csv", std::ios::out | std::ios::trunc);       //根据自己需要进行适当的选取
    return 0;
}