﻿#include <matplotlibcpp.h>
namespace plt = matplotlibcpp;
void  draw_picture(int num,...);