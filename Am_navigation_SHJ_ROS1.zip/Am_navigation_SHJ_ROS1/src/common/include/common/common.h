﻿#ifndef COMMON_H
#define COMMON_H
#include<iostream>
#include<ros/ros.h>
#include <cmath>
#include <vector>
#include <string>
#include <fstream>
// 结构体用于存储关键字及其数值

#define DEBUG
#ifdef DEBUG
    #define Debug_Info(msg)  ROS_INFO_STREAM(msg)
    #define Debug_Warn(msg)  ROS_WARN_STREAM(msg)
    #define Debug_Error(msg) ROS_ERROR_STREAM(msg)
#else
    #define Debug_Info(msg)
#endif

struct Keyword {
    char keyword[128];
    char value[128];
};
double   range_angle_PI(double angle);
std::vector<std::string> Split(const std::string& str,const std::string& delims);
struct Keyword read_txt_file(const char *file_path, const char *keyword);
double process_data(double data, double a, double b, double c);
double slide_mean_filter(double data, int buffer_size);
std::string ReadLastLine(const std::string& filename) ;
uint16_t  CRC16_2(unsigned char *buf, int len);
#endif
