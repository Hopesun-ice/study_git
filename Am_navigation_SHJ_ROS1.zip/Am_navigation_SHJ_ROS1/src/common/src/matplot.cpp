﻿#include"matplot.h"
void  draw_picture(int num,...){
    va_list ap;
    va_start(ap,num);
    std::vector<std::vector<double>> data;
    for(int i=0;i<num;i++){
        data[num] = va_arg(ap,std::vector<double>);
    }
    va_end(ap);
    plt::plot(data[0]);
    plt::show();
}