#include<common/common.h>
#define MAX_LEN 1024  // 定义每行读取的最大长度

double  range_angle_PI(double angle){
    if (angle > M_PI)angle -= 2 * M_PI;
	else if (angle < -M_PI)angle += 2 * M_PI;
	return angle;
}


std::vector<std::string> Split(const std::string& str,
                               const std::string& delims) {
  std::vector<std::string> tokens;
  std::string::size_type last_index = str.find_first_not_of(delims, 0);
  std::string::size_type index = str.find_first_of(delims, last_index);

  while (std::string::npos != index || std::string::npos != last_index) {
    tokens.push_back(str.substr(last_index, index - last_index));
    last_index = str.find_first_not_of(delims, index);
    index = str.find_first_of(delims, last_index);
  }
  return tokens;
}



// 函数定义：读取txt文本中指定关键字的数值
struct Keyword read_txt_file(const char *file_path, const char *keyword) {
    struct Keyword result = {"", ""};  // 存储读取到的结果
    char buffer[MAX_LEN];  // 读取每行数据的缓冲区

    // 打开文件
    FILE *f = fopen(file_path, "r");
    if (f == NULL) {
        printf("Failed to open file %s.\n", file_path);
        return result;
    }

    // 逐行读取每行数据
    while (fgets(buffer, MAX_LEN, f) != NULL) {
        // 去掉字符串末尾的换行符
        int len = strlen(buffer);
        if (len > 0 && buffer[len-1] == '\n') {
            buffer[len-1] = '\0';
        }
        
        // 查找关键字，并把对应的数值提取出来
        char *ptr = strstr(buffer, keyword);
        if (ptr != NULL) {
            ptr += strlen(keyword);
            if (*ptr == ':') {
                ptr++;  // 指向值的第一个字符
                strncpy(result.value, ptr, sizeof(result.value));
                result.value[sizeof(result.value)-1] = '\0';  // 防止字符串溢出
                strcpy(result.keyword, keyword);
                break;
            }
        }
    }
    // 关闭文件
    fclose(f);
    return result;
}

double process_data(double data, double a, double b, double c)
{
    static double prev_processed_data = 0.0; // 用静态变量保存上一次处理后的数据
    // 将输入数据限制在上下限范围内
    if (data > a)data = a;
    else if (data < b)data = b;
    // 进行数据处理
    double processed_data = data; // 这里只是一个示例，实际处理过程可以根据需要修改
    // 检查是否需要保持上一次处理后的数据
    if (std::abs(processed_data - prev_processed_data) >= c){processed_data = prev_processed_data;}
    // 保存本次处理后的数据，供下次调用时使用
    prev_processed_data = processed_data;
    // 返回处理后的数据
    return processed_data;
}
//帮我写一个滑动窗口均值滤波函数，窗口大小可以自己定义，比如5个数据，然后每次收到一个新数据，就把最早的那个数据扔掉，然后把新数据放进去，然后求平均值，然后输出这个平均值，这样就可以了
double slide_mean_filter(double data, int buffer_size)
{
    static double data_buffer[10];
    static int buffer_index = 0; // 用静态变量保存上一次处理后的数据
    // 将输入数据限制在上下限范围内
    if (buffer_index >= buffer_size)buffer_index = 0;
    data_buffer[buffer_index] = data;
    buffer_index++;
    double sum = 0;
    for (int i = 0; i < buffer_size; i++)
    {
        sum += data_buffer[i];
    }
    return sum / buffer_size;
}

// 读取文件的最后一行  仅做测试用
std::string ReadLastLine(const std::string& filename) {
    std::string lastLine;
    std::ifstream file(filename);
    if (file.is_open()) {
        std::string line;
        while (getline(file, line)) {
            lastLine = line;
        }
        file.close();
    }
    return lastLine;
}

uint16_t  CRC16_2(unsigned char *buf, int len)
{
	uint16_t crc = 0xFFFF;
	for (int pos = 0; pos < len; pos++){
        crc ^= (uint16_t)buf[pos]; // XOR byte into least sig. byte of crc
        for (int i = 8; i != 0; i--)   // Loop over each bit
        {
            if ((crc & 0x0001) != 0)   // If the LSB is set
            {
                crc >>= 1; // Shift right and XOR 0xA001
                crc ^= 0xA001;
            }
            else // Else LSB is not set
            {    
                crc >>= 1;    // Just shift right
            }
        }
	}   
	crc = ((crc & 0x00ff) << 8) | ((crc & 0xff00) >> 8);
    buf[len]=crc/256;
    buf[++len] = crc%256;
	return crc;
}