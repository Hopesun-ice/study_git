import matplotlib.pyplot as plt
import numpy as np
import time
from math import *

import rospy
from std_msgs.msg import Float32

horizontal_error_file_path = "/home/beidou/a.txt"

t_now = 0
t=[t_now]
m=[t_now]

def horizontal_error_Callback(data):
    rospy.loginfo(data.data)
    global t_now
    t_now= t_now + 1
    t.append(t_now)
    m.append(data.data)
    plt.plot(t,m,'-r')
    plt.pause(0.01)
    print(t)
    with open(horizontal_error_file_path,'a+') as f:
        f.writelines(str(data.data))

def horizontal_error():
    rospy.init_node('listener',anonymous=True)
    rospy.Subscriber('error',Float32,horizontal_error_Callback)
    rospy.spin()



if __name__ =='__main__':
    horizontal_error()
    


