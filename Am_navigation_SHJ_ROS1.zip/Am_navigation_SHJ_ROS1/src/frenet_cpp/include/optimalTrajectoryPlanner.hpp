#ifndef INCLUDE_OPTIMALTRAJECTORYPLANNER_HPP_
#define INCLUDE_OPTIMALTRAJECTORYPLANNER_HPP_

#include <iostream>
#include <vector>
#include <cmath>
#include <iostream>
#include <polynomial.hpp>
#include <frenetPath.hpp>
#include <opencv2/opencv.hpp>
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <Eigen/Dense>
#include "ros/ros.h"
#include <sys/stat.h>
#include <cassert>
#include "frenet_cpp/CustomMsg.h"  // 确保替换为你的包名
#include "frenet_cpp/Pose.h"
#include "frenet_cpp/BoundingBox.h"
#include "frenet_cpp/BoundingBoxes.h"
#include <fstream>
#include <common/CustomMsg.h>
#include "common/DataArray.h"
#include "frenet_cpp/DataArray.h"
#include "frenet_cpp/Path.h"
#include "common/Path.h"
#include "frenet_cpp/Pathpoint.h"
#include "common/Pathpoint.h"
#include "frenet_cpp/ObstacleArray.h"
#include "frenet_cpp/Obstaclepoint.h"

////轨迹规划器的类
class OptimalTrajectoryPlanner
{
    public:

        OptimalTrajectoryPlanner();

        ~OptimalTrajectoryPlanner();

        bool isColliding();

        FrenetPath optimalTrajectory(double d0, double dv0, double da0,
                                     double s0, double sv0,
                                     std::vector<std::vector<double>> &centerLane,
                                     std::vector<std::vector<double>> &obstacles,
                                    std::vector<std::vector<double>> &obstacle_dynamic,
                                     std::vector<std::vector<double>> &obstacle_rectangle,
                                     std::vector<FrenetPath> &allPaths);

        void trajectoryCost(FrenetPath &path);

        bool isColliding(FrenetPath &path, std::vector<std::vector<double>> &obstacles, std::vector<std::vector<double>> &obstacle_dynamic,std::vector<std::vector<double>> &obstacle_rectangle);

        bool isWithinKinematicConstraints(FrenetPath &path);

        std::vector<FrenetPath> isValid(std::vector<FrenetPath> &paths, std::vector<std::vector<double>> &obstacles, std::vector<std::vector<double>> &obstacle_dynamic,std::vector<std::vector<double>> &obstacle_rectangle);

        std::vector<FrenetPath> isValid(std::vector<FrenetPath> &paths);

        void convertToWorldFrame(std::vector<FrenetPath> &paths, std::vector<std::vector<double>> &centerLane);

        cv::Point2i windowOffset(float x, float y, int image_width, int image_height);

        Eigen::Vector2d rotation(double theta, double x, double y);

        void run();

    private:
        double pi_ = 3.14159;
   
};

#endif  //  INCLUDE_OPTIMALTRAJECTORYPLANNER_HPP_