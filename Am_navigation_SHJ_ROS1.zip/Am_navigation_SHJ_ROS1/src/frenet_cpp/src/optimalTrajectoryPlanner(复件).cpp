#include <optimalTrajectoryPlanner.hpp>
// #include <gsl/gsl_interp.h>
#include <gsl/gsl_spline.h>

#include <thread>
#include"cJSON.h"
#include <mutex>
#include <unistd.h>
#include <common/Pose.h>


// #include "rclcpp/rclcpp.hpp"

///配置读取 需要读取的参数

// 设置插值的细腻度 
double step = 0.1;
double left_distance = 4;
double right_distance = 4;
std::string outputsetfilename =  "centerLane.csv";
std::string output_imagefilename = "output_image.png";
std::string gaussdatafilename = "centerLane_wf.csv";
std::string obstaclefilename = "obstacle.txt";
std::string departure_return= "departure";
double maxVelocity_ = 50/3.6;     ///最大速度
double maxAcceleration_ = 2;     ////最大加速度
double maxSteeringAngle_ = 0.7;     /////最大转角
double maxCurvature_ = 10;            ////最大曲率
double robotFootprint_ = 1.5;
double maxPredictionStep_ = 30;  ///分为多少  5-4S时间
double minPredictionStep_ = 20;
double noOfLanes_ = 7;    ////分为的车道数目
double laneWidth_ = 1;    ///相当于车道宽度 
double targetVelocity_ = 3.6/3.6;  ///目标速度
double velocityStep_ = targetVelocity_/2; ////每一步的速度
double timeStep_ = 0.05;
double klat_ = 1;
double klon_ = 1;
double kjd_ = 0.1;
double ktd_ = 0.1;
double ksd_ = 0.5;
double kjs_ = 0.1;
double kts_ = 0.1;
double kss_ = 2;
std::vector<std::vector<double>> centerLane{{0.0, 0.0}, {10.0, -2.0}, {20.5, 5.0}, {35.0, 6.5}, {70.5, 2.0} , {105.5, 2.0} };
std::vector<std::vector<double>> centerLane_publish{{0.0, 0.0}, {10.0, -2.0}, {20.5, 5.0}, {35.0, 6.5}, {70.5, 2.0} , {105.5, 2.0} };
std::vector<std::vector<double>> obstacle_circle;
std::vector<std::vector<double>> obstacle_rectangle;
double Global_heading = 0;
double Global_x = 0;
double Global_y = 0;
double Global_z = 22;
double maxX = centerLane[0][0];
double minX = centerLane[0][0];
double maxY = centerLane[0][1];
double minY = centerLane[0][1];
double bili_X = 0;
double bili_Y = 0;
ros::Publisher pub;

int obstacle_dis_flag = 0;

ros::Publisher pub_obs;

cv::Mat lane(12000, 12000, CV_8UC3, cv::Scalar(255, 255, 255));
std::mutex data_mutex;  //全局互斥锁
void xuanzhuan_ceshi();
OptimalTrajectoryPlanner::OptimalTrajectoryPlanner() {
	// minimumTurningRadius_ = wheelBase_/tan(maxSteeringAngle_)
	// maxCurvature_ = 1/minimumTurningRadius_;
}

OptimalTrajectoryPlanner::~OptimalTrajectoryPlanner() {
}
//////最优求解器
// int lujingshu = 0;
FrenetPath OptimalTrajectoryPlanner::optimalTrajectory(double d0, double dv0, double da0,
												 	   double s0, double sv0,
												 	   std::vector<std::vector<double>> &centerLane,
												 	   std::vector<std::vector<double>> &obstacles,
													   std::vector<std::vector<double>> &obstacle_rectangle,
												 	   std::vector<FrenetPath> &allPaths){
	// To store all possible tranectories in TNB/Frenet Frame   在TNB/Frenet框架中存储所有可能的瞬态
	std::vector<FrenetPath> paths;

	// Calculate all possible paths in TNB/Frenet Frame         计算TNB/Frenet帧中所有可能的路径
	// Iterate over different prediction times                  迭代不同的预测时间   设定最大最小步长 4-5
	// int jishu = 0;
	for(double T = minPredictionStep_; T<maxPredictionStep_; T=T+0.5){

		// Iterate over different lanes 在不同的车道上迭代
		//[-6,6]这个区间  每次加2
		for(double dT = -((noOfLanes_-1)*laneWidth_)/2; dT<= ((noOfLanes_-1)*laneWidth_)/2; dT = dT + laneWidth_){
			double dvT = 0 , daT = 0;
			std::vector<std::vector<double>> latitudionalTrajectory;
			Polynomial quintic(d0, dv0, da0, dT, dvT, daT, T);
			double jd = 0;
			// Generate Latitudinal Trajectory for a given T and lane   生成给定T和车道的横向轨迹 五次
			for(double t=0; t<=T; t=t+timeStep_){
				std::vector<double> data= {quintic.position(t), quintic.velocity(t), quintic.acceleration(t), quintic.jerk(t), t};
				jd += std::pow(data[3],2);
				latitudionalTrajectory.push_back(data);
			}
			// Iterate over different end velocities times 迭代不同的终端速度和时间
			// for(double svT = targetVelocity_ - velocityStep_ ; svT<=targetVelocity_ + velocityStep_; svT = svT+velocityStep_){
				double svT  = targetVelocity_;
				FrenetPath path;
				path.T = T;
				path.d = latitudionalTrajectory;
				path.jd = jd;
				std::vector<std::vector<double>> longitudionalTrajectory;
				// std::cout<< "sv0  "<<  sv0 << std::endl;
				// std::cout<< "svT  "<<  svT << std::endl;
				// std::cout<< "T  "<<  T << std::endl;

				Polynomial quartic(s0, sv0, 0, svT, 0, T);
				double js = 0;
				// Generate Longitudional Trajectory for a given v and Latitudional Trajectory  生成给定v的纵向轨迹和纵向轨迹
				for(double t=0; t<=T; t=t+timeStep_){
					std::vector<double> data= {quartic.position(t), quartic.velocity(t), quartic.acceleration(t), quartic.jerk(t), t};
					js += std::pow(data[3],2);
					if(data[1]>path.maxVelocity)
						path.maxVelocity = data[1];
					if(data[2]>path.maxAcceleration)
						path.maxAcceleration = data[2];
					longitudionalTrajectory.push_back(data);
				}
				path.s = longitudionalTrajectory;
				path.js = js;

				trajectoryCost(path);   ////获取代价值

		        // std::cout << "path.d  " << path.d<< std::endl;
                // jishu++;
				// store Frenet path 贮存Frenet路径
				// for(int i{0}; i< path.d.size(); i++){
				// 	// std::cout<< "第 "<<  i << "xs  "<< path.s[i][0] << std::endl;
				// 	std::cout<< "第 "<< i  << "  d  "<< path.d[i][0] << std::endl;
				// }
				// lujingshu++;
				// std::cout<< "路径数"<< lujingshu << std::endl;
               
				paths.push_back(path);
			// }
		}
	}

  	std::cout << "Frenet帧转换为全局/世界帧  " <<std::endl;

	//  将轨迹从Frenet帧转换为全局/世界帧
	convertToWorldFrame(paths, centerLane);

	// check if trajectories are valid based on kinodynamic constraints and collisions
	//检查基于动力学约束和碰撞的轨迹是否有效
	std::vector<FrenetPath> validPaths;
	validPaths = isValid(paths, obstacles,obstacle_rectangle);
	allPaths = paths;
  	// std::cout << "碰撞检测完成  " <<std::endl;
	if (validPaths.empty()) {
		std::cout << "validPaths is empty!" << std::endl;
		while (ros::ok())
		{
			/* code */
		}

	}
	//根据成本从所有有效路径中找出最优轨迹
	FrenetPath optimalTrajectory;

	double cost = INT_MAX;
	for(FrenetPath &path:validPaths){
		if(cost >= path.cf){
			cost = path.cf;
			optimalTrajectory = path;
		}
	}
	std::cout << "最优轨迹  "<< optimalTrajectory.s.size() <<std::endl;
	// for(int i{0}; i<optimalTrajectory.world.size(); i++){
    std::cout << "曲率" << optimalTrajectory.maxCurvature<< std::endl;
    std::cout << "代价值" << optimalTrajectory.cf<< std::endl;
    std::cout << "d" << optimalTrajectory.d.back()[0]<< std::endl;

		// }

	// for(int i{1}; i< optimalTrajectory.s.size(); i++){
	// 		std::cout<< "x  "<< optimalTrajectory.world[i][0] << std::endl;
	// 		std::cout<< "y  "<<  optimalTrajectory.world[i][1] << std::endl;
	// }	

	// for(int i{1}; i<p.world.size(); i++){
	// 		cv::line(lane, windowOffset(p.world[i-1][0], p.world[i-1][1], lane.cols, lane.rows), windowOffset(p.world[i][0], p.world[i][1], lane.cols, lane.rows), cv::Scalar(0, 255, 0), 30);
	// 	}
	return optimalTrajectory;
}

void OptimalTrajectoryPlanner::trajectoryCost(FrenetPath &path){
     double cd  = 0;
	// double cd = path.jd*kjd_ + path.T*ktd_ + std::pow(path.d.back()[0], 2)*ksd_;
	// double cv = path.js*kjs_ + path.T*kts_ + std::pow(path.s.front()[0]-path.s.back()[0],2)*kss_;
	if(obstacle_dis_flag == 1)
	 cd = path.jd*kjd_ + path.T*ktd_+path.maxCurvature*5;
	else
	 cd = path.jd*kjd_ + path.T*ktd_ + std::pow(path.d.back()[0], 2)*ksd_;
	double cv = path.js*kjs_ + path.T*kts_;
	path.cf = klat_*cd + klon_*cv;
}

// 计算两点之间的距离
double distance(double x1, double y1, double x2, double y2) {
    return std::hypot(x1 - x2, y1 - y2);
}

// 计算点(px, py)到通过点(x1, y1)和点(x2, y2)的线段的最短距离
double pointToSegmentDistance(double px, double py, double x1, double y1, double x2, double y2) {
    double dx = x2 - x1;
    double dy = y2 - y1;
    // 线段的长度的平方
    double l2 = dx * dx + dy * dy;
    if (l2 == 0.0) {
        // 线段退化为一个点
        return distance(px, py, x1, y1);
    }
    // 计算投影点到线段起点的相对位置t
    double t = ((px - x1) * dx + (py - y1) * dy) / l2;
    if (t < 0.0) {
        // 投影点在线段的外部，最近的点是线段起点
        return distance(px, py, x1, y1);
    }
    if (t > 1.0) {
        // 投影点在线段的外部，最近的点是线段终点
        return distance(px, py, x2, y2);
    }
    // 投影点在线段上
    return distance(px, py, x1 + t * dx, y1 + t * dy);
}

// 计算点(px, py)到矩形的最短距离
double pointRectangleDistance(double px, double py, const std::vector<double>& rectangle) {
    std::vector<double> distances;
    // 计算点到每条边的距离
    for (int i = 0; i < 4; i++) {
        int j = (i + 1) % 4;
        distances.push_back(pointToSegmentDistance(px, py, rectangle[2*i], rectangle[2*i+1], rectangle[2*j], rectangle[2*j+1]));
    }
    // 返回最短距离
    return *std::min_element(distances.begin(), distances.end());
}

/////可以调节障碍物的大小范围目前是1的圆
bool OptimalTrajectoryPlanner::isColliding(FrenetPath &path, std::vector<std::vector<double>> &obstacles, std::vector<std::vector<double>> &obstacle_rectangle){
	for(int i = 0; i<path.world.size(); i++){
		for(int j = 0; j<obstacles.size(); j++){
			if(std::sqrt(std::pow(path.world[i][0]-obstacles[j][0],2)+std::pow(path.world[i][1]-obstacles[j][1],2)) <= 0.3+0.8){
				std::cerr<< "圆距离  "<<std::sqrt(std::pow(path.world[i][0]-obstacles[j][0],2)+std::pow(path.world[i][1]-obstacles[j][1],2))<<" 点数 "<< i << std::endl;
				return true;
			}
		}
		//矩形障碍物
		for(int j = 0; j<obstacle_rectangle.size(); j++){
			if(pointRectangleDistance(path.world[i][0],path.world[i][1],obstacle_rectangle[j])<0.2+0.8){
				std::cerr<< "矩形距离  "<<pointRectangleDistance(path.world[i][0],path.world[i][1],obstacle_rectangle[j])<< std::endl;

				return true;
			}
		}

	}
	return false;
}

bool OptimalTrajectoryPlanner::isWithinKinematicConstraints(FrenetPath &path){
	if(path.maxVelocity>maxVelocity_ || path.maxAcceleration>maxAcceleration_ || abs(path.maxCurvature)>maxCurvature_){
	    std::cerr << "不符合 "<< path.cf<< "   " << path.maxVelocity<< "   " << path.maxAcceleration <<"   " << path.maxCurvature << std::endl;
		// return false;
		 return true;
	}
	    std::cerr << "符合  "<< std::fixed << path.cf<< "   " << path.maxVelocity<< "   " << path.maxAcceleration <<"   " << path.maxCurvature << std::endl;

	return true;
}
////碰撞检测

std::vector<FrenetPath> OptimalTrajectoryPlanner::isValid(std::vector<FrenetPath> &paths, std::vector<std::vector<double>> &obstacles, std::vector<std::vector<double>> &obstacle_rectangle){
	std::vector<FrenetPath> validPaths;
	int num_path = 0;
	for(FrenetPath &path:paths){
	// if (!isColliding(path, obstacles) && isWithinKinematicConstraints(path)){
	if (!isColliding(path, obstacles,obstacle_rectangle)){
           if(isWithinKinematicConstraints(path)){
			validPaths.push_back(path);		   
		}
		else{
				// std::cout<< "不符合动力学约束  "<< path.cf<< std::endl;
		   }
		}
		else{
        	// for(int j = 0; j<paths.size(); j++){

			// }
			if(num_path >1){
				paths[num_path-1].cf +=50;
				paths[num_path-2].cf +=5;		
		
			}
			if(num_path <paths.size()-1 ){
				paths[num_path+1].cf +=50;
				paths[num_path+2].cf +=5;		
		
			} 
		   std::cout<< "碰撞  "<< "  "<<num_path	<< "  "<<paths[num_path-1].cf <<"   "<< path.cf<<"   "<< path.maxCurvature<< std::endl;
		}
		num_path++;
	}
	return validPaths;
}
////x y对调
void swapXAndY(std::vector<std::vector<double>>& input) {
    for (auto& point : input) {
        if (point.size() >= 2) {
            std::swap(point[0], point[1]); // Swap x and y values in place
        } else {
            std::cout << "Invalid point in the input vector. Skipping." << std::endl;
        }
    }
}
// 样条插值通常需要x坐标是递增的。这是因为样条插值的基本假设是，x坐标是单调递增的。如果x坐标不是递增的，样条插值可能会导致结果的不确定性或不连续性。
// 参数化样条插值。这种方法是将x和y坐标都作为参数的函数来处理
std::vector<std::vector<double>> ParametricSplineInterpolation(const std::vector<std::vector<double>>& path2) {

	 std::vector<std::vector<double>> path;
       path  = path2;
    	// if((maxX-minX)<(maxY-minY)){
		// 			swapXAndY(path);
		// 			// swapXAndY(obstacle_circle);
		// 		}


    std::vector<double> x;
    std::vector<double> y;
    std::vector<double> t;  // parameter

    double accumulated_distance = 0.0;
    t.push_back(accumulated_distance); // start with 0
	x.push_back(path[0][0]);
	y.push_back(path[0][1]);
    for (size_t i = 1; i < path.size(); ++i) {
        x.push_back(path[i][0]);
        y.push_back(path[i][1]);

        double dx = path[i][0] - path[i - 1][0];
        double dy = path[i][1] - path[i - 1][1];

        accumulated_distance += std::sqrt(dx * dx + dy * dy);
        t.push_back(accumulated_distance);
    }
    gsl_interp_accel* accel = gsl_interp_accel_alloc();
    gsl_spline* splineX = gsl_spline_alloc(gsl_interp_cspline, path.size());
    gsl_spline* splineY = gsl_spline_alloc(gsl_interp_cspline, path.size());

    gsl_spline_init(splineX, t.data(), x.data(), path.size());
    gsl_spline_init(splineY, t.data(), y.data(), path.size());

    std::vector<std::vector<double>> interpolatedPath;

    double prevX = x.front();
    double prevY = y.front();
    double distanceTraced = 0.0;

    for (double param = t.front(); param <= t.back(); param += step) {
        double interpolatedX = gsl_spline_eval(splineX, param, accel);
        double interpolatedY = gsl_spline_eval(splineY, param, accel);

        double dx = interpolatedX - prevX;
        double dy = interpolatedY - prevY;
        double yaw = std::atan2(dy, dx);

        double ddx = gsl_spline_eval_deriv(splineX, param, accel);
        double ddy = gsl_spline_eval_deriv(splineY, param, accel);
				
		double ddx2 = gsl_spline_eval_deriv2(splineX, param, accel);
		double ddy2 = gsl_spline_eval_deriv2(splineY, param, accel);

		double numerator = ddy2 * ddx - ddx2 * ddy;
		double denominator = std::pow(ddx * ddx + ddy * ddy, 1.5);
		double curvature = numerator / denominator;
        // double curvature = std::abs(ddy / (std::pow(1 + std::pow(ddx, 2), 1.5)));

        distanceTraced += std::sqrt(std::pow(dx,2)+std::pow(dy,2));
        
        interpolatedPath.push_back({ interpolatedX, interpolatedY, yaw, curvature, distanceTraced });

        prevX = interpolatedX;
        prevY = interpolatedY;
    }

    gsl_spline_free(splineX);
    gsl_spline_free(splineY);
    gsl_interp_accel_free(accel);

    return interpolatedPath;
}
//////解决行航向角在正负π之间的断点问题
double normalize_angle(double angle) {
    while (angle > M_PI) angle -= 2.0 * M_PI;
    while (angle < -M_PI) angle += 2.0 * M_PI;
    return angle;
}
int jishu = 0;
void OptimalTrajectoryPlanner::convertToWorldFrame(std::vector<FrenetPath> &paths, std::vector<std::vector<double>> &centerLane){
	for(FrenetPath &path:paths){
		jishu++;
		// Calculate x, y in world frame 在世界坐标系中计算x, y
		int j = 0;
		for(int i =0; i<path.s.size(); i++){
			double x = 0, y = 0, yaw = -22;
			// double x , y , yaw ;

			for(; j<centerLane.size(); j++){
				////以距离判断到哪里
				if(std::abs(path.s[i][0]-centerLane[j][4])<=0.01){
					// std::cout<< "找到了初始点111  "<< "x=  "<< centerLane[j][0] << " y=  "<< centerLane[j][1] << std::endl;

					x = centerLane[j][0]- minX;
					y = centerLane[j][1]- minY;

					// 	x = centerLane[j][0];
					// y = centerLane[j][1];
					yaw = centerLane[j][2];
					// std::cout<< "找到了初始点  "<< "x=  "<< x << " y=  "<< y << std::endl;
					// std::cout<< "i=  "<< i <<std::endl;
					// std::cout<< "path.s[i][0]=  "<< path.s[i][0] <<std::endl;
					// std::cout<< "j=  "<< j <<std::endl;
					// std::cout<< "centerLane[j][4]=  "<< centerLane[j][4] <<std::endl;
					// std::cout<< "centerLane[j][0]=  "<< centerLane[j][0] <<std::endl;
					// std::cout<< "========  " <<std::endl;
					break;
				}
				//  double x = x + path.s[i][0] * std::cos(initYaw + M_PI / 2.0);
    			//  double y = y + path.s[i][0] * std::sin(initYaw + M_PI / 2.0);
			}
			if(x == 0 && y == 0 && yaw == -22){
                std::cout<< "没有找到最近点  "<< path.s[i][0]<<std::endl;

			    while (ros::ok())
				{
					// std::cout<< "没有找到最近点  "<< path.s[i][0]<<std::endl;
					// std::cout<< "i=  "<< i <<std::endl;
                    std::this_thread::sleep_for(std::chrono::seconds(1));
				}
			 }
			// for(int k =i*(0.1/timeStep_); k<i*(0.1/timeStep_)+(0.1/timeStep_); k++){

				double d = path.d[i][0];
				///x  y 的计算
				// if(jishu == 1)
				// std::cout<< "d  "<< path.d[k][0]<<std::endl;
				// if(jishu == 1)
				// while (ros::ok()){
				// }
                
				path.world.push_back({x + d * std::cos(yaw + 1.57), y + d * std::sin(yaw + 1.57), 0, 0});
			// }
			   
			// path.world.push_back({x + d * std::cos(yaw), y + d * std::sin(yaw ), 0, 0});
		}
		// if(jishu == 20)
		// 	while (ros::ok()){
		// }
		// std::cout<< "全局坐标点数  "<< path.world.size()<<std::endl;

		// for (int i = 0; i < path.world.size(); i++) {
		//  path.world[i][0] -= minX;
		//  path.world[i][1] -= minY;
		// }
		// 在世界框架中计算偏航
		for(int i = 0; i<path.world.size()-1; i++){
			path.world[i][2] = std::atan2((path.world[i+1][1]-path.world[i][1]), (path.world[i+1][0]-path.world[i][0])); 
			//点与点之间的距离
			path.world[i][3] = std::sqrt(std::pow(path.world[i+1][0]-path.world[i][0],2)+std::pow(path.world[i+1][1]-path.world[i][1],2)); 
		}
		path.world[path.world.size()-1][2]= path.world[path.world.size()-2][2];
		path.world[path.world.size()-1][3]= path.world[path.world.size()-2][3];

		// 计算轨迹的最大曲率
		double curvature = 0;
		// for (size_t i = 0; i < paths.size() - 1; i++) { // -1 to avoid accessing out of bounds
		// 	double delta_yaw = normalize_angle(paths[i+1][2] - paths[i][2]);
			
		// 	// First and second derivatives
		// 	double ddx = paths[i+1][0] - paths[i][0];
		// 	double ddy = paths[i+1][1] - paths[i][1];
		// 	double ddx2 = paths[i+2][0] - 2*paths[i+1][0] + paths[i][0];
		// 	double ddy2 = paths[i+2][1] - 2*paths[i+1][1] + paths[i][1];
			
		// 	// Curvature computation using parametric spline interpolation
		// 	double numerator = ddy2 * ddx - ddx2 * ddy;
		// 	double denominator = std::pow(ddx * ddx + ddy * ddy, 1.5);
		// 	double curvature = numerator / denominator;
			
		// 	paths[i][4] = curvature; // Assuming the 5th entry in your path vector stores curvature
				// }
			// std::vector<double> x;
			// std::vector<double> y;
			// std::vector<double> t;  // parameter
			// double accumulated_distance = 0.0;

			// t.push_back(accumulated_distance); // start with 0
			// x.push_back( path.world[0][0]);
			// y.push_back( path.world[0][1]);
			// for (size_t i = 1; i < path.world.size(); ++i) {
			// 	x.push_back( path.world[i][0]);
			// 	y.push_back( path.world[i][1]);

			// 	double dx =  path.world[i][0] -  path.world[i - 1][0];
			// 	double dy =  path.world[i][1] -  path.world[i - 1][1];

			// 	accumulated_distance += std::sqrt(dx * dx + dy * dy);
			// 	t.push_back(accumulated_distance);
			// }
			// gsl_interp_accel* accel = gsl_interp_accel_alloc();
			// gsl_spline* splineX = gsl_spline_alloc(gsl_interp_cspline,  path.world.size());
			// gsl_spline* splineY = gsl_spline_alloc(gsl_interp_cspline,  path.world.size());

			// gsl_spline_init(splineX, t.data(), x.data(),  path.world.size());
			// gsl_spline_init(splineY, t.data(), y.data(),  path.world.size());

			// double prevX = x.front();
			// double prevY = y.front();

			// for (double param = t.front(); param <= t.back(); param += step) {
			// 	double interpolatedX = gsl_spline_eval(splineX, param, accel);
			// 	double interpolatedY = gsl_spline_eval(splineY, param, accel);

			// 	double dx = interpolatedX - prevX;
			// 	double dy = interpolatedY - prevY;
			// 	double ddx = gsl_spline_eval_deriv(splineX, param, accel);
			// 	double ddy = gsl_spline_eval_deriv(splineY, param, accel);
			// 	double ddx2 = gsl_spline_eval_deriv2(splineX, param, accel);
			// 	double ddy2 = gsl_spline_eval_deriv2(splineY, param, accel);

			// 	double numerator = ddy2 * ddx - ddx2 * ddy;
			// 	double denominator = std::pow(ddx * ddx + ddy * ddy, 1.5);
			// 	double tempCurvature = numerator / denominator;
        // double curvature = std::abs(ddy / (std::pow(1 + std::pow(ddx, 2), 1.5)));
		// double curvature = ddy / (std::pow(1 + std::pow(ddx, 2), 1.5));
		  std::vector<std::vector<double>> centerLane_cur;
				// if((maxX-minX)<(maxY-minY)){
				// 	swapXAndY(centerLane);
				// 	// swapXAndY(obstacle_circle);
				// }
			//   std::vector<std::vector<double>> centerLane_cur2{{692977.9457, 4048374.9785}, {692977.9557,4048374.8985}, { 692977.9757, 4048374.7985} };
   
	         centerLane_cur = ParametricSplineInterpolation( path.world);
			 	//  centerLane_cur = ParametricSplineInterpolation( centerLane_cur2);

			 	for (int i =1; i < centerLane_cur.size(); i++){
		          if(abs(curvature)< abs(centerLane_cur[i][3]))
					 curvature= centerLane_cur[i][3];
				}
          	// 	if(abs(curvature) >=0){
			// 	// if(jishu >7){
			// 	for (int i =0; i < centerLane_cur.size(); i++){
		    //      		std::cout<< "tempCurvature  "<< std::fixed<< i<< "  "<< centerLane_cur[i][3]<< std::endl;

			// 	}
   			// 		 OptimalTrajectoryPlanner otp;
			// 	for (int i = 0; i < path.world.size(); i++) {
			// 			path.world[i][0] += minX;
			// 			path.world[i][1] += minY;
			// 			std::cout<< "xy  "<< std::fixed<< i<< "  "<<path.world[i][0]<<"   "<<path.world[i][1] << std::endl;

			// 		}

			// 		while (ros::ok()){

			// 				for(int i{1}; i< path.world.size(); i++){
			// 				// cv::line(lane, windowOffset(p.world[i-1][0], p.world[i-1][1], lane.cols, lane.rows), windowOffset(p.world[i][0], p.world[i][1], lane.cols, lane.rows), cv::Scalar(0, 255, 0), 30);
			// 				cv::circle(lane, otp.windowOffset( path.world[i-1][0], path.world[i-1][1], lane.cols, lane.rows), 15, cv::Scalar(0, 255, 0), -1);
			// 			}
			// 				cv::resizeWindow("Optimal Trajectory Planner", 1050,600);
			// 					///开启显示
			// 					cv::imshow("Optimal Trajectory Planner", lane);
			// 					cv::waitKey(1);
			// 			sleep(1);

			// 		}
			// }


				// if(curvature< abs(tempCurvature))
				// curvature= abs(tempCurvature);

		// for(int i = 0; i<path.world.size()-2; i++){
		// 	double delta_yaw = normalize_angle(path.world[i+1][2] - path.world[i][2]);
		// 	double ddx = path.world[i+1][0] - path.world[i][0];
		// 	double ddy = path.world[i+1][1] - path.world[i][1];
		// 	double ddx2 = path.world[i+2][0] - 2*path.world[i+1][0] + path.world[i][0];
		// 	double ddy2 = path.world[i+2][1] - 2*path.world[i+1][1] + path.world[i][1];
		// 	double numerator = ddy2 * ddx - ddx2 * ddy;
		// 	double denominator = std::pow(ddx * ddx + ddy * ddy, 1.5);
		// 	double tempCurvature = numerator / denominator;

		// 	// double tempCurvature = abs(delta_yaw / path.world[i][3]);
		// 	// double tempCurvature = abs((path.world[i+1][2]-path.world[i][2])/(path.world[i][3]));
		// 	//path.world[i][4] = tempCurvature;
		// 	if(tempCurvature > 1){
		// 		std::cout<< "tempCurvature  "<<tempCurvature<<std::endl;
		// 		std::cout<< "tempCurvature  "<< std::fixed<< i<< "  "<< path.world[i+1][2]<< "   "<< path.world[i][2]<< "  "<< path.world[i][3]<< "  "<<tempCurvature<<std::endl;
		// 		std::cout<< "dis     "<< std::fixed<< path.world[i+1][0]<< "   "<< path.world[i][0]<< "  "<< path.world[i+1][1]<< "  "<<path.world[i][1]<<std::endl;
		// 		std::cout<< "numerator     "<< std::fixed<<numerator<< "    "<< denominator<<std::endl;

		// 			while (ros::ok()){
		// 			}
		// 	}
		// }
		for (int i = 0; i < path.world.size(); i++) {
		 path.world[i][0] += minX;
		 path.world[i][1] += minY;
		}
		path.maxCurvature=curvature;
		// path.maxCurvature=0;

	// std::cout<< "path.s.size()  "<< path.s.size()<<std::endl;
	// std::cout<< "path.d.size()  "<< path.d.size()<<std::endl;
	}
	std::cout<< "路径条数  "<< jishu<<std::endl;
	jishu = 0;
}


void parameter_read()
{
	FILE *file = NULL;
	file = fopen("/home/nvidia/Am_navigation_SHJ_ROS1/parameter.json", "r");
	if (file == NULL) 
	{
		std::cout <<"Open file parameter.json fail!"<< std::endl;
	}
	else
	{
		// 获得文件大小
		struct stat statbuf;
		stat("parameter.json", &statbuf);
		int fileSize = statbuf.st_size;
		std::cout <<"文件大小： "<< fileSize<<std::endl;

		// 分配符合文件大小的内存
		char *jsonStr = (char *)malloc(sizeof(char) * fileSize + 1);
		memset(jsonStr, 0, fileSize + 1);

		// 读取文件中的json字符串
		int size = fread(jsonStr, sizeof(char), fileSize, file);
		if (size == 0) {
			std::cout <<"读取文件parameter.json失败!"<< std::endl;
		}
		printf("%s", jsonStr);
		fclose(file);
		// 将读取到的json字符串转换成json变量指针
		cJSON *root = cJSON_Parse(jsonStr);
		cJSON *node = NULL;
		if (!root) 
		{
			const char *err = cJSON_GetErrorPtr();
		    std::cout <<"Error before: "<< err<<std::endl;
			free((void *)err);
			free(jsonStr);
			return;
		}
		node = cJSON_GetObjectItem(root,"step");   
		step = node->valuedouble;
		node = cJSON_GetObjectItem(root,"left_distance");   
		left_distance = node->valuedouble;
		node = cJSON_GetObjectItem(root,"right_distance");  
		right_distance = node->valuedouble;
		node = cJSON_GetObjectItem(root,"maxCurvature_");   
		maxCurvature_ = node->valuedouble;
        node = cJSON_GetObjectItem(root,"maxPredictionStep_");   
		maxPredictionStep_ = node->valuedouble;
		node = cJSON_GetObjectItem(root,"minPredictionStep_");   
		minPredictionStep_ = node->valuedouble;
		node = cJSON_GetObjectItem(root,"noOfLanes_");  
		noOfLanes_ = node->valuedouble;
		node = cJSON_GetObjectItem(root,"laneWidth_");   
		laneWidth_ = node->valuedouble;

		node = cJSON_GetObjectItem(root,"targetVelocity_");   
		targetVelocity_ = node->valuedouble;
		node = cJSON_GetObjectItem(root,"velocityStep_");  
		velocityStep_ = node->valuedouble;
		node = cJSON_GetObjectItem(root,"timeStep_");  
		timeStep_ = node->valuedouble;
		std::cout <<"maxCurvature_ maxPredictionStep_  minPredictionStep_ "<< maxCurvature_<<" " << maxPredictionStep_<<" "<< minPredictionStep_<<std::endl;

		// node = cJSON_GetObjectItem(root,"outputfilename");  
		// outputsetfilename = node->valuestring;
		node = cJSON_GetObjectItem(root,"output_imagefilename");  
		output_imagefilename = node->valuestring;
		node = cJSON_GetObjectItem(root,"gaussdatafilename");  
		gaussdatafilename = node->valuestring;
		node = cJSON_GetObjectItem(root,"obstaclefilename");  
		obstaclefilename = node->valuestring;
		node = cJSON_GetObjectItem(root,"departure_return");  
		departure_return = node->valuestring;
		std::cout <<"step left_distance  right_distance "<< step<<" " << left_distance<<" "<< right_distance<<std::endl;
		std::cout <<"outputsetfilename "<< outputsetfilename<<std::endl;
		std::cout <<"output_imagefilename "<< output_imagefilename<<std::endl;
		std::cout <<"gaussdatafilename "<< gaussdatafilename<<std::endl;
		std::cout <<"obstaclefilename "<< obstaclefilename<<std::endl;
		std::cout <<"departure_return "<< departure_return<<std::endl;

		if(step == 0)
		   std::cout <<"step为0"<< std::endl;

		free(jsonStr);
	}
}
///障碍物点的坐标  可自由增加障碍物
// std::vector<std::vector<double>> obstacles = {{693165.97,4048958.88} ,{693138.99, 4048959.38}};
// std::vector<std::vector<double>> obstacles = {{60, 4.93},  {94.42,-4}};
void readobstacleFromFile(const std::string& filename, std::vector<std::vector<double>>& obstacle_circle, std::vector<std::vector<double>>& obstacle_rectangle) {
    // 清空path，以便重新填充
    obstacle_circle.clear();
    obstacle_rectangle.clear();
    std::ifstream file(filename);
    if (!file.is_open()) {
        std::cerr << "Error: Unable to open file " << filename << std::endl;
        return;
    }
    // 设置流的区域设置，使用点号作为小数点分隔符
    file.imbue(std::locale("C"));

    std::string line;
    int lineCount = 1;
    while (std::getline(file, line)) {
        if (!line.empty() && line.back() == '\n') {
            line.pop_back();
        }

        if (line.empty()) {
            std::cerr << "Warning: Empty line in file at line " << lineCount << std::endl;
            continue;
        }

        std::istringstream iss(line);
        double x = 0.0, y = 0.0;
        std::vector<double> points;

        while (iss >> x >> y) {
            points.push_back(x);
            points.push_back(y);
        }

        if (points.size() == 2) {
		    std::cerr << "obstacle_circle x y " << lineCount << ": " << line <<": " << x <<": " << y << std::endl;
            obstacle_circle.push_back(points);
        } else if (points.size() == 8) {
			std::cerr << "obstacle_rectangle x y " << lineCount << ": " << line <<": " << x <<": " << y << std::endl;
            obstacle_rectangle.push_back(points);
        } else {
            std::cerr << "Error: Invalid data format in line " << lineCount << ": " << line << std::endl;
        }

        lineCount++;
    }

    file.close();
}


void coordinateScaling(int image_width, int image_height) {
    double path_width = maxX - minX;
    double path_height = maxY - minY;
	std::cout <<"path_width = " << std::fixed<< std::setprecision(4) <<path_width <<"path_height = " <<path_height<<std::endl;

    bili_X = (image_width/path_width)*0.9;
    bili_Y = (image_height/path_height)*0.9;
	std::cout <<"bili_X = " << std::fixed<< std::setprecision(4) <<bili_X <<"  bili_Y = "<< bili_Y<<std::endl;
    //  printf("path_height = %lf\n",path_height);
    if(bili_X > bili_Y)
       bili_X = bili_Y;
}

//作用是将给定的 (x, y) 坐标映射到图像窗口中的像素坐标。
cv::Point2i OptimalTrajectoryPlanner::windowOffset(float x, float y, int image_width=2000, int image_height=2000){
  cv::Point2i output;
//   output.x = int(x * 90) + 300;
//   output.y = image_height - int(y * 100) - image_height/2;
	// if((maxX-minX)<(maxY-minY)){
	// 	output.x = int(((x-minY)* bili_X) )+300;
    // 	output.y = image_height - int((y- minX)* bili_X*0.5) - image_height/2;
	// }
	// else{
		output.x = int((x-minX) * bili_X)+300;
   		output.y = image_height - int((y- minY)* bili_X*0.5) - image_height/2;
	// }
	
	// output.x = int((x) * bili_X)+300;
    // output.y = image_height - int((y)* bili_X*0.5) - image_height/2;
	// std::cout <<"output.x = "<< std::fixed<< output.x <<"   output.y = "<< output.y<<std::endl;
	if(output.x < 0||output.y < 0){
		std::cout <<"x = "<< std::fixed<< x <<"   y = "<< y<<std::endl;
		std::cout <<"minY = "<< std::fixed<< minY <<"   minX = "<< minX<<std::endl;
	}
  return output;
}

Eigen::Vector2d OptimalTrajectoryPlanner::rotation(double theta, double x, double y){
	Eigen::Matrix2d rotationZ;
	rotationZ << std::cos(theta), -1*std::sin(theta),
							 std::sin(theta), std::cos(theta);
	Eigen::Vector2d point;
	point << x, y;
	return rotationZ*point;
}

std::vector<std::vector<double>> CubicSplineInterpolation2(const std::vector<std::vector<double>>& path) {
    // 取出x和y值
	std::vector<double> x;
    std::vector<double> y;
    for (const auto& point : path) {
        x.push_back(point[0]);
        y.push_back(point[1]);
    }
    // 对x值进行排序并去除重复点
	std::sort(x.begin(), x.end());
	auto last = std::unique(x.begin(), x.end());
	x.erase(last, x.end());


    // 初始化gsl_interp_accel和gsl_spline
    gsl_interp_accel* accel = gsl_interp_accel_alloc();
    gsl_spline* spline = gsl_spline_alloc(gsl_interp_cspline, path.size());

    // 进行三次样条插值
    gsl_spline_init(spline, x.data(), y.data(), path.size());

    // 设置插值的细腻度
    const double step = 0.1;

    // 生成插值点
    std::vector<std::vector<double>> interpolatedPath;
    double distanceTraced = 0.0;
    double prevX = x.front();
    double prevY = y.front();
    for (double point = x.front(); point <= x.back(); point += step) {
        double interpolatedY = gsl_spline_eval(spline, point, accel);

        // 计算曲率和距离
        // double dx = point - prevX;
        double dy = interpolatedY - prevY;
	    double yaw = dy;

        double ddy = gsl_spline_eval_deriv2(spline, point, accel);
        double curvature = std::abs(ddy) / std::pow(1 + std::pow(dy, 2), 1.5);
        // distanceTraced += std::sqrt(dx * dx + dy * dy);
	    distanceTraced += std::sqrt(std::pow(point-prevX,2)+std::pow(interpolatedY-prevY,2));
		// std::cout << "每回合  "<< std::sqrt(std::pow(point-prevX,2)+std::pow(interpolatedY-prevY,2))<< std::endl;

        interpolatedPath.push_back({ point, interpolatedY, yaw, curvature, distanceTraced });

        prevX = point;
        prevY = interpolatedY;
    }

    // 释放内存
    gsl_spline_free(spline);
    gsl_interp_accel_free(accel);

    return interpolatedPath;
}

void readDataFromFile(const std::string& filename, std::vector<std::vector<double>>& centerLane) {
    // 清空centerLane，以便重新填充
    centerLane.clear();

    std::ifstream file(filename);
    if (!file.is_open()) {
        std::cerr << "Error: Unable to open file " << filename << std::endl;
        return;
    }

    std::string line;
    bool isFirstLine = true; // 标志变量，用于跳过第一行
    while (std::getline(file, line)) {
        if (!line.empty() && line.back() == '\n') {
            line.pop_back();
        }

        if (line.empty()) {
            std::cerr << "Warning: Empty line in file" << std::endl;
            continue;
        }

        if (isFirstLine) {
            isFirstLine = false;
            continue; // 跳过第一行
        }

        std::istringstream iss(line);
        double x, y, yaw_read, curvature_read, distance_read,z;
        char comma;

        // 读取指定列的数据，根据描述，x为第一列，y为第二列，yaw为第九列，curvature为第六列，distance为第十一列
        for (int i = 1; i <= 11; i++) {
            if (i == 1) {
                if (!(iss >> x)) {
                    std::cerr << "Error1: Invalid data format in line: " << line << std::endl;
                    break;
                }
            } else if (i == 2) {
                if (!(iss >> comma >> y)) {
                    std::cerr << "Error2: Invalid data format in line: " << line << std::endl;
                    break;
                }
            }else if (i == 3) {
                if (!(iss >>  comma>> z)) {
                    std::cerr << "Error3: Invalid data format in line: " << line << std::endl;
                    break;
                } 
			}else if (i == 6) {
				if (!(iss >> comma >> comma >> curvature_read)) {
					std::cerr << "Error5: Invalid data format in line: " << line << std::endl;
					break;
				}
			} else if (i == 9) {
                if (!(iss >>   comma>>  yaw_read)) {
                    std::cerr << "Error4: Invalid data format in line: " << line << std::endl;
                    break;
                }
            
			} else if (i == 11) {
				if (!(iss  >> comma >> distance_read)) {
					std::cerr << "Erro6: Invalid data format in line: " << line << std::endl;
					break;
				}
			} else {
                // For other columns, skip their values by using a temporary variable
                double temp;
                if (!(iss >> comma >> temp)) {
                    std::cerr << "Error7: Invalid data format in line: " << line << std::endl;
                    break;
                }
            }
        }

        // 在读取完成后，将数据添加到centerLane中
        centerLane.push_back({x, y, yaw_read, curvature_read, distance_read});
		// std::cout << "x               "<<std::fixed<<  x<< std::endl;
		// std::cout << "y               "<< std::fixed<< y<< std::endl;
		// std::cout << "z               "<< std::fixed<< z<< std::endl;
		// std::cout << "yaw_read        "<<std::fixed<<  yaw_read<< std::endl;
		// std::cout << "curvature_read  "<<std::fixed<<  curvature_read<< std::endl;
		// std::cout << "distance_read   "<<std::fixed<<  distance_read<< std::endl;
    }

    file.close();
}

std::vector<std::vector<double>> GetRoadBoundary(const std::vector<std::vector<double>>& path, double width_l, double width_r) {
    std::vector<std::vector<double>> roadBoundary;

    for (const auto& point : path) {
        double x = point[0];
        double y = point[1];
        double yaw = point[2];

        // 计算左侧的边界
        double leftX = x + width_l * sin(yaw);
        double leftY = y - width_l * cos(yaw);
        // roadBoundary.push_back({leftX, leftY});

        // 计算右侧的边界
        double rightX = x - width_r * sin(yaw);
        double rightY = y + width_r * cos(yaw);
        roadBoundary.push_back({leftX, leftY,rightX, rightY});
    }

    return roadBoundary;
}
class DataPublisher {
public:
    DataPublisher() {
        pub_ = nh_.advertise<frenet_cpp::CustomMsg>("planner_topic2222", 1000);  // 将 "data_topic" 替换为你想要的话题名
    }

    void publishData(double x, double y, double yaw, double curvature, double distance,double time) {
        frenet_cpp::CustomMsg msg;
        msg.x = x;
        msg.y = y;
        msg.heading = yaw;
        msg.curvature = curvature;
        msg.distance = distance;
		msg.time = time;
		msg.speed = 1;
		msg.gear = 1;

        pub_.publish(msg);
        ros::spinOnce();  // 确保消息被发送
    }

private:
    ros::NodeHandle nh_;
    ros::Publisher pub_;
};


struct Point {
    double x, y;
    Point(double x, double y) : x(x), y(y) {}
};

double distance(const Point& a, const Point& b) {
    return std::sqrt(std::pow(a.x - b.x, 2) + std::pow(a.y - b.y, 2));
}

std::pair<double, double> toFrenet(const Point& position, const std::vector<Point>& centerLane1) {
    double s = 0;
    double d = 0;
    double min_dist = std::numeric_limits<double>::max();
    Point closest_point(0.0, 0.0);
    int closest_idx = -1;

    // Find closest point and its index on the reference path
    for (int i = 0; i < centerLane1.size(); i++) {
        double dist = distance(position, centerLane1[i]);
        if (dist < min_dist) {
            min_dist = dist;
            closest_point = centerLane1[i];
            closest_idx = i;
        }
    }

    // Calculate s (cumulative distance along reference path)
    // for (int i = 0; i < closest_idx; i++) {
    //     s += distance(centerLane1[i], centerLane1[i+1]);
    // }
    // s += distance(centerLane1[closest_idx], position);
         s =  centerLane[closest_idx] [4];      
    // Calculate d (perpendicular distance from reference path)
    if (closest_idx > 0) {
        const Point& prev = centerLane1[closest_idx - 1];
        const Point& curr = centerLane1[closest_idx];
        double diff_x = curr.x - prev.x;
        double diff_y = curr.y - prev.y;
        double norm = std::sqrt(diff_x * diff_x + diff_y * diff_y);
        double dx = -diff_y / norm;
        double dy = diff_x / norm;

        d = dx * (position.x - curr.x) + dy * (position.y - curr.y);
    }

    return {s, d};
}

int planner_sign = 0;


struct SpeedComponents {
    double longitudinal_speed; // 纵向速度
    double lateral_speed;     // 横向速度
};
SpeedComponents calculateRelativeSpeeds(double theta_reference, double v, double theta_vehicle) {
    SpeedComponents result;

    double angle_difference = theta_vehicle - theta_reference;

    // 计算横向速度
    result.lateral_speed = v * cos(angle_difference);
    // 计算纵向速度
    result.longitudinal_speed = v * sin(angle_difference);

    return result;
}
double obstacle_dis_old[4] = {20,20,20,20};
void Planner_manage(double x_cur,double y_cur,double heading,double v){
    Point position(10, 1);
    position.x = x_cur;
	position.y = y_cur;
    double d0 = 0;   ///初始位置
	double dv0 = 0;
	double da0 = 0;
	double s0 = 0;
	double sv0 = 1;
	double x = 0;
	double y = 0;
	double theta_reference = 0;
	// DataPublisher publisher;
    OptimalTrajectoryPlanner otp;
   heading = heading/180.0*3.14;
   	Global_heading = heading;

	std::vector<Point> centerLaneData;
	for (const auto& dataPoint : centerLane) {
		centerLaneData.push_back(Point(dataPoint[0], dataPoint[1]));
	}
	for(int j = 0; j<obstacle_circle.size(); j++){
		// obstacle_dis_array[2] = obstacle_dis_array[1];
		// obstacle_dis_array[1] = obstacle_dis_array[0];
		// obstacle_dis_array[0]= std::sqrt(std::pow(x_cur-obstacle_circle[j][0],2)+std::pow( y_cur-obstacle_circle[j][1],2));
       if(std::sqrt(std::pow(x_cur-obstacle_circle[j][0],2)+std::pow( y_cur-obstacle_circle[j][1],2)) >10)
	   continue;

		if(std::sqrt(std::pow(x_cur-obstacle_circle[j][0],2)+std::pow( y_cur-obstacle_circle[j][1],2)) <= 10 &&(obstacle_dis_old[j]>std::sqrt(std::pow(x_cur-obstacle_circle[j][0],2)+std::pow( y_cur-obstacle_circle[j][1],2)) ) ){
			obstacle_dis_flag = 1;
				std::cout << "初始点接近障碍物       "<<  obstacle_dis_old[j] << "     当前距离  " <<std::sqrt(std::pow(x_cur-obstacle_circle[j][0],2)+std::pow( y_cur-obstacle_circle[j][1],2))<< std::endl;
		}
		else
		obstacle_dis_flag = 0;
		std::cout << "  数据     "<<  obstacle_dis_old[j] << "     当前距离  " <<std::sqrt(std::pow(x_cur-obstacle_circle[j][0],2)+std::pow( y_cur-obstacle_circle[j][1],2))<< std::endl;

		 obstacle_dis_old[j]= std::sqrt(std::pow(x_cur-obstacle_circle[j][0],2)+std::pow( y_cur-obstacle_circle[j][1],2));
	}
	auto [s_cur, d_cur] = toFrenet(position, centerLaneData);
	std::cout << "s_cur: " << s_cur << ", d_cur: " << d_cur << std::endl;
	s0  = s_cur;
	d0 = d_cur;
    
    ///拆解横纵向速度分量
	for(int j = 0; j<centerLane.size(); j++){
		if(std::abs(s0-centerLane[j][4])<=0.02){
		    theta_reference = centerLane[j][2];
			break;
		}
	}
	v = 1;
    SpeedComponents speeds = calculateRelativeSpeeds(theta_reference, v, heading);
    sv0 = speeds.lateral_speed;   //横
	dv0 = speeds.longitudinal_speed;  //纵
	std::cout << "sv0: " << sv0 << ", dv0: " << dv0 << ", theta_reference: " << theta_reference << ", heading: " << heading<< std::endl;

	//获得最佳轨迹
	std::vector<FrenetPath> allPaths;
	std::chrono::system_clock::time_point lp_start, lp_end;
	lp_start = std::chrono::system_clock::now();   ////开始时间计算
	FrenetPath p = otp.optimalTrajectory(d0, dv0, da0, s0, sv0, centerLane, obstacle_circle,obstacle_rectangle, allPaths);
	// for (int i = 0; i < p.world.size(); i++) {
	//  p.world[i][0] += minX;
	//  p.world[i][1] += minY;
	// }
	lp_end = std::chrono::system_clock::now();   ////终止时间计算
	double lp_elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(lp_end-lp_start).count();
	std::cout << "Solver Calculation Time: " << lp_elapsed << "[ms]" << std::endl;
	// d0 = p.d[p.d.size()-1][0];
	// std::cout << "d0 data " << d0<< std::endl;
	// dv0 = p.d[p.d.size()-1][1];
	// std::cout << "p.d.size()-1  " << p.d.size()-1<< std::endl;
	// da0 = p.d[p.s.size()-1][2];
	// s0 = p.s[p.s.size()-1][0];
	// std::cout << "p.s.size()-1  " << p.s.size()-1<< std::endl;

	// sv0 = p.s[p.s.size()-1][1];
	x = p.world[p.world.size()-1][0];
	y = p.world[p.world.size()-1][1];
	// d0 = p.d[5][0];
	std::cout << "p.world.size()-1  " << p.world.size()-1<< std::endl;
	std::cout << "x " << x<< std::endl;
	std::cout << "y " << y<< std::endl;

	double tempCurvature = abs((p.world[9+1][2]-p.world[9][2])/(p.world[9][3]));
   		std::cout << "1"<<std::endl;

    ////进行拟合离散使其精度达到0.01
	centerLane_publish = ParametricSplineInterpolation(p.world);
   		std::cout << "2"<<std::endl;

    // double time = 0;
    // for(int i{0}; i<centerLane_publish.size(); i++){
	// 	publisher.publishData(centerLane_publish[i][0], centerLane_publish[i][1], centerLane_publish[i][2],centerLane_publish[i][3], centerLane_publish[i][4],time);
	// 	time+=0.01;
	// }
	double time = 0;
	common::Path path1;
	for (int i = 0; i < centerLane_publish.size(); i++)
	{
		common::Pathpoint point;
		point.x = centerLane_publish[i][0];  
		point.y = centerLane_publish[i][1];
		point.heading = centerLane_publish[i][2];  
		point.curvature = centerLane_publish[i][3];
		point.distance = centerLane_publish[i][4];
		point.time = time;
		point.v = 1;
		point.gear = 1;
		path1.path.push_back(point);
		time+=0.01;
	}
	pub.publish(path1);
	std::cout << "3"<<std::endl;
	frenet_cpp::ObstacleArray obs_output;
	for (int i = 0; i < obstacle_circle.size(); i++)
	{
		frenet_cpp::Obstaclepoint point_obs;
		point_obs.x = obstacle_circle[i][0];  
		point_obs.y = obstacle_circle[i][1];
		point_obs.r = 0.3;

		obs_output.obstaclepoint.push_back(point_obs);
	}
		pub_obs.publish(obs_output);

    ////发布话题
	// publisher.publishData(p.world[10][0], p.world[10][1], p.world[10][2], p.world[10][3], tempCurvature);
	// publisher.publishData(p.world[11][0], p.world[11][1], p.world[11][2], p.world[11][3], tempCurvature);

	//在目标范围内停止
	if(std::sqrt(std::pow(centerLane[centerLane.size()-1][0]-x,2)+std::pow(centerLane[centerLane.size()-1][1]-y,2))<=1){
		std::cout << "到达目标点" << dv0<< std::endl;
		while (ros::ok()){
		}
	}
		
	//All Trajectories 所有轨迹  other reference lane  &t 表示对 allPaths 中的每个元素进行引用  红
	int num_path = 0;
	for(FrenetPath &t:allPaths){
		if(num_path >=15)
		for(int i{1}; i<t.world.size(); i++){
			cv::line(lane, otp.windowOffset(t.world[i-1][0], t.world[i-1][1], lane.cols, lane.rows), otp.windowOffset(t.world[i][0], t.world[i][1], lane.cols, lane.rows), cv::Scalar(0, 0, 255), 5);
		}
		else
    	for(int i{1}; i<t.world.size(); i++){
			cv::line(lane, otp.windowOffset(t.world[i-1][0], t.world[i-1][1], lane.cols, lane.rows), otp.windowOffset(t.world[i][0], t.world[i][1], lane.cols, lane.rows), cv::Scalar(0, 0, 255), 5);
		}
		num_path++;
		if(num_path >=15)
		break;
	}

	// Trajectory 轨迹最优  绿
	for(int i{1}; i<p.world.size(); i++){
		// cv::line(lane, windowOffset(p.world[i-1][0], p.world[i-1][1], lane.cols, lane.rows), windowOffset(p.world[i][0], p.world[i][1], lane.cols, lane.rows), cv::Scalar(0, 255, 0), 30);
		cv::circle(lane, otp.windowOffset(p.world[i-1][0], p.world[i-1][1], lane.cols, lane.rows), 15, cv::Scalar(0, 255, 0), -1);
	}
	////起始点 蓝
	for(int i{1}; i<2; i++){   
		cv::circle(lane, otp.windowOffset(p.world[i-1][0], p.world[i-1][1], lane.cols, lane.rows), 30, cv::Scalar(255, 0, 0), -1);
	}
	std::cout << "p.world[p.world.size()-1][0]  " << p.world[p.world.size()-1][0]<< std::endl;
	std::cout << "p.world[p.world.size()-1][1]  " << p.world[p.world.size()-1][1]<< std::endl;
	std::cout << "p.world[i-1][0]  " << p.world[0][0]<< std::endl;
	std::cout << "p.world[i-1][1]  " << p.world[0][1]<< std::endl;

	////画布大小
	cv::resizeWindow("Optimal Trajectory Planner", 1050,600);
	///开启显示
	cv::imshow("Optimal Trajectory Planner", lane);
	cv::waitKey(1);
}



void poseInfoCallback(const common::Pose::ConstPtr& msg){
    // 将接收到的消息打印出来
	// ROS_INFO("Subcribe  Info: x:%lf  y:%lf heading:%lf v:%lf", msg->x, msg->y, msg->heading,msg->v);
	
	planner_sign ++;
	Global_x = msg->x;
	Global_y = msg->y;

	if(planner_sign>20){
		planner_sign = 0;	
		// if((maxX-minX)>(maxY-minY)){
			Planner_manage(msg->x, msg->y,msg->heading,msg->v);
		// }
		// else{
		// 	Planner_manage(msg->y, msg->x,msg->heading,msg->v);
		// }
		xuanzhuan_ceshi();
	}
}
class Point3D {
public:
    double x, y, z;
    Point3D(double _x, double _y, double _z) : x(_x), y(_y), z(_z) {}
};

// 航向角转旋转矩阵
Point3D RotateByYaw(double yaw, const Point3D& p) {
    double cos_yaw = cos(yaw);
    double sin_yaw = sin(yaw);

    return Point3D(
        cos_yaw * p.x - sin_yaw * p.y,
        sin_yaw * p.x + cos_yaw * p.y,
        p.z
    );
}
Point3D camera_offset(0, 0, 0);    // 相机相对车的坐标
Point3D obstacle_in_camera(0.1, 0.1, 1.1);// 相机检测到的障碍物相对相机的坐标
Point3D obstacle_in_car2(0.1, 0.1, 1.1);// 相机检测到的障碍物相对相机的坐标

Point3D obstacle_global(0,0,0);
void obstacleInfoCallback(const frenet_cpp::BoundingBox::ConstPtr& msg){
    // 将接收到的消息打印出来
	// ROS_INFO("Subcribe  Info: num:%d  Class:%s  posx:%lf  posy:%lf  posz:%lf", msg->num, msg->Class.c_str(), msg->posx,msg->posy,msg->posz);
	ROS_INFO("Subcribe  Info: num:%d  Class:%s ", msg->num, msg->Class.c_str());
    
    if(msg->Class == "person"){
   	 std::cout << msg->Class << std::endl;
    
	}
	else{

	}

	if(msg->num == 0){

	}
	else{
		ROS_INFO("obstacle posx:%lf  posy:%lf  posz:%lf", msg->posx,msg->posy,msg->posz);
		obstacle_in_camera.x = msg->posx;
		obstacle_in_camera.y = msg->posy;
		obstacle_in_camera.z = msg->posz;
		// obstacle_in_camera.setValues(msg->posx, msg->posy, msg->posz);
		if(Global_x !=0 && Global_y != 0){    /////判断已经有了自车的位置
			// 1. 转换障碍物的坐标到车辆坐标系
			Point3D obstacle_in_car = RotateByYaw(Global_heading, obstacle_in_camera);
			obstacle_in_car.x += camera_offset.x;
			obstacle_in_car.y += camera_offset.y;
			obstacle_in_car.z += camera_offset.z;

			// 2. 转换车辆坐标系的障碍物坐标到全局坐标
			// Point3D obstacle_global(
			// 	Global_x + obstacle_in_car.x,
			// 	Global_y + obstacle_in_car.y,
			// 	Global_z + obstacle_in_car.z
			// );
			obstacle_global.x = Global_x + obstacle_in_car.x;
			obstacle_global.y = Global_y + obstacle_in_car.y;
			obstacle_global.z = Global_z + obstacle_in_car.z;

			std::cout << "障碍物的全局坐标为: X=" << obstacle_global.x
				<< ", Y=" << obstacle_global.y
				<< ", Z=" << obstacle_global.z << std::endl;
		}	
	}
	// planner_sign ++;
	// if(planner_sign>10){
	// 	planner_sign = 0;
	// 	Planner_manage(msg->x, msg->y+2,msg->heading,msg->v);
	// }
}
void xuanzhuan_ceshi(){

       obstacle_in_camera.x =-0.293;
		obstacle_in_camera.y = 2.87;
		obstacle_in_camera.z =  8.21+1.4;
		obstacle_in_car2.x =  obstacle_in_camera.x;
		obstacle_in_car2.y =  obstacle_in_camera.z;
		obstacle_in_car2.z =   -obstacle_in_camera.y;
		// obstacle_in_camera.setValues(msg->posx, msg->posy, msg->posz);
		if(Global_x !=0 && Global_y != 0){    /////判断已经有了自车的位置
			// 1. 转换障碍物的坐标到车辆坐标系
			Point3D obstacle_in_car = RotateByYaw(Global_heading, obstacle_in_car2);
			// obstacle_in_car.x += camera_offset.x;
			// obstacle_in_car.y += camera_offset.y;
			// obstacle_in_car.z += camera_offset.z;
		std::cout << "obstacle_in_car: X=" << obstacle_in_car.x
				<< ", Y=" << obstacle_in_car.y
				<< ", Z=" << obstacle_in_car.z << std::endl;
			// 2. 转换车辆坐标系的障碍物坐标到全局坐标
		
			obstacle_global.x = Global_x+ obstacle_in_car.y;
			obstacle_global.y = Global_y - obstacle_in_car.x;
			obstacle_global.z = Global_z + obstacle_in_car.z;
	       std::cout << "Global: X=" <<Global_x
				<< ", Y=" << Global_y
				<< ", Z=" << Global_z << std::endl;
			std::cout << "障碍物的全局坐标为: X=" << obstacle_global.x
				<< ", Y=" << obstacle_global.y
				<< ", Z=" << obstacle_global.z << std::endl;
		}	
}

void OptimalTrajectoryPlanner::run(){

    DataPublisher publisher;
	ros::NodeHandle n;

	////配置参数读取
    parameter_read(); 
	//读取障碍物
    readobstacleFromFile(obstaclefilename,obstacle_circle,obstacle_rectangle);
    //输出读取障碍物的数据
    for (int i = 0; i < obstacle_circle.size(); i++) {
        std::cout << "obstacle_circle x: " << std::fixed<< obstacle_circle[i][0] << ", y: " << obstacle_circle[i][1] << std::endl;
    }
	for (int i = 0; i < obstacle_rectangle.size(); i++) {
        std::cout << "obstacle_rectangle : "<< std::fixed<< obstacle_rectangle[i][0] << ",  " << obstacle_rectangle[i][1]<< ",  "<< obstacle_rectangle[i][2] << std::endl;
    }
	std::cout << "obstacle_rectangle.size(): " << std::fixed<< obstacle_rectangle.size() << std::endl;
	//读参考线
    readDataFromFile(gaussdatafilename, centerLane);
	
    std::cout << "centerLane.size()  "<< centerLane.size()<< std::endl;
	for(int i{0}; i<10; i++){
    	std::cout << "s          "<<std::fixed<<  centerLane[i][0]<< std::endl;
		std::cout << "d          "<< std::fixed<< centerLane[i][1]<< std::endl;
		std::cout << "yaw        "<<std::fixed<<  centerLane[i][2]<< std::endl;
		std::cout << "curvature  "<<std::fixed<<  centerLane[i][3]<< std::endl;
		std::cout << "distance   "<<std::fixed<<  centerLane[i][4]<< std::endl;
		// std::cout << "heading   "<<std::fixed<<  centerLane[i][5]<< std::endl;

	}
	// while(1){
	// }
	// 遍历数组，找到最大值和最小值
 	maxX = centerLane[0][0];
	minX = centerLane[0][0];
	maxY = centerLane[0][1];
	minY = centerLane[0][1];
    for (const auto& point : centerLane){
        double x = point[0];
        double y = point[1];
        maxX = std::max(maxX, x);
        minX = std::min(minX, x);
        maxY = std::max(maxY, y);
        minY = std::min(minY, y);
    }
	std::cout << "最大的x值为: " << std::fixed<< maxX << std::endl;
    std::cout << "最小的x值为: " << std::fixed<< minX << std::endl;
    std::cout << "最大的y值为: " << std::fixed<< maxY << std::endl;
    std::cout << "最小的y值为: " << std::fixed<< minY << std::endl;

	// std::vector<std::vector<double>> swappedPath = swapXAndY(path);

	if((maxX-minX)<(maxY-minY)){
        swapXAndY(centerLane);
		// swapXAndY(obstacle_circle);
	}

	// visualize 可视化
	// 10000 是 lane 的行数，表示图像的高度。
	// 10500 是 lane 的列数，表示图像的宽度。
	// CV_8UC3 是 lane 的图像类型，其中 CV_8UC3 表示每个像素有 3 个 8 位无符号整数通道，分别表示蓝色、绿色和红色通道。
    // double cishu = 0;
	//窗口显示    WINDOW_NORMAL设置大小的 可以随意调整大小
	cv::namedWindow("Optimal Trajectory Planner", cv::WINDOW_NORMAL);
	// std::vector<std::vector<double>> roadBoundary;
    // roadBoundary = GetRoadBoundary(centerLane,left_distance,right_distance);
    // // // cv::Mat lane(10000, 10000, CV_8UC3, cv::Scalar(255, 255, 255));
	// coordinateScaling(lane.cols, lane.rows);

	// for(int i{1}; i<centerLane.size(); i++){
	// 	cv::line(lane, windowOffset(centerLane[i-1][0], centerLane[i-1][1], lane.cols, lane.rows), windowOffset(centerLane[i][0], centerLane[i][1], lane.cols, lane.rows), cv::Scalar(0, 0, 0), 10);
	// }
	// //运行轨迹规划器，直到感知/可用Lane数据结束
	// // 画参考线 cv::line 是 OpenCV 库提供的绘制线段的函数。 10 是线段的宽度，即线段在图像上的像素宽度。
	
	// for(int i{1}; i<roadBoundary.size(); i++){
	// 		cv::line(lane, windowOffset(roadBoundary[i-1][0], roadBoundary[i-1][1], lane.cols, lane.rows), windowOffset(roadBoundary[i][0], roadBoundary[i][1], lane.cols, lane.rows), cv::Scalar(0, 0, 0), 20);
	// }
	// for(int i{1}; i<roadBoundary.size(); i++){
	// 	cv::line(lane, windowOffset(roadBoundary[i-1][2], roadBoundary[i-1][3], lane.cols, lane.rows), windowOffset(roadBoundary[i][2], roadBoundary[i][3], lane.cols, lane.rows), cv::Scalar(0, 0, 0), 20);
	// }
	// //圆形障碍物
	// for(int i{0}; i<obstacle_circle.size(); i++){
	// 	cv::circle(lane, windowOffset(obstacle_circle[i][0], obstacle_circle[i][1], lane.cols, lane.rows), int(0.3*bili_X), cv::Scalar(0, 0, 255), -1);
	// }
	// //画矩形障碍物
	// for (int i{0}; i < obstacle_rectangle.size(); i++) {
	// 	cv::line(lane, windowOffset(obstacle_rectangle[i][0], obstacle_rectangle[i][1], lane.cols, lane.rows), windowOffset(obstacle_rectangle[i][2], obstacle_rectangle[i][3], lane.cols, lane.rows), cv::Scalar(0, 0, 255), 20);
	// 	cv::line(lane, windowOffset(obstacle_rectangle[i][2], obstacle_rectangle[i][3], lane.cols, lane.rows), windowOffset(obstacle_rectangle[i][4], obstacle_rectangle[i][5], lane.cols, lane.rows), cv::Scalar(0, 0, 255), 20);
	// 	cv::line(lane, windowOffset(obstacle_rectangle[i][4], obstacle_rectangle[i][5], lane.cols, lane.rows), windowOffset(obstacle_rectangle[i][6], obstacle_rectangle[i][7], lane.cols, lane.rows), cv::Scalar(0, 0, 255), 20);
	// 	cv::line(lane, windowOffset(obstacle_rectangle[i][6], obstacle_rectangle[i][7], lane.cols, lane.rows), windowOffset(obstacle_rectangle[i][0], obstacle_rectangle[i][1], lane.cols, lane.rows), cv::Scalar(0, 0, 255), 20);
	// }
		if((maxX-minX)<(maxY-minY)){
        swapXAndY(centerLane);
		// swapXAndY(obstacle_circle);
	}
	for(int i{1}; i<centerLane.size(); i++){
		cv::line(lane, windowOffset(centerLane[i-1][0], centerLane[i-1][1], lane.cols, lane.rows), windowOffset(centerLane[i][0], centerLane[i][1], lane.cols, lane.rows), cv::Scalar(0, 0, 0), 10);
	}
	//运行轨迹规划器，直到感知/可用Lane数据结束
	// 画参考线 cv::line 是 OpenCV 库提供的绘制线段的函数。 10 是线段的宽度，即线段在图像上的像素宽度。
		std::vector<std::vector<double>> roadBoundary;
    roadBoundary = GetRoadBoundary(centerLane,left_distance,right_distance);
    // // cv::Mat lane(10000, 10000, CV_8UC3, cv::Scalar(255, 255, 255));
	coordinateScaling(lane.cols, lane.rows);
	// for(int i{1}; i<roadBoundary.size(); i++){
	// 		cv::line(lane, windowOffset(roadBoundary[i-1][0], roadBoundary[i-1][1], lane.cols, lane.rows), windowOffset(roadBoundary[i][0], roadBoundary[i][1], lane.cols, lane.rows), cv::Scalar(0, 0, 0), 20);
	// }
	// for(int i{1}; i<roadBoundary.size(); i++){
	// 	cv::line(lane, windowOffset(roadBoundary[i-1][2], roadBoundary[i-1][3], lane.cols, lane.rows), windowOffset(roadBoundary[i][2], roadBoundary[i][3], lane.cols, lane.rows), cv::Scalar(0, 0, 0), 20);
	// }
	//圆形障碍物
	for(int i{0}; i<obstacle_circle.size(); i++){
		cv::circle(lane, windowOffset(obstacle_circle[i][0], obstacle_circle[i][1], lane.cols, lane.rows), int(0.3*bili_X), cv::Scalar(0, 0, 255), -1);
	}
	//画矩形障碍物
	for (int i{0}; i < obstacle_rectangle.size(); i++) {
		cv::line(lane, windowOffset(obstacle_rectangle[i][0], obstacle_rectangle[i][1], lane.cols, lane.rows), windowOffset(obstacle_rectangle[i][2], obstacle_rectangle[i][3], lane.cols, lane.rows), cv::Scalar(0, 0, 255), 20);
		cv::line(lane, windowOffset(obstacle_rectangle[i][2], obstacle_rectangle[i][3], lane.cols, lane.rows), windowOffset(obstacle_rectangle[i][4], obstacle_rectangle[i][5], lane.cols, lane.rows), cv::Scalar(0, 0, 255), 20);
		cv::line(lane, windowOffset(obstacle_rectangle[i][4], obstacle_rectangle[i][5], lane.cols, lane.rows), windowOffset(obstacle_rectangle[i][6], obstacle_rectangle[i][7], lane.cols, lane.rows), cv::Scalar(0, 0, 255), 20);
		cv::line(lane, windowOffset(obstacle_rectangle[i][6], obstacle_rectangle[i][7], lane.cols, lane.rows), windowOffset(obstacle_rectangle[i][0], obstacle_rectangle[i][1], lane.cols, lane.rows), cv::Scalar(0, 0, 255), 20);
	}
    // 创建一个Subscriber，订阅名为/pose的topic，注册回调函数poseInfoCallback
    ros::Subscriber pose_info_sub = n.subscribe("/pose", 1, poseInfoCallback);

	// 创建一个Subscriber，订阅名为/pose的topic，注册回调函数poseInfoCallback
	ros::Subscriber obstacle_info_sub = n.subscribe("/yolov5/BoundingBoxes", 1, obstacleInfoCallback);

	pub = n.advertise<common::Path>("plan", 1);

	pub_obs = n.advertise<frenet_cpp::ObstacleArray>("Obstacle", 1);

	while(ros::ok()){
		ros::spin();
	}
}