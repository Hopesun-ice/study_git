#include <iostream>
#include "location/serial.h"
#include <string.h>
#include "ros/ros.h"
#include "common/Pose.h"
#include "location/coorconv.h"
#include "common/common.h"

using namespace std;
void LonLat2UTM(double longitude, double latitude, double& UTME, double& UTMN)
{
	double lat = latitude;
	double lon = longitude;
    double PI = 3.1415926;
	double kD2R = PI / 180.0;
	double ZoneNumber = floor((lon - 1.5) / 3.0) + 1;
	double L0 = ZoneNumber * 3.0;

	double a = 6378137.0;
	double F = 298.257223563;
	double f = 1 / F;
	double b = a * (1 - f);
	double ee = (a * a - b * b) / (a * a);
	double e2 = (a * a - b * b) / (b * b);
	double n = (a - b) / (a + b); 
	double n2 = (n * n); 
	double n3 = (n2 * n); 
	double n4 = (n2 * n2); 
	double n5 = (n4 * n);
	double al = (a + b) * (1 + n2 / 4 + n4 / 64) / 2.0;
	double bt = -3 * n / 2 + 9 * n3 / 16 - 3 * n5 / 32.0;
	double gm = 15 * n2 / 16 - 15 * n4 / 32;
	double dt = -35 * n3 / 48 + 105 * n5 / 256;
	double ep = 315 * n4 / 512;
	double B = lat * kD2R;
	double L = lon * kD2R;
	L0 = L0 * kD2R;
	double l = L - L0; 
	double cl = (cos(B) * l); 
	double cl2 = (cl * cl); 
	double cl3 = (cl2 * cl); 
	double cl4 = (cl2 * cl2); 
	double cl5 = (cl4 * cl); 
	double cl6 = (cl5 * cl); 
	double cl7 = (cl6 * cl); 
	double cl8 = (cl4 * cl4);
	double lB = al * (B + bt * sin(2 * B) + gm * sin(4 * B) + dt * sin(6 * B) + ep * sin(8 * B));
	double t = tan(B); 
	double t2 = (t * t); 
	double t4 = (t2 * t2); 
	double t6 = (t4 * t2);
	double Nn = a / sqrt(1 - ee * sin(B) * sin(B));
	double yt = e2 * cos(B) * cos(B);
	double N = lB;
	N = N + t * Nn * cl2 / 2;
	N = N + t * Nn * cl4 * (5 - t2 + 9 * yt + 4 * yt * yt) / 24;
	N = N + t * Nn * cl6 * (61 - 58 * t2 + t4 + 270 * yt - 330 * t2 * yt) / 720;
	N = N + t * Nn * cl8 * (1385 - 3111 * t2 + 543 * t4 - t6) / 40320;
	double E = Nn * cl;
	E = E + Nn * cl3 * (1 - t2 + yt) / 6;
	E = E + Nn * cl5 * (5 - 18 * t2 + t4 + 14 * yt - 58 * t2 * yt) / 120;
	E = E + Nn * cl7 * (61 - 479 * t2 + 179 * t4 - t6) / 5040;
	E = E + 500000;
	N = 0.9996 * N;
	E = 0.9996 * (E - 500000.0) + 500000.0;

	UTME = E;
	UTMN = N;
}


class DataOut
{
    public:
    float Lon;
    float Lat;
    float Alt;
    
    float v;
    float Yaw;

};
float YawCorrect=90.0f;
uint8_t buff[4096];
const char *dev  = "/dev/ttyUART_232_A";


int main(int argc,char* argv[])
{
    ros::init(argc,argv,"position_P");
    
    ros::NodeHandle n;
    
    ros::Publisher pub =n.advertise<common::Pose>("pose",1);
    
//    DataOut dataout;
    serialPort myserial;
    int i,nread,nwrite;
    int LenBuffer;
    
    char framebuff[1024];
    int n_fbuffer=0;
    
    myserial.OpenPort(dev);
    myserial.setup(115200,0,8,1,'N'); 
    
    myserial.Test1();
    uint8_t buffer1[3];
    
    buffer1[0]=0x11;
    buffer1[1]=0x22;
    buffer1[2]=0x33;
    
    std::string tempStr[20];
    
    common::Pose dataOut;
 
 
//    while(true)
//    {
//      uint8_t data=myserial.getchar();
//     printf("%X\r\n",data);
//      sleep(1);
//    }
    
//    while(true)
//    {
//        myserial.writeBuffer( buffer1, 3);
//        sleep(1);
//   }
    int t =0;
	int  flag  = 0;
    while (ros::ok())
    {UTMCoor test;
	
	  nread = myserial.readBuffer( buff, 4000);
//	  printf("data %d\r\n",nread);
//-	  printf("%s",buff);
//	  usleep(10000);
//	  LenBuffer=length(buff);
//	  if(LenBuffer>4096)
//	  {
//	      LenBuffer=4096;
//	  }
      double lat,lon=0;
	  for(i=0;i<nread;i++)
	  {
	      framebuff[n_fbuffer++]=buff[i];
	      if(n_fbuffer==1)
	      {
	          if(framebuff[0]!='$')
	          {
	              n_fbuffer=0;
				  memset(framebuff,0,sizeof(framebuff));
	          }
	      }
	      else if(n_fbuffer>=5)
	      {
	          if(framebuff[n_fbuffer-2]=='\r'&&framebuff[n_fbuffer-1]=='\n')
	          //if(framebuff[n_fbuffer-1]=='\n')
	          {
	              char TokStr[]=",";
	              uint8_t Len=0;
	              
	              
	              //printf("%s",framebuff);
	              
	              char *pBufferTemp=NULL;
	              pBufferTemp=strtok(framebuff,TokStr);
	              while(pBufferTemp!=NULL)
	              {
	                  tempStr[Len++]=pBufferTemp;
	                  //printf("%s\n",pBufferTemp);
	                  pBufferTemp=strtok(NULL,TokStr);
	                  
	              }
	              //printf("%s",tempStr[0]);
	              if(tempStr[0]=="$GPGGA"&&Len>13)
	              {
	                  int LenStr=0;
	                  LenStr=tempStr[2].length();
					  

					  //printf("%d\n",LenStr);
					//   printf("%s\n",tempStr[2]);
					if(LenStr>6)
					{
					  std::string temp=tempStr[2].substr(0,2);
	                  std::string tempD=tempStr[2].substr(2,LenStr-2);
	                  lat= atof(temp.data())+atof(tempD.data())/60.0f;
					  LenStr=tempStr[4].length();
					  if(LenStr>7)
				      {
					    
					    //printf("%d\n",LenStr);
					    //printf("%s\n",tempStr[4]);
	                    temp=tempStr[4].substr(0,3);
	                    tempD=tempStr[4].substr(3,LenStr-3);
	                    lon= atof(temp.data())+atof(tempD.data())/60.0f;
	                    LatLonToUTMXY(DegToRad(lat ), DegToRad( lon),50,test);
	                   // printf("GGA %10.10f %10.10f\n",lat,lon);
					   
					   flag  = atof(tempStr[6].data());
	                    

					  }
					  std::cout<< "lat: "<<lat<<"   lon:"<<lon<<std::endl;
					}
					n_fbuffer=0;
					memset(framebuff,0,sizeof(framebuff));
	              }
	              else if(tempStr[0]=="$GNVTG"&&Len>9)
	              {
	                  dataOut.v=atof(tempStr[7].data())/3.6f;
	                  //printf("VTG %f\n",dataOut.vP);
	                  n_fbuffer=0;
					  //memset(framebuff,0,sizeof(framebuff));
	              }
	              else if(tempStr[0]=="$BDHDT"||tempStr[0]=="$GNHDT")
	              {
	                  if(Len>2)
					  {
						   float headraw,headtemp;
						   headraw=atof(tempStr[1].data());

                           headtemp=headraw-YawCorrect;
						   if(headtemp<0)
						   {
							  headtemp=headtemp+360.0f;
						   }

                           if(headtemp>180)
						   {
							dataOut.heading=-(headtemp-360.0f);
						   }
						   else
						   {
							dataOut.heading=-headtemp;
						   }

	                       //printf("HDT %f\n",dataOut.yawP);
	                       //n_fbuffer=0;
					       //memset(framebuff,0,sizeof(framebuff));
						   //LonLat2UTM(lon,lat,dataOut.y,dataOut.x);
						    
							double  x_ =  0.14* cos(dataOut.heading/180*3.14) - 0.62*sin(dataOut.heading/180*3.14) ;
							double  y_ =  0.14 * sin(dataOut.heading/180*3.14) + 0.62*cos(dataOut.heading/180*3.14) ;

						   
						  dataOut.x = test.x;
						   dataOut.y = test.y;
						   dataOut.flagP=flag;
						//  dataOut.x = process_data( dataOut.x , 100000000, -100000000, 0.06);
						//  dataOut.x = slide_mean_filter(dataOut.x , 10);

						// dataOut.y = process_data( dataOut.y , 100000000, -100000000, 0.06);
						//  dataOut.y= slide_mean_filter(dataOut.y , 10);

						    // dataOut.x = test.x   + x_;
						    //  dataOut.y = test.y  -  y_;
	                       pub.publish(dataOut);
	                       ROS_INFO("HDT %f,VTG %f,GGA %10.10f %10.10f %d",dataOut.heading,dataOut.v,dataOut.x,dataOut.y,dataOut.flagP);
						   
					  }
					  n_fbuffer=0;
	                  
	              }
	              else
	              {
	                  printf("None");
	                  n_fbuffer=0;
	              }
	          }

	      }
	  }
//    memset(buff,0,sizeof(buff));
	  
//	  printf("%.*s",8,buff);
//	  usleep(400);
    }

    return 0;
}


