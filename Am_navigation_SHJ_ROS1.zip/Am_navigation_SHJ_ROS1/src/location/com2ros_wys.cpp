#include <iostream>
#include "location/serial.h"
#include <string.h>
#include "ros/ros.h"
#include "common/Pose.h"
#include "location/coorconv.h"
#include "common/common.h"
using namespace std;

 double lat,lon,h=0;

void ECEF2LLH(double x,double y,double z,double *lat,double *lon,double *h)
{
        double      a, b, f, e, e1;
double      Longitude;

double      Latitude;

double      Altitude;

double      p, q;

double      N;


a = (double)6378137.0;

b = (double)6356752.31424518;

f = 1.0 / (double)298.257223563;

e = sqrtl(((a * a) - (b * b)) / (a * a));

e1 = sqrtl(((a * a) - (b * b)) / (b * b));

p = sqrtl((x * x) + (y * y));

q = atan2l((z * a), (p * b));

Longitude = atan2l(y, x);

Latitude = atan2l((z + (e1 * e1) * b * powl(sinl(q), 3)), (p - (e * e) * a * powl(cosl(q), 3)));

N = a / sqrtl(1 - ((e * e) * powl(sinl(Latitude), 2)));

Altitude = (p / cosl(Latitude)) - N;

*lon = Longitude ;

*lat = Latitude ;

*h = Altitude;
}


class DataOut
{
    public:
    float Lon;
    float Lat;
    float Alt;
    
    float v;
    float Yaw;

};
float YawCorrect=90.0f;
uint8_t buff[4096];
const char *dev  = "/dev/ttyUART_232_A";


int main(int argc,char* argv[])
{
    ros::init(argc,argv,"position_P");
    
    ros::NodeHandle n;
    
    ros::Publisher pub =n.advertise<common::Pose>("pose",1);
    
//    DataOut dataout;
    serialPort myserial;
    int i,nread,nwrite;
    int LenBuffer;
    
    char framebuff[1024];
    int n_fbuffer=0;
    
    myserial.OpenPort(dev);
    myserial.setup(460800,0,8,1,'N'); 
    
    //myserial.Test1();
    uint8_t buffer1[3];

    std::string tempStr[20];
    
    common::Pose dataOut;
 
    int t =0;
	int  flag  = 0;



    while (1)
    {
        UTMCoor test;
	
	  nread = myserial.readBuffer( buff, 4000);
//    printf("data %d\r\n",nread);
//      printf("%s",buff);
//	  usleep(10000);
//	  LenBuffer=length(buff);
//	  if(LenBuffer>4096)
//	  {
//	      LenBuffer=4096;
//	  }

	  for(i=0;i<nread;i++)
	  {
	      framebuff[n_fbuffer++]=buff[i];
	      if(n_fbuffer==1)
	      {
	          if(framebuff[0]!='$')
	          {
	              n_fbuffer=0;
				  memset(framebuff,0,sizeof(framebuff));
	          }
	      }
	      else if(n_fbuffer>=5)
	      {

			 if(framebuff[n_fbuffer-1]=='$')
			 {
                    n_fbuffer=1;
			 }
	          //if(framebuff[n_fbuffer-2]=='\r'&&framebuff[n_fbuffer-1]=='\n')
	          else if(framebuff[n_fbuffer-1]=='\n')
	          {
	              char TokStr[]="  ";
	              uint8_t Len=0;
	              
	              
	             //printf("%s",framebuff);
	              
	              char *pBufferTemp=NULL;
	              pBufferTemp=strtok(framebuff,TokStr);
	              while(pBufferTemp!=NULL)
	              {
	                  tempStr[Len++]=pBufferTemp;
	                  //printf("%s\n",pBufferTemp);
	                  pBufferTemp=strtok(NULL,TokStr);
	                  
	              }
	              //printf("%d\n",Len);
	              if(tempStr[0]=="$IMUPOS"&&Len==14)
	              {

	                int LenStr=0;
	                LenStr=tempStr[2].length();

					double x,y,z=0;

					x=atof(tempStr[3].data());
					y=atof(tempStr[4].data());
					z=atof(tempStr[5].data());
           
					ECEF2LLH(x,y,z,&lat,&lon,&h);
                    
                    // printf("%f %f %f  %f %f %f \n",lat*57.29,lon*57.29,h,x,y,z);
					LatLonToUTMXY(lat,lon,50,test);

					double vx,vy,vz=0;

					vx=atof(tempStr[8].data());
					vy=atof(tempStr[9].data());
					vz=atof(tempStr[10].data());
					dataOut.latitude = lat;
					dataOut.longitude = lon;

					dataOut.v=sqrt(vx*vx+vy*vy+vz*vz);

					dataOut.flagP=atof(tempStr[7].data());

					dataOut.heading=-atof(tempStr[13].data())-90.0;
                    if(dataOut.heading < -180.0){
                        dataOut.heading  +=360.0;
                    }
                    
                    double  x_ =  0.14* cos(dataOut.heading/180*3.14) - 0.62*sin(dataOut.heading/180*3.14) ;
					double  y_ =  0.14 * sin(dataOut.heading/180*3.14) + 0.62*cos(dataOut.heading/180*3.14) ;
						   
					dataOut.x = test.x;
					dataOut.y = test.y;

                    pub.publish(dataOut);
	                ROS_INFO("HDT %f,VTG %f,GGA %10.10f %10.10f %d",dataOut.heading,dataOut.v,dataOut.x,dataOut.y,dataOut.flagP);

					n_fbuffer=0;
					memset(framebuff,0,sizeof(framebuff));
	              }
	              else
	              {
	                 // printf("None");
	                  n_fbuffer=0;
	              }
	          }
	      }
	  }
//	  usleep(400);
    }

    return 0;
}

