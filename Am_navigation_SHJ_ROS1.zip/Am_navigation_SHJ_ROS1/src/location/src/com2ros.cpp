#include <iostream>
#include "location/serial.h"
#include <string.h>
#include "ros/ros.h"
#include "common/Pose.h"
#include "location/coorconv.h"
#include<fstream>

using namespace std;

class DataOut
{
    public:
    float Lon;
    float Lat;
    float Alt;
    
    float v;
    float Yaw;

};
float YawCorrect=90.0f;
uint8_t buff[4096];
const char *dev  = "/dev/ttyUART_232_A";



int posflag = 1;//定位数据标志位 1表明是GGA+VTG+HDT   0表示韦永僧IMUPOS

void ECEF2LLH(double x,double y,double z,double *lat,double *lon,double *h)
{
        double      a, b, f, e, e1;
double      Longitude;

double      Latitude;

double      Altitude;

double      p, q;

double      N;


a = (double)6378137.0;

b = (double)6356752.31424518;

f = 1.0 / (double)298.257223563;

e = sqrtl(((a * a) - (b * b)) / (a * a));

e1 = sqrtl(((a * a) - (b * b)) / (b * b));

p = sqrtl((x * x) + (y * y));

q = atan2l((z * a), (p * b));

Longitude = atan2l(y, x);

Latitude = atan2l((z + (e1 * e1) * b * powl(sinl(q), 3)), (p - (e * e) * a * powl(cosl(q), 3)));

N = a / sqrtl(1 - ((e * e) * powl(sinl(Latitude), 2)));

Altitude = (p / cosl(Latitude)) - N;

*lon = Longitude ;

*lat = Latitude ;

*h = Altitude;
}

int main(int argc,char* argv[])
{
	fstream fwrite;
    ros::init(argc,argv,"position_P");
    
    ros::NodeHandle n;
    
    ros::Publisher pub =n.advertise<common::Pose>("pose",1);
    
	fwrite.open("./data.txt",ios::out|ios::app);

    serialPort myserial;
    int i,nread,nwrite;
    int LenBuffer;
    
    char framebuff[1024];
    int n_fbuffer=0;
    
    myserial.OpenPort(dev);
    myserial.setup(460800,0,8,1,'N'); 
    
    //myserial.Test1();
    uint8_t buffer1[3];
    
    std::string tempStr[20];
    
    common::Pose dataOut;
    int t =0;
	int  flag  = 0;
    while (ros::ok())
    {
	  UTMCoor test;	
	  nread = myserial.readBuffer( buff, 4000);
//	  printf("data %d\r\n",nread);
	//   printf("%s",buff);

//	  LenBuffer=length(buff);
//	  if(LenBuffer>4096)
//	  {
//	      LenBuffer=4096;
//	  }
      double lat,lon,h=0;
	  for(i=0;i<nread;i++)
	  {
	      framebuff[n_fbuffer++]=buff[i];
	      if(n_fbuffer==1)
	      {
	          if(framebuff[0]!='$')
	          {
	              n_fbuffer=0;
				  memset(framebuff,0,sizeof(framebuff));
	          }
	      }
	      else if(n_fbuffer>=5)
	      {
	          if(framebuff[n_fbuffer-1]=='\n')
	          {
				  char TokStr[]= ",";
				  char TokStr1[]=" ";

				  uint8_t Len=0;
	              
	              char *pBufferTemp=NULL;
				  if(posflag==1)
				  {
					     pBufferTemp=strtok(framebuff,TokStr);
	                     while(pBufferTemp!=NULL)
	                     {
	                         tempStr[Len++]=pBufferTemp;
	                         pBufferTemp=strtok(NULL,TokStr);
	                     }
				  }
                  else{
					    pBufferTemp=strtok(framebuff,TokStr1);
	                     while(pBufferTemp!=NULL)
	                     {
	                         tempStr[Len++]=pBufferTemp;
	                         pBufferTemp=strtok(NULL,TokStr1);
	                     }
				  }

	         
	              if(tempStr[0]=="$GPGGA"&&Len>13)
	              {
	                int LenStr=0;
	                LenStr=tempStr[2].length();
					if(LenStr>7)
					{
					  std::string temp=tempStr[2].substr(0,2);
	                  std::string tempD=tempStr[2].substr(2,LenStr-2);
	                  lat= atof(temp.data())+atof(tempD.data())/60.0f;
					  
					  LenStr=tempStr[4].length();
	                  temp=tempStr[4].substr(0,3);
	                  tempD=tempStr[4].substr(3,LenStr-3);
	                  lon= atof(temp.data())+atof(tempD.data())/60.0f;
	                  LatLonToUTMXY(DegToRad(lat), DegToRad(lon),50,test);
				      flag  = atof(tempStr[6].data());
					}
					n_fbuffer=0;
					memset(framebuff,0,sizeof(framebuff));
	              }
	              else if(tempStr[0]=="$GNVTG"&&Len>9)
	              {
	                dataOut.v=atof(tempStr[7].data())/3.6f;
	                n_fbuffer=0;
					//memset(framebuff,0,sizeof(framebuff));
	              }
	              else if(tempStr[0]=="$BDHDT"||tempStr[0]=="$GNHDT")
	              {

					float headraw,headtemp;
					headraw=atof(tempStr[1].data());

                    headtemp=headraw-YawCorrect;
					if(headtemp<0)
					{
						headtemp=headtemp+360.0f;
					}

                    if(headtemp>180)
					{
					    dataOut.heading=-(headtemp-360.0f);
					}
					else
					{
					    dataOut.heading=-headtemp;
					}

					// dataOut.heading+=90;
					double  x_ =  0.13* cos(dataOut.heading/180*3.14) - 0.0*sin(dataOut.heading/180*3.14) ;
					double  y_ =  0.13 * sin(dataOut.heading/180*3.14) + 0.0*cos(dataOut.heading/180*3.14) ;

					
					dataOut.x = test.x  + x_ ;
					dataOut.y = test.y +  y_;
					dataOut.flagP=flag;
					dataOut.latitude =lat;
                    dataOut.longitude = lon;

					// dataOut.x = test.x  + x_;
					// dataOut.y = test.y  - y_;
	                pub.publish(dataOut);
	                ROS_INFO("HDT %f,VTG %f,GGA %10.10f %10.10f %d",dataOut.heading,dataOut.v,dataOut.x,dataOut.y,dataOut.flagP);   
					n_fbuffer=0;
	              }
				  else if(tempStr[0]=="$IMUPOS"&&Len==21)
				  {
					int LenStr=0;
	                LenStr=tempStr[2].length();

					double x,y,z=0;

					x=atof(tempStr[3].data());
					y=atof(tempStr[4].data());
					z=atof(tempStr[5].data());
           
					ECEF2LLH(x,y,z,&lat,&lon,&h);
                    
                    // printf("%f %f %f  %f %f %f \n",lat*57.29,lon*57.29,h,x,y,z);
					LatLonToUTMXY(lat,lon,50,test);

					double vx,vy,vz=0;

					vx=atof(tempStr[8].data());
					vy=atof(tempStr[9].data());
					vz=atof(tempStr[10].data());

					double wx,wy,wz=0;
					wx=atof(tempStr[15].data());
					wy=atof(tempStr[17].data());
					wz=atof(tempStr[18].data());

					double ax,ay,az=0;
					ax=atof(tempStr[18].data());
					ay=atof(tempStr[19].data());
					az=atof(tempStr[20].data());

					


					dataOut.v=sqrt(vx*vx+vy*vy+vz*vz);

					
					dataOut.flagP=atof(tempStr[7].data());

					dataOut.heading=-atof(tempStr[13].data())-90.0;
                    if(dataOut.heading < -180.0){
                        dataOut.heading  +=360.0;
                    }
                    
                    double  x_ =  0.14* cos(dataOut.heading/180*3.14) - 0.62*sin(dataOut.heading/180*3.14) ;
					double  y_ =  0.14 * sin(dataOut.heading/180*3.14) + 0.62*cos(dataOut.heading/180*3.14) ;
						   
					dataOut.x = test.x;
					dataOut.y = test.y;

					fwrite<<fixed<<dataOut.v<<"  "<<fixed<<dataOut.heading<<"  "<<fixed<<wx<<"  "<<fixed<<wy<<"  "<<fixed<<wz<<"  "<<fixed<<ax<<"  "<<fixed<<ay<<"  "<<fixed<<az<<endl;

                    pub.publish(dataOut);
	                ROS_INFO("HDT %f,VTG %f,GGA %10.10f %10.10f %d",dataOut.heading,dataOut.v,dataOut.x,dataOut.y,dataOut.flagP);

					n_fbuffer=0;
					memset(framebuff,0,sizeof(framebuff));
				  }
	              else
	              {
	                n_fbuffer=0;
	              }
	          }
	      }
	  }
//    memset(buff,0,sizeof(buff));
//	  usleep(400);
    }
    return 0;
}


