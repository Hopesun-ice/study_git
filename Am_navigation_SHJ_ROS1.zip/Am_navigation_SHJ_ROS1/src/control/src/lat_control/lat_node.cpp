﻿#include <ros/ros.h>
#include "Control/lat_control.h"
#include "Control/pid.h"
int main(int argc, char** argv)
{
    ros::init(argc,argv,"Lat_Node" );
    ros::NodeHandle n;
    lat_control   lat_control_car;
    lat_control_car.get_sim_flag();
    if(lat_control_car.sim_flag){
           lat_control_car.get_plan_point_start();
    }
    std::cout<<"lat_control_car.sim_flag:  "<<lat_control_car.sim_flag<<std::endl;
    lat_control_car.data_save_init();

    // lat_control_car.hmi_file.seekp(0);
    // lat_control_car.hmi_file <<25666<<","<< 3.55<<","<<2.3<<","<<0.5<<std::endl;


    // lat_control_car.hmi_file.seekp(0);
    //  lat_control_car.hmi_file <<25666<<","<< 23232323<<","<<2.3<<","<<0.5<<std::endl;
    ros::Subscriber sub_path = n.subscribe("plan", 1,&lat_control::callback_path, &lat_control_car);
    ros::Subscriber sub_pose = n.subscribe("pose", 1,&lat_control::callback_pose, &lat_control_car);
    ros::Publisher   sim_pose_pub = n.advertise<common::Pose>("pose",1);
    ros::Subscriber sub_delta= n.subscribe("delta", 1,&lat_control::callback_delta,&lat_control_car);
    ros::Publisher   lat_control_pub = n.advertise<vehicle_chassis::lat_1204>("lat_control_cmd",1);  
    ros::Publisher   direction_car = n.advertise< std_msgs::Int32>("my_topic",1);  
    ros::Subscriber sub_car_stop = n.subscribe("Topic_Car_stop", 1,&lat_control::callback_car_stop, &lat_control_car);
    ros::Subscriber beiginorpause = n.subscribe("beiginorpause", 1,&lat_control::callback_beiginorpause, &lat_control_car);
       //注意这里修改为和感知一样的话题名字
     ros::Subscriber sub_car_precetpion = n.subscribe("yolov5/BoundingBoxes", 1,&lat_control::callback_perception, &lat_control_car);
    ros::Rate rate(50);
    while(ros::ok())
    {
        // lat_control_car.beginorstop_flag = lat_control_car.get_beginorstop_flag();
        std::cout<<"  lon_control_car.beginorstop_flag: "<<  lat_control_car.beginorstop_flag<<std::endl;
        if(lat_control_car.sim_flag){
            sim_pose_pub.publish(lat_control_car.pose_car);
            if(lat_control_car.beginorstop_flag){lat_control_car.sim_dead_reckoning();}
        }
        if(lat_control_car.beginorstop_flag){
            lat_control_car.ptca();
        } 
        lat_control_car.steer_control();
        lat_control_pub.publish(lat_control_car.lat_cmd);
        direction_car.publish(lat_control_car.diretion);
        rate.sleep();
        ros::spinOnce();
       
    }
    return 0;
}