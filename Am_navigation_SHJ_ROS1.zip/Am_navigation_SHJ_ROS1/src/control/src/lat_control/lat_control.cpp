﻿#include "Control/lat_control.h"
#include <ros/ros.h>
#include <cmath>
#include <vector>
#include "unistd.h"
using namespace std;

/*路径订阅回调函数 */
void lat_control::callback_path(const common::Path &  path_paln){
    path_point.clear();
    for(int i = 0;i<path_paln.path.size();i+=2){
        path_point.push_back(path_paln.path[i]);}
}

void lat_control::callback_pose(const common::Pose & Pose_point){
    if(!sim_flag){
        pose_car.x = Pose_point.x;
        pose_car.y = Pose_point.y;
        pose_car.heading = Pose_point.heading/180.0*3.1415926;
        pose_car.v = Pose_point.v;
        pose_car.latitude = Pose_point.latitude;
        pose_car.longitude = Pose_point.longitude;
    }
   //std::cout<< "当前农机姿态： ("<<pose_car.x<<" , "<<pose_car.y<<" , "<<pose_car.heading<<")"<<std::endl<<std::endl;
}

void lat_control:: callback_delta(const std_msgs::Float32  & deltae){
    this->delta_real = deltae.data;
}

void lat_control::callback_car_stop(const std_msgs::Bool & sub_car_stop){
    lat_control_stop = sub_car_stop.data;
}
void lat_control::callback_beiginorpause(const std_msgs::Bool & sub_car_beiginorpause){
    beginorstop_flag = sub_car_beiginorpause.data;
}
void lat_control:: callback_perception(const yolov5_ros_msgs::BoundingBoxes &  car_perception){
    static int num_car_perception = 0;
    static int num_car_perception_false = 0;
    if(car_perception.bounding_boxes[0].num>0){
        num_car_perception++;
        if(num_car_perception > 30){
            num_car_perception = 0;
            // beginorstop_flag = false;
           // std::cout<< "true"<<std::endl;
        }
    }
    else{
        num_car_perception_false ++ ;
        if(num_car_perception_false > 50){
            // beginorstop_flag = true;
           // std::cout<< "false"<<std::endl;
        }
    }
}
void  lat_control::control_init(){
    //低频PWM模块
    pid_lat.setK(200.0,0,50); pid_lat.setBound(70,-70);
    lat_cmd.lat_cmd[0] = 0x01;  lat_cmd.lat_cmd[1] = 0x06;lat_cmd.lat_cmd[2] = 0x01;
    //高频PWM模块
//     pid_lat.setK(8000.0,0,150); pid_lat.setBound(800,-800);
//     lat_cmd.lat_cmd[0] = 0x21;  lat_cmd.lat_cmd[1] = 0x06;lat_cmd.lat_cmd[2] = 0x23; lat_cmd.lat_cmd[6] = 0xAA; lat_cmd.lat_cmd[7] = 0xAA;
 }
double lat_control::ptca(){
    
    //寻找距离当前农机位置的最近点的ID
    std::vector<double> dis;
    for(int  i =0;i<path_point.size();i++){
         dis.push_back(sqrt((pose_car.x - path_point[i].x)*(pose_car.x - path_point[i].x)   + (pose_car.y - path_point[i].y) * (pose_car.y -path_point[i].y)));
    }
    int ref_num = dis.size();
    if(ref_num == 0){ ROS_WARN("The number of reference path points received is 0"); return  0; }
    int min_id = min_element(dis.begin(),dis.end()) - dis.begin();
    double L_dis_min_id = sqrt(( path_point[min_id].x - pose_car.x)* (path_point[min_id].x - pose_car.x) + ( path_point[min_id].y - pose_car.y)*( path_point[min_id].y - pose_car.y));
    //寻找前视距离中最近点的ID
    static  int  idx_target;
    int   idx = min_id;
    float L_steps = 0,average_cur = 0;
    while(L_steps < Ld && idx < ref_num - 1){
        float x =  path_point[idx+1].x                - path_point[idx].x;
        float y =  path_point[idx+1].y - path_point[idx].y;
        float dis_step = sqrt(x*x + y*y);
        L_steps  += dis_step;
        idx++;
    }
     idx_target = idx ;
    for(int i =0;i<100;i++){
        average_cur  +=fabs(path_point[idx_target+i].curvature);
    }
    average_cur = average_cur /(100.0);
    if(path_point[idx_target].curvature>=0.1&& average_cur> 0.02){k_v = 1.4;Ld0=1.6;}
    else {k_v = 1.2;Ld0=1.2;}
    Ld=k_v*(pose_car.v)+Ld0+L_dis_min_id; 
    // Ld = 1.8;
    // if(Ld > 5) Ld=5;  
    float alpha = atan2((path_point[idx_target].y - pose_car.y),(path_point[idx_target].x - pose_car.x));
    double Ld_tar = sqrt(( path_point[idx_target].x - pose_car.x)* (path_point[idx_target].x - pose_car.x) + ( path_point[idx_target].y - pose_car.y)*( path_point[idx_target].y - pose_car.y));
    static float theta_e;
    if(path_point[idx_target].gear == 1){
            theta_e = alpha - pose_car.heading; 
            theta_e =range_angle_PI(theta_e);
            delta_f =atan2(2*3.13*sin(theta_e),Ld_tar) ;
            diretion.data = 1;
        }
    else {
            theta_e = (alpha -pose_car.heading);
            theta_e = 3.1415926 -theta_e;
            theta_e = range_angle_PI(theta_e);
            delta_f = atan2(2*3.13*sin(theta_e),Ld) ;
            std::cout<<"daoche!!!!! "<<std::endl;
            diretion.data = 0;
        }
    
    delta_f =  delta_f>0.6?0.6:delta_f;
    delta_f =  delta_f<-0.6?-0.6:delta_f;
    // // 对直线路径输出的前轮转角进行限幅  防止定位出现抖动的时候 方向盘出现大规模的抖动  实验中可以测试一下  这里面的常数都有待调试
    // if(L_dis_min_id  <0.3 && (fabs(path_point[min_id].curvature)<0.1  &&fabs(path_point[idx_target].curvature)<0.1 )){
    //     delta_f =  delta_f>0.1?0.1:delta_f;
    //     delta_f =  delta_f<-0.1?-0.1:delta_f;
    // }
    hmi_file.seekp(0);
    hmi_file << pose_car.latitude<<","<<  pose_car.longitude<<","<<pose_car.heading<<","<<L_dis_min_id<<std::endl;
    outFile <<L_dis_min_id<<","<< pose_car.x<<","<< pose_car.y<<","<<pose_car.heading<<","<<pose_car.v<<","<<path_point[min_id].v<<","\
    <<min_id<<","<< path_point[min_id].x<<","<< path_point[min_id].y<<","<< path_point[min_id].heading  <<","\
    <<delta_f<<","<<delta_real<<","<<alpha<<","<<Ld<<","<<Ld_tar<<std::endl;
    static int printf_num = 0;
    if(++printf_num>0){
        printf_num = 0;
        std::cout<<"L_dis_min_id: "<<L_dis_min_id<<"  Ld: "<< Ld <<"  ref_num: "<<ref_num<<"   min_id: "<<min_id<<"  target_id: "<<idx_target<<std::endl;
        std::cout<<setprecision(9)<< "目标点("<<path_point[idx_target].x<<" , "<<path_point[idx_target].y<<" , "<<alpha<<")";
        std::cout<<setprecision(9)<< "  当前点 ("<<pose_car.x<<" , "<<pose_car.y<<" , "<<pose_car.heading<<" , "<<pose_car.v<<")"<<std::endl;
        std::cout<<"Ld_tar:  "<<Ld_tar<<"   alpha:  "<<alpha<<" theta_e:"<<theta_e<< " delta_f:"<<delta_f<<"      delta_real:"<<this->delta_real<<std::endl<<std::endl;
    }
    delta_f = lat_control_stop>0?0.0:delta_f;
    std::cout<<"lat_control_stop: "<<(int)lat_control_stop<<std::endl;
    std::cout<<"delta_f: "<<delta_f<<std::endl;
    delta_last = delta_f;
    // if(this->beginorstop_flag)return delta_f;
    // else return delta_last;
    return delta_f;
}
void    lat_control::steer_control(){
    static  uint8_t  temp_src[8] = {0x01,0x06,0x01};
    double error = fabs(delta_f - delta_real);
    // if(error < 0.08 ){error = error *0.5*(8-fabs(error*100));}//尝试一下直接放大误差 会怎么样
    //  if(error < 0.08 ){error = error *1.5;}//尝试一下直接放大误差 会怎么样
    // float steer_output = pid_lat.calOutput(delta_f,delta_real);
    float steer_output = pid_lat.calOutput(error);
    // lat_cmd.lat_cmd[3] = (delta_f -delta_real) <= 0 ? 0x51:0x52;
    // lat_cmd.lat_cmd[4] = (uint8_t)(fabs(steer_output*10))/256;
    // lat_cmd.lat_cmd[5] = (uint8_t)(fabs(steer_output*10))%256;
    std::cout<<"steer_output: "<<steer_output<<std::endl;
    lat_cmd.lat_cmd[3] = (delta_f -delta_real) <= 0 ? 0x95:0x94;
    lat_cmd.lat_cmd[4] = (int)(fabs(steer_output*10))/256;
    lat_cmd.lat_cmd[5] = (int)(fabs(steer_output*10))%256;
    temp_src[3] =  lat_cmd.lat_cmd[3]; temp_src[4] =  lat_cmd.lat_cmd[4]; temp_src[5] =  lat_cmd.lat_cmd[5];
    lat_cmd.lat_cmd[6] = CRC16_2(temp_src,6)/256;
    lat_cmd.lat_cmd[7] = CRC16_2(temp_src,6)%256;
}

int lat_control::sim_dead_reckoning(){
    std::vector<double> dis;
    for(int  i =0;i<path_point.size();i++){
         dis.push_back(sqrt((pose_car.x - path_point[i].x)*(pose_car.x - path_point[i].x)   + (pose_car.y - path_point[i].y) * (pose_car.y -path_point[i].y)));
    }
    int ref_num = dis.size();
    if(ref_num == 0){ ROS_WARN("sim_dead_reckoning received is 0"); return  0; }
    int min_id = min_element(dis.begin(),dis.end()) - dis.begin();
    int   idx = min_id;
    float v ;
    if(path_point[min_id].gear == 1)   v = 2;
    else  v = -1;
    if (lat_control_stop){ v = 0;}
    pose_car.x = pose_car.x + v  * 0.02*cos(pose_car.heading);
    pose_car.y = pose_car.y + v * 0.02*sin(pose_car.heading);
    pose_car.heading = pose_car.heading + v*0.1*tan(this->delta_f)/2.36;
    pose_car.heading  =   range_angle_PI(pose_car.heading );
    }

void  lat_control:: get_plan_point_start(){
    std::string filename = ros::package::getPath(std::string("planning"));
    filename.append("/data/wp.csv");
    std::ifstream file_in(filename.c_str());
    if (!file_in.is_open()) {
        ROS_ERROR("planning cannot open trajectory file: [%s]", filename.c_str());
        return;
    }
    std::string line;
  // 跳过表头
    getline(file_in, line);
    getline(file_in, line);
    std::vector<std::string>  tokens = Split(line, ",");
    plan_point_start.x = std::atof(tokens[0].c_str());
    plan_point_start.y = std::atof(tokens[1].c_str());
    plan_point_start.heading = std::atof(tokens[8].c_str());

    this->pose_car.x  =plan_point_start.x+1;
    this->pose_car.y  =plan_point_start.y-1;
    this->pose_car.heading  =plan_point_start.heading;
    file_in.close();
}
int   lat_control::get_sim_flag(){
    const char* filename = "/home/nvidia/Am_navigation_SHJ_ROS1/src/common/param/param.txt";
    sim_keyword = read_txt_file(filename, "sim_flag");
    sim_flag =  std::atoi(sim_keyword.value);
}

void  lat_control::data_save_init(){
outFile.open("test.csv", std::ios::out | std::ios::trunc);
hmi_file.open("hmi_file.txt", std::ios::out | std::ios::trunc);
outFile <<"L_dis_1"<<","<< "pose_car.x"<<","<< "pose_car.y"<<","<<"pose_car.heading"<<","<<"pose_car.v"<<","\
                <<"path[min_id].v"<<","<<"min_id"<<","<< "path[min_id].x"<<","<<"path[min_id].y"<<","<< "path[min_id].heading" \
                    <<","<<"delta_f"<<","<<"delta_real"<<","<<"alpha"<<","<<"Ld"<<","<<"Ld_tar"<<std::endl;
outFile.fixed;
outFile.precision(10);
hmi_file.fixed;
hmi_file.precision(10);
}

bool  lat_control::get_beginorstop_flag(){
        static std::string filename = "/home/nvidia/Am_navigation_SHJ_ROS1/output.txt";
        std::string lastLine = ReadLastLine(filename);
        if(std::atoi(lastLine.c_str())){ return true;}
        else{return false;}
}
