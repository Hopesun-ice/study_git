#include <eigen3/Eigen/Dense>
#include <iostream>
#include <vector>
#include <fstream>
#include <cmath>
#include "Control/MPC.h"
//#include "std_msgs/msg/string.hpp"
using namespace std;
#define pi 3.1415926

int main(int argc, char **argv) {  
    
    ros::init(argc,argv,"MPC_Node" );
    ros::NodeHandle n;
    ros::Rate rate(20);

    MPC mpc;
    mpc.get_sim_flag();
    if(mpc.sim_flag){
           mpc.get_plan_point_start();
    }
    std::cout<<"lat_control_car.sim_flag:  "<<mpc.sim_flag<<std::endl;
    mpc.data_save_init();
    mpc.mpc_init();
    mpc.get_plan_point_start();
    ros::Subscriber sub_path = n.subscribe("plan", 1,&MPC::callback_path, &mpc);
    ros::Subscriber sub_pose = n.subscribe("pose", 1,&MPC::callback_pose, &mpc);
    ros::Publisher   sim_pose_pub = n.advertise<common::Pose>("pose",1);
    ros::Publisher   lat_control_pub = n.advertise<vehicle_chassis::lat_1204>("lat_control_cmd",1);  
    ros::Subscriber sub_delta= n.subscribe("delta", 1,&MPC::callback_delta,&mpc);
    // ros::Subscriber sub_car_stop = n.subscribe("Topic_Car_stop", 1,&MPC::callback_car_stop, &mpc);
    ros::Subscriber beiginorpause = n.subscribe("beiginorpause", 1,&MPC::callback_beiginorpause, &mpc);
       //注意这里修改为和感知一样的话题名字
    //  ros::Subscriber sub_car_precetpion = n.subscribe("yolov5/BoundingBoxes", 1,&MPC::callback_perception, &mpc);

    double  dt = 0.1;                                         //time   s
    double  L = 2.36;                                        //Zhou Ju     m
    double  max_steer = 30 * pi / 180;      //MAX ZhuanXiangJiao rad
    double  target_v =0.1;                                //Target v   m/s


        double x, y, yaw;                                   // x, y, yaw 
        double v = 0.0;                                     
        Eigen::Vector2d U(0.0, 0.0);                      
        int idx = 0;                                        
        Eigen::VectorXd latError_MPC;        
        // mpc.refPos_x.resize(20);             // refPos_x          
        // mpc.refPos_y.resize(20);      

        x = mpc.plan_point_start.x -3;                              
        y = mpc.plan_point_start.y;         
        mpc.pose_car.x = x;
        mpc.pose_car.y = y;                   
        yaw = -1.41;    //-3.1    
        // std::cout<< x << "  y "<< y<<std::endl;
        // while(1);                 
        
     

        while (ros::ok()) {
        Eigen::VectorXd MPC_res ;
        static int num = 10;
        // std::cout<<"  lon_control_car.beginorstop_flag: "<<  mpc.beginorstop_flag<<std::endl;
    
        if(mpc.beginorstop_flag){
            ROS_INFO("start MPC");
            x =  mpc.pose_car.x;
            y = mpc.pose_car.y;
            yaw = mpc.pose_car.heading  ;
            // MPC_res = mpc.mpc_control(x, y, yaw, mpc.refPos_x, mpc.refPos_y, mpc.refHeading, mpc.refPos_k,mpc.refDelta, dt, L, U, target_v);
             MPC_res = mpc.mpc_control_osqp(x, y, yaw, mpc.refPos_x, mpc.refPos_y, mpc.refHeading, mpc.refPos_k,mpc.refDelta, dt, L, U, target_v);
            mpc.steer_control();
            lat_control_pub.publish(mpc.lat_cmd);
            cout <<"heading: " << yaw<<  "     LatError    " << MPC_res(3)<< endl;
            ROS_INFO("stop MPC");
            // if(num--  <1)   while(1);
        } 
        if(mpc.sim_flag){
            sim_pose_pub.publish(mpc.pose_car);
       
            if(mpc.beginorstop_flag){
                // std::cout<"  MPC_res(1)  "<<MPC_res(1)<<std::endl;
                mpc.updateState(x, y, yaw, 1,0.5, dt, L, max_steer);
                mpc.pose_car.x = x;
                mpc.pose_car.y = y;
                mpc.pose_car.heading = yaw;
                
            }
        }  
        rate.sleep();
        ros::spinOnce();
         } 
    return 0;
}

