#include "Control/MPC.h"

#define NB 480//hx
#define NM 564
#define NS 645
#define ZO 730
#define PS 814
#define PM 897
#define PB 980
#define pi 3.1415926

MPC::MPC() :Fuzzy_controller(0,0,0){};

/*路径订阅回调函数 */
void MPC::callback_path(const common::Path &  path_paln){
    // ROS_WARN("callback_path");
     refPos.resize(path_paln.path.size(),4);
    for(int i = 0;i<path_paln.path.size();i ++){
        refPos(i,0) = path_paln.path[i].x;
        refPos(i,1) = path_paln.path[i].y;
        refPos(i,2) = path_paln.path[i].heading;
        // std::cout<<" path_paln.path[i].heading: "<< path_paln.path[i].heading<<std::endl;
        refPos(i,3) = path_paln.path[i].curvature;
    }
   
    refPos_x = refPos.col(0);             // refPos_x
    refPos_y = refPos.col(1);             // refPos_y

    Eigen::VectorXd diff_x = refPos_x.segment(1, refPos_x.size() - 1) - refPos_x.segment(0, refPos_x.size() - 1);
    diff_x.conservativeResize(diff_x.size() + 1); 
    diff_x(diff_x.size() - 1) = diff_x(diff_x.size() - 2);

    Eigen::VectorXd diff_y = refPos_y.segment(1, refPos_y.size() - 1) - refPos_y.segment(0, refPos_y.size() - 1);
    diff_y.conservativeResize(diff_y.size() + 1); 
    diff_y(diff_y.size() - 1) = diff_y(diff_y.size() - 2);

    refHeading.resize(path_paln.path.size());                       // refHeading 
    for(int i = 0;i<refHeading.size();i++){
    refHeading(i) = atan2(diff_y(i), diff_x(i));
    }
    refPos_k.resize(refPos_x.size() -2);   
    for (int i = 0; i < refPos_x.size() - 2; ++i) {
        double dx = refPos_x(i + 2) - refPos_x(i + 1);
        double dy = refPos_y(i + 2) - refPos_y(i + 1);
        double ddx = refPos_x(i + 1) - refPos_x(i);
        double ddy = refPos_y(i + 1) - refPos_y(i);
        double num = dx * ddy - dy * ddx;
        double denom = std::pow(dx * dx + dy * dy, 1.5);
        double curv = num / denom;
        refPos_k(i) = -curv;
    }
    // refHeading =  refPos.col(2);                       // refHeading
    // refPos_k = refPos.col(3);                            // refPos_k
    refDelta = 2.36 * refPos_k.array().atan();     // refDelta 

    

    // std::cout<<"refPos_x "<<std::fixed<<refPos_x<<std::endl;
    //  std::cout<<"refPos_y "<<std::fixed<<refPos_y<<std::endl;
        // std::cout<<"refPos_heading "<<std::fixed<<refHeading<<std::endl;
    //         std::cout<<"refPos_Delta "<<std::fixed<<refDelta<<std::endl;
    //         while (1)
    //         {
    //             /* code */
    //         }
}
void MPC::callback_pose(const common::Pose & Pose_point){
      if(!sim_flag){
        pose_car.x = Pose_point.x;
        pose_car.y = Pose_point.y;
        pose_car.heading = Pose_point.heading/180.0*3.1415926;
        pose_car.v = Pose_point.v;
        std::cout<<fixed<<setprecision(8)<< "当前农机姿态： ("<<pose_car.x<<" , "<<pose_car.y<<" , "<<pose_car.heading<<")"<<std::endl<<std::endl;}
}
void MPC::callback_beiginorpause(const std_msgs::Bool & sub_car_beiginorpause){
    beginorstop_flag = sub_car_beiginorpause.data;
}

void MPC:: callback_delta(const std_msgs::Float32  & delta){
    this->delta_real = delta.data;
    std::cout<< "callback_delta!! "<<std::endl;
}

 void MPC:: mpc_init(){
    pid_lat.setK(400.0,0,150); pid_lat.setBound(80,-80);
    lat_cmd.lat_cmd[0] = 0x00;  lat_cmd.lat_cmd[1] = 0x00;lat_cmd.lat_cmd[2] = 0x01;  lat_cmd.lat_cmd[3] = 0x00;
    lat_cmd.lat_cmd[4] = 0x00;  lat_cmd.lat_cmd[5] = 0x01;lat_cmd.lat_cmd[6] = 0x64;  lat_cmd.lat_cmd[7] = 0x00;
 }

//寻找最近点 不建议使用整条轨迹
int MPC::calc_target_index(double x, double y, Eigen::VectorXd refPos_x, Eigen::VectorXd refPos_y) {
    int size = refPos_x.size() - 1;
    std::vector<double> dist(size);
   
    for (int i = 0; i < size; i++) {
        dist[i] = std::sqrt(std::pow(refPos_x[i] - x, 2) + std::pow(refPos_y[i] - y, 2));
    }

    int target_idx = 0;
    double min_dist = dist[0];
    for (int i = 1; i < size; i++) {
        if (dist[i] < min_dist) {
            min_dist = dist[i];
            target_idx = i;
        }
    }
    return target_idx;
}


Eigen::VectorXd MPC::mpc_control_osqp(double x, double y, double yaw, const Eigen::VectorXd& refPos_x, const Eigen::VectorXd& refPos_y, const Eigen::VectorXd& refPos_yaw,
	 const Eigen::VectorXd& refPos_k,const Eigen::VectorXd& refDelta, const double dt, const double L, Eigen::VectorXd& U, const double target_v) {

        if(refPos_x.size() == 0){
            std::cout<<"refPos_x.size() == 0"<<std::endl;
            return Eigen::VectorXd::Zero(6);
        }
	   int Nx = 3;
	//    int Nu = 2;//new
       int Nu = 1;
       //这里预测时域是怎么理解  时间步长？距离步长，在实际工程中怎么理解这个预测时域
	   int Np = 10;
	   int Nc = 5;
	   //int row = 10;

    int idx = calc_target_index(x, y, refPos_x, refPos_y);                           
    double v_r = target_v;
    double Delta_r = refDelta(idx);
    double heading_r = refPos_yaw(idx);

    Eigen::Vector3d X_real(x, y, yaw);
    Eigen::Vector3d Xr(refPos_x(idx), refPos_y(idx), refPos_yaw(idx));
    double x_error = x - refPos_x(idx);
    double y_error = y - refPos_y(idx);
    // std::cout<< "x: "<< x << "     refPos_x(idx):"<< refPos_x(idx)<<std::endl;
    // std::cout<< "y: "<< y << "     refPos_y(idx):"<< refPos_y(idx)<<std::endl;
    std::cout<< "x_error: "<<x_error  <<" y_error  "<<y_error<<std::endl; 
    double L_dis = sqrt(x_error * x_error + y_error * y_error);
    double latError = y_error * cos(heading_r) - x_error * sin(heading_r);     

    float Error = latError;		             //横向误差
    float K = refPos_k(idx);			  //路径曲率
     //float Kq = 0;              	               //优化Q
    double ruleMatrix[7][7] = { {NB,NB,NB,NM,NS,NS,ZO},
                               {NB,NB,NM,NM,NS,ZO,ZO},
                               {NB,NM,NS,NS,ZO,PS,PS},
                               {NM,NM,NS,ZO,PS,PS,PM},
                               {NS,NS,ZO,PS,PS,PM,PB},
                               {ZO,ZO,PS,PS,PM,PB,PB},
                               {ZO,PS,PS,PM,PB,PB,PB} };
    float x1_mf_paras[21] = {0,0,0.01,0,0.01,0.02,0.01,0.02,0.03,0.02,0.03,0.04,0.03,0.04,0.05,0.04,0.05,0.08,0.05,0.08,0.12};                
    // float x1_mf_paras[21] = { -12,-12,-8,-12,-8,-4,-8,-4,0,-4,0,4,0,4,8,4,8,12,8,12,12 };
     float x2_mf_paras[21] = { 0,0,0.04,0,0.04,0.08,0.04,0.08,0.12,0.08,0.12,0.16,0.12,0.16,0.2,0.16,0.2,0.24,0.2,0.24,0.24 };
    //float x2_mf_paras[21] = { -6,-6,-4,-6,-4,-2,-4,-2,0,-2,0,2,0,2,4,2,4,6,4,6,6 }; 
     float u_mf_paras[21] = {480,480,564,480,564,645,564,645,730,645,730,814,730,814,897,814,897,980,897,980,980 };       
    // float u_mf_paras[21] = { -3.6,-3.6,-2.4,-3.6,-2.4,-1.2,-2.4,-1.2,0,-1.2,0,1.2,0,1.2,2.4,1.2,2.4,3.6,2.4,3.6,3.6 };
    
    Fuzzy_controller fuzzy(0.12, 0.24 ,980);
    fuzzy.setMf("trimf", x1_mf_paras, "trimf", x2_mf_paras, "trimf", u_mf_paras);
    fuzzy.setRule(ruleMatrix);

    // float Kq = fuzzy.realize(abs(Error), K);
    // cout <<"优化值Q"<< Kq << endl;

    static  float k_q =0;
    k_q =  (L_dis < 0.2)? 1.5:0.2; 
    Eigen::MatrixXd q(Nx,Nx);
     q<<10,0,0,
     0,0,0,
     0,0,2;
    

    Eigen::MatrixXd Q = Eigen::MatrixXd::Zero(Np*Nx, Np*Nx);
    for(int i =0; i<Np; ++i){
        Q.block(i*Nx, i*Nx,Nx, Nx) = q;
    }
    // Eigen::MatrixXd Q = 10* Eigen::MatrixXd::Identity(Np * Nx, Np * Nx);   
	Eigen::MatrixXd R =  1* Eigen::MatrixXd::Identity(Nc * Nu, Nc * Nu);         

    Eigen::Matrix3d a;                                                              
    a << 1, 0, -v_r * std::sin(heading_r) * dt,
         0, 1, v_r* std::cos(heading_r)* dt,
         0, 0, 1;

    Eigen::Matrix<double, 3, 1> b;
    // b << std::cos(heading_r) * dt, 0,
    //      std::sin(heading_r)* dt, 0,
    //      std::tan(heading_r)* dt / L, v_r* dt / (L * std::pow(std::cos(Delta_r), 2));
// b << std::cos(heading_r) * dt, 0,
//          std::sin(heading_r)* dt, 0,
//          std::tan(Delta_r)* dt / L, v_r* dt / (L * std::pow(std::cos(Delta_r), 2));//new
    b << 0, 0, v_r* dt / (L * std::pow(std::cos(Delta_r), 2));
    // std::cout<<a  <<std::endl;
    // std::cout<<b<<std::endl;
    std::cout<< "v_r: "<<v_r << "  Delta_r: "<<Delta_r<<"  heading_r "<<heading_r<<std::endl;
   
   Eigen::Vector3d temp(0, 0, 0);
    temp = X_real - Xr;
    // std::cout <<temp(0) << "   "<<temp(1)<<std::endl;
    temp(2) = range_angle_PI(temp(2));
    Eigen::VectorXd kesi(Nx + Nu);                                                  
    kesi.segment(0, Nx) = temp;
    kesi.segment(Nx, Nu) = U;

    Eigen::MatrixXd A(Nx+Nu, Nx+Nu);
    Eigen::MatrixXd zeros_Nu_Nx = Eigen::MatrixXd::Zero(Nu, Nx);            
    Eigen::MatrixXd eye_Nu = Eigen::MatrixXd::Identity(Nu, Nu);             

    A.block(0, 0, Nx, Nx) = a;
    A.block(0, Nx, Nx, Nu) = b;
    A.block(Nx, 0, Nu, Nx) = zeros_Nu_Nx;
    A.block(Nx, Nx, Nu, Nu) = eye_Nu;

    Eigen::MatrixXd B(Nx+Nu, Nu);                                                   
    B.block(0, 0, Nx, Nu) = b;
    B.block(Nx, 0, Nu, Nu) = Eigen::MatrixXd::Identity(Nu, Nu);

    Eigen::MatrixXd C(Nx, Nx + Nu);                                                 
    C.block(0, 0, Nx, Nx) = Eigen::MatrixXd::Identity(Nx, Nx);
    C.block(0, Nx, Nx, Nu) = Eigen::MatrixXd::Zero(Nx, Nu);

                                                                     
    std::vector<Eigen::MatrixXd> PHI_cell(Np); //PHI
    PHI_cell[0] = C * A;
    for (int i = 1; i < Np; i++) {
        PHI_cell[i] = PHI_cell[i - 1] * A;
    }
    Eigen::MatrixXd PHI(Nx*Np, Nx+Nu);
    for (int i = 0; i < Np; i++) {
        PHI.block(i * Nx, 0, Nx, Nx + Nu) = PHI_cell[i];
    }
                                                 
    std::vector<std::vector<Eigen::MatrixXd>> THETA_cell(Np, std::vector<Eigen::MatrixXd>(Nc));//THETA

    for (int i = 0; i < Np; i++) {
        for (int j = 0; j < Nc; j++) {
            if (j <= i) {
                Eigen::MatrixXd power_A = Eigen::MatrixXd::Identity(Nx + Nu, Nx + Nu);
                for (int k = 0; k < (i - j); k++) {
                    power_A *= A;
                }
                THETA_cell[i][j] = C * power_A * B;
            }
            else {
                THETA_cell[i][j] = Eigen::MatrixXd::Zero(Nx, Nu);
            }
        }
    }
    Eigen::MatrixXd THETA(Nx * Np, Nu * Nc);
    for (int i = 0; i < Np; i++) {
        for (int j = 0; j < Nc; j++) {
            THETA.block(i * Nx, j * Nu, Nx, Nu) = THETA_cell[i][j];
        }
    }

Eigen::MatrixXd Yref = Eigen::VectorXd::Zero(Nx * Np);                         
 Eigen::MatrixXd delta_U;
    
Eigen::MatrixXd THETA_transpose = THETA.transpose();
Eigen::MatrixXd Q_THETA = Q * THETA;
Eigen::MatrixXd THETA_Q_THETA_R_inv = (THETA_transpose * Q_THETA + R).inverse();
Eigen::MatrixXd THETA_Q_Yref = THETA_transpose * Q * (Yref - PHI * kesi);

// Eigen::VectorXd umin(2); umin << -0.2, -0.58;
// Eigen::VectorXd umax(2); umax << 0.2, 0.49;
// Eigen::VectorXd delta_umin(2); delta_umin << -0.05, -0.1;
// Eigen::VectorXd delta_umax(2); delta_umax << 0.05, 0.1;
Eigen::VectorXd umin(1); umin <<  -0.50;
Eigen::VectorXd umax(1); umax << 0.40;
Eigen::VectorXd delta_umin(1); delta_umin << -0.1;
Eigen::VectorXd delta_umax(1); delta_umax << 0.1;
Eigen::VectorXd Umin = umin.replicate(Nc, 1);
Eigen::VectorXd Umax = umax.replicate(Nc, 1);
Eigen::VectorXd delta_Umin = delta_umin.replicate(Nc, 1);
Eigen::VectorXd delta_Umax = delta_umax.replicate(Nc, 1);
Eigen::VectorXd U_ = U.replicate(Nc, 1);
Eigen::MatrixXd A_t = Eigen::MatrixXd::Zero(Nc, Nc); 
for (int i = 0; i < Nc; ++i) {
    A_t.block(i, 0, 1, i + 1).setOnes(); // 设置下三角方阵的对角线及以下元素为1
}
Eigen::MatrixXd eye_Nu_ = Eigen::MatrixXd::Identity(Nu, Nu); // 创建大小为Nu*Nu的单位矩阵

Eigen::MatrixXd A_I(Nc * Nu, Nc * Nu); // 创建大小为Nc*Nu * Nc*Nu的A_I矩阵
// 实现A_I矩阵的计算
for (int i = 0; i < Nc; ++i) {
    for (int j = 0; j < Nc; ++j) {
        A_I.block(i * Nu, j * Nu, Nu, Nu) = A_t(i, j) * eye_Nu_;
    }
}

Eigen::MatrixXd A_cons( Nc * Nu, Nc * Nu); // 创建大小为2*Nc*Nu * Nc*Nu的A_cons矩阵
A_cons << A_I;


Eigen::MatrixXd iden = Eigen::MatrixXd::Identity(Nc * Nu, Nc * Nu);
Eigen::MatrixXd A_tmp(2*Nc * Nu, Nc * Nu);
Eigen::SparseMatrix<double>  A_all(2*Nc * Nu, Nc * Nu);
A_tmp << A_cons,iden;

// Eigen::MatrixXd A_tmp(Nc * Nu, Nc * Nu);
// Eigen::SparseMatrix<double>  A_all(Nc * Nu, Nc * Nu);
// A_tmp << A_cons;

for(int i = 0; i<A_tmp.rows();++i){
    for(int j = 0; j<A_tmp.cols();++j){
        A_all.insert(i,j) = A_tmp(i,j);
    }
}


Eigen::VectorXd ub(2* Nc * Nu, 1);
ub << Umax - U_,delta_Umax;
Eigen::VectorXd lb(2* Nc * Nu, 1);
lb << Umin - U_,delta_Umin;

// Eigen::VectorXd ub( Nc * Nu, 1);
// ub << Umax - U_;
// Eigen::VectorXd lb( Nc * Nu, 1);
// lb << Umin - U_;

Eigen::MatrixXd H_tmp(Nu*Nc, Nu*Nc);
Eigen::SparseMatrix<double> H(Nu*Nc, Nu*Nc);
H_tmp = 2* (THETA_transpose * Q_THETA + R);
for(int i = 0; i<H_tmp.rows();++i){
    for(int j = 0; j<H_tmp.cols();++j){
        H.insert(i,j) = H_tmp(i,j);
    }
}

// Eigen::VectorXd f = 2 * (PHI * kesi).transpose() * Q * THETA;
// Eigen::VectorXd f = 2  * THETA.transpose() * Q * (PHI * kesi-Yref);
Eigen::VectorXd f = 2  *  (PHI * kesi- Yref).transpose()* Q * THETA;
// std::cout<<"H_tmp"<<H_tmp<<std::endl;
// std::cout<<"H"<<H<<std::endl;
// std::cout<<"ub"<<ub<<std::endl;
// std::cout<<"lb"<<lb<<std::endl;
// std::cout<<"A_tmp"<<A_tmp<<std::endl;
// std::cout<<"A_all"<<A_all<<std::endl;
// std::cout<<"f"<<f<<std::endl;


/* 创建求解器 */
OsqpEigen::Solver solver;

/* 设置参数*/
solver.settings()->setVerbosity(false);
solver.settings()->setWarmStart(true);

/* 设置数据 */
solver.data()->setNumberOfVariables(Nu*Nc);//变量数
solver.data()->setNumberOfConstraints(2*Nc*Nu);//约束的数量
// solver.data()->setNumberOfConstraints(Nc*Nu);//约束的数量
solver.data()->setHessianMatrix(H);//设置hessian矩阵
solver.data()->setGradient(f);//设置雅克比矩阵
solver.data()->setLinearConstraintsMatrix(A_all);//设置线性约束矩阵
solver.data()->setLowerBound(lb);//下限
solver.data()->setUpperBound(ub);//上限


/* 初始化求解器 */
solver.initSolver();
/*求解*/
// solver.solveProblem();
solver.solve();
/*获得解*/
Eigen::VectorXd QPSolution = solver.getSolution();

// std::cout << "QPSolution"<<QPSolution(1) << std::endl;
// delta_U = THETA_Q_THETA_R_inv * THETA_Q_Yref;
// std::cout<< "THETA_Q_THETA_R_inv: "<<THETA_Q_THETA_R_inv<<std::endl;
// std::cout<< "THETA_Q_Yref: "<<THETA_Q_Yref<<std::endl;
//   if( QPSolution(1) > 15*pi/180)    QPSolution(1) =15*pi/180;//限幅值
//      if( QPSolution(1) < -15.0*pi /180)   QPSolution(1) = -15*pi/180; 
// double delta_v_tilde = QPSolution(0);
// double delta_Delta_tilde = QPSolution(1); //new

double delta_Delta_tilde = QPSolution(0);                                                                                       
// double delta_v_tilde = delta_U(0);
// double delta_Delta_tilde = delta_U(1);
                                                                                  
    // U(0) = kesi(3) + delta_v_tilde;
    // U(1) = kesi(4) + delta_Delta_tilde;
     U(0)= kesi(3) + delta_Delta_tilde;                                         
    // double v_real = U(0) + v_r;
    //  Delta_real =( U(1) + Delta_r);
    double v_real =1;
     Delta_real = U(0)+ Delta_r;
    // std::cout<<std::fixed<<"Delta_real "<<Delta_real<<std::endl;
    //  if(Delta_real > 26.44*pi/180)   Delta_real =26.44*pi/180;//限幅值
    //  if(Delta_real < -33.0*pi /180)  Delta_real = -33.0*pi/180; 
    //  std::cout<< "kesi: "<<kesi<<std::endl;
    std::cout<<"Delta_real "<<Delta_real<<"  delta_real: "<<delta_real<<"delta_Delta_tilde: "<<delta_Delta_tilde<<std::endl;

    // Eigen::VectorXd res(6);
    // res << v_real, Delta_real, idx, latError, U(0), U(1);
      Eigen::VectorXd res(5);
    res << v_real, Delta_real, idx, latError, U;
    outFile <<x<<","<< y<<","<< yaw<<","<<heading_r<<","<<latError<<","<<L_dis<<","<<v_real<<","<<U(0)<<","\
    <<Delta_real<<","<<delta_Delta_tilde<<","<<Delta_r<<","<<refPos_k(idx)<<std::endl;
    
    return res;
}

void    MPC::steer_control(){
    double error = fabs(Delta_real - delta_real);
    // if(error < 0.08 ){error = error *0.5*(8-fabs(error*100));}//尝试一下直接放大误差 会怎么样
     if(error < 0.08 ){error = error *1.5;}//尝试一下直接放大误差 会怎么样
    // float steer_output = pid_lat.calOutput(delta_f,delta_real);
    float steer_output = pid_lat.calOutput(error);
    lat_cmd.lat_cmd[2] = (Delta_real -delta_real) <= 0 ? 0x01:0x02;
    lat_cmd.lat_cmd[0]= fabs(steer_output);
}


void MPC::updateState(double& x, double& y, double& yaw, double v, double Delta, double dt, double Length, double max_steer) {
    double x_temp, y_temp, yaw_temp;
    Delta = (std::max(std::min(max_steer, Delta), -max_steer));
    std::cout<< "v: "<<v<<std::endl;
    x_temp = x + v * std::cos(yaw) * dt;
    y_temp = y + v * std::sin(yaw) * dt;
    yaw_temp = yaw + v / Length * std::tan(Delta) * dt;
    // std::cout<<"std::tan(Delta):  "<<std::tan(Delta)<<"   v/ Length * std::tan(Delta) * dt:  "<<v / Length * std::tan(Delta) * dt<<std::endl;
    x = x_temp;
    y = y_temp;
    yaw = yaw_temp;
    yaw =   range_angle_PI(yaw );
}


int   MPC::get_sim_flag(){
    const char* filename = "/home/nvidia/Am_navigation_SHJ_ROS1/src/common/param/param.txt";
    sim_keyword = read_txt_file(filename, "sim_flag");
    sim_flag =  std::atoi(sim_keyword.value);
}

void  MPC:: get_plan_point_start(){
    std::string filename = "/home/nvidia/Am_navigation_SHJ_ROS1/src/planning/data/wp.csv";
    // filename.append("/data/wp.csv");
    std::ifstream file_in(filename.c_str());
    if (!file_in.is_open()) {
        ROS_ERROR("planning cannot open trajectory file: [%s]", filename.c_str());
        return;
    }
    std::string line;
  // 跳过表头
    getline(file_in, line);
    getline(file_in, line);
    std::vector<std::string>  tokens = Split(line, ",");
    plan_point_start.x = std::atof(tokens[0].c_str());
    plan_point_start.y = std::atof(tokens[1].c_str());
    plan_point_start.heading = std::atof(tokens[8].c_str());

    std::cout<<plan_point_start.x<<std::endl;
    this->pose_car.x  =plan_point_start.x;
    this->pose_car.y  =plan_point_start.y;
    this->pose_car.heading  =plan_point_start.heading;
    file_in.close();
}

void  MPC::data_save_init(){
outFile.open("/home/nvidia/Am_navigation_SHJ_ROS1/mpc_data.csv", std::ios::out | std::ios::trunc);
outFile <<"x"<<","<< "y"<<","<< "heading"<<","<<"heading_r"<<","<<"Error"<<","<<"L_dis"<<","\
                <<"v"<<","<<"d_v"<<","<< "delta"<<","<<"d_delat"<<std::endl;
outFile.fixed;
outFile.precision(10);
}
