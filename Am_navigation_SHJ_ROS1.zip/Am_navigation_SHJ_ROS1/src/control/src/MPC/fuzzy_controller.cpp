#include"Control/fuzzy_controller.h"
#include <cmath>

Fuzzy_controller::Fuzzy_controller(float x1_max,float x2_max,float u_max):
x1max(x1_max),x2max(x2_max),umax(u_max),x1_mf_paras(NULL),x2_mf_paras(NULL),u_mf_paras(NULL)
{
   //Kx1=(N/2)/x1max;
   //Kx2=(N/2)/x2max;
   //Ku=umax/(N/2);
	Kx1 = 1;
	Kx2 = 1;
	Ku = 1;
   mf_t_x1="trimf";
   mf_t_x2="trimf";
   mf_t_u="trimf";
}

Fuzzy_controller::~Fuzzy_controller()
{
  delete [] x1_mf_paras;
  delete [] x2_mf_paras;
  delete [] u_mf_paras;
}
//三角隶属度函数定义
float Fuzzy_controller::trimf(float x,float a,float b,float c)
{
   float u;
   if (x >= a && x <= b && b == a)
	   u = (c - x) / (c - b);
   else if (x >= a && x <= b)
	   u = (x - a) / (b - a);
   else if (x > b && x <= c)
	   u = (c - x) / (c - b);
   else if (x > b && x <= c && b == c)
	   u = (x - a) / (b - a);
   else
	   u=0.0;
   return u;

}
//高斯隶属度函数定义
float Fuzzy_controller::gaussmf(float x,float ave,float sigma) 
{
	float u;
	if(sigma<0)
	{
	   cout<<"In gaussmf, sigma must larger than 0"<<endl;
	}
	u=exp(-pow(((x-ave)/sigma),2));
	return u;
}
//梯形隶属度函数定义
float Fuzzy_controller::trapmf(float x,float a,float b,float c,float d)
{
    float u;
	if(x>=a&&x<b)
		u=(x-a)/(b-a);
	else if(x>=b&&x<c)
        u=1;
	else if(x>=c&&x<=d)
		u=(d-x)/(d-c);
	else
		u=0;
	return u;
}

void Fuzzy_controller::setRule(double rulelist[N][N])
{
	for(int i=0;i<N;i++)
	   for(int j=0;j<N;j++)
	     rule[i][j]=rulelist[i][j];
}

//设置控制器隶属度函数
void Fuzzy_controller::setMf(const string & mf_type_x1,float *x1_mf,const string & mf_type_x2,float *x2_mf,const string & mf_type_u,float *u_mf)
{
	if(mf_type_x1=="trimf"||mf_type_x1=="gaussmf"||mf_type_x1=="trapmf")
	    mf_t_x1=mf_type_x1;
	else
		cout<<"Type of membership function must be \"trimf\" or \"gaussmf\" or \"trapmf\""<<endl;

	if(mf_type_x2=="trimf"||mf_type_x2=="gaussmf"||mf_type_x2=="trapmf")
	    mf_t_x2=mf_type_x2;
	else
		cout<<"Type of membership function must be \"trimf\" or \"gaussmf\" or \"trapmf\""<<endl;

	if(mf_type_u=="trimf"||mf_type_u=="gaussmf"||mf_type_u=="trapmf")
	    mf_t_u=mf_type_u;
	else
		cout<<"Type of membership function must be \"trimf\" or \"gaussmf\" or \"trapmf\""<<endl;
	x1_mf_paras=new float [N*3];
	x2_mf_paras=new float [N*3];
	u_mf_paras=new float [N*3];
    for(int i=0;i<N*3;i++)
	   x1_mf_paras[i]=x1_mf[i];
	for(int i=0;i<N*3;i++)
	   x2_mf_paras[i]=x2_mf[i];
	for(int i=0;i<N*3;i++)
	   u_mf_paras[i]=u_mf[i];
}
//控制器实现过程
float Fuzzy_controller::realize(float t,float a)   
{
	float u_x1[N],u_x2[N],u_u[N];
	int u_x1_index[3],u_x2_index[3];                         //激活个数
	float u;
	int M;
	x1=Kx1*t;
	x2=Kx2*a;
	if(mf_t_x1=="trimf")
		M=3;               
    else if(mf_t_x1=="gaussmf")
	    M=2;            
	else if(mf_t_x1=="trapmf")
		M=4;              
	int j=0;
	for(int i=0;i<N;i++)
	{
		u_x1[i]=trimf(x1,x1_mf_paras[i*M],x1_mf_paras[i*M+1],x1_mf_paras[i*M+2]);//x1模糊化后的隶属度
		if(u_x1[i]!=0)
            u_x1_index[j++]=i;                                              
	}
	for(;j<3;j++)u_x1_index[j]=0;

	if(mf_t_x2=="trimf")
		M=3;               
    else if(mf_t_x2=="gaussmf")
	    M=2;               
	else if(mf_t_x2=="trapmf")
		M=4;               
	j=0;
	for(int i=0;i<N;i++)
	{
		u_x2[i]=trimf(x2,x2_mf_paras[i*M],x2_mf_paras[i*M+1],x2_mf_paras[i*M+2]);//x2模糊化后的隶属度
		if(u_x2[i]!=0)
			u_x2_index[j++]=i;                                                      
	}
	for(;j<3;j++)u_x2_index[j]=0;

	float den=0,num=0;
	for(int m=0;m<3;m++)
		for(int n=0;n<3;n++)
		{
		   num+=u_x1[u_x1_index[m]]*u_x2[u_x2_index[n]]*rule[u_x1_index[m]][u_x2_index[n]];
		   den+=u_x1[u_x1_index[m]]*u_x2[u_x2_index[n]];
		}
	if(den == 0) den += 1e-7;
	u=num/den;
	u=Ku*u;
	if(u>=umax)   u=umax;
	else if(u<=-umax)  u=-umax;
	//e_pre=e;
	return u;
}
void Fuzzy_controller::showMf(const string & type,float *mf_paras)
{
    int tab;
	if(type=="trimf")
		tab=2;
	else if(type=="gaussmf")
		tab==1;
	else if(type=="trapmf")
		tab=3;
	cout<<"函数类型"<<mf_t_x1<<endl;
	cout<<"函数参数列表"<<endl;
	float *p=mf_paras;
	for(int i=0;i<N*(tab+1);i++)
	  {
		  cout.width(3);
	      cout<<p[i]<<"  ";
		  if(i%3==tab)
			  cout<<endl;
	  }
}
void Fuzzy_controller::showInfo()
{
   cout<<"Info of this fuzzy controller is as following:"<<endl;
   cout<<"输入1基本论域["<<-x1max<<","<<x1max<<"]"<<endl;
   cout<<"输入2基本论域["<<-x2max<<","<<x2max<<"]"<<endl;
   cout<<"输出u基本论域["<<-umax<<","<<umax<<"]"<<endl;
   cout<<"输入1隶属度函数参数"<<endl;
   showMf(mf_t_x1,x1_mf_paras);
   cout<<"输入2隶属度函数参数"<<endl;
   showMf(mf_t_x2,x2_mf_paras);
   cout<<"输出u隶属度函数参数"<<endl;
   showMf(mf_t_u,u_mf_paras);
   cout<<"模糊规则表"<<endl;
   for(int i=0;i<N;i++)
   {
	 for(int j=0;j<N;j++)
	   {
		 cout.width(3);
		 cout<<rule[i][j]<<"  ";
	    }
	   cout<<endl;
   }
   cout<<endl;
   cout<<"输入1量化因子Ke="<<Kx1<<endl;
   cout<<"输入2量化因子Kde="<<Kx2<<endl;
   cout<<"输出u量化因子Ku="<<Ku<<endl;
   cout<<endl;
}