﻿#include <Control/tool_control.h>

/*路径订阅回调函数 */
void tool_control::callback_path(const common::Path &  path_paln){
    path_point.clear();
    for(int i = 0;i<path_paln.path.size();i+=2){
        path_point.push_back(path_paln.path[i]);}
}

void tool_control::callback_pose(const common::Pose & Pose_point){
    pose_car.x = Pose_point.x;
    pose_car.y = Pose_point.y;
    pose_car.heading = Pose_point.heading/180.0*3.1415926;
   //std::cout<< "当前农机姿态： ("<<pose_car.x<<" , "<<pose_car.y<<" , "<<pose_car.heading<<")"<<std::endl<<std::endl;
}

void tool_control::tool_control_init(){
    tool_cmd.tool_cmd [0] = 0x00;tool_cmd.tool_cmd [1] = 0x00;tool_cmd.tool_cmd [2] = 0xfa;tool_cmd.tool_cmd [3] = 0xfa;
    tool_cmd.tool_cmd [4] = 0xfa;tool_cmd.tool_cmd [5] = 0x00;tool_cmd.tool_cmd [6] = 0x00;tool_cmd.tool_cmd [7] = 0x00;
}
void tool_control::tool_taishengqi_init(ros::Publisher   tool_control_pub ){
        static  int init_num = 10, init_num1 = 10;
        while(init_num ){
            tool_cmd.tool_cmd [6] = 0x00;
            tool_control_pub.publish(tool_cmd);
            usleep(100000);
            tool_cmd.tool_cmd [6] = 0x01;
            tool_control_pub.publish(tool_cmd);
            usleep(100000);
            init_num --;
            std::cout<< "Enable_bit-----0------>1"<<std::endl;
    }
    while(! init_num && init_num1){
    tool_cmd.tool_cmd [5] = 0x00; tool_cmd.tool_cmd [6] = 0x01;
    tool_control_pub.publish(tool_cmd);
    usleep(100000);
    tool_cmd.tool_cmd [5] = 0x01; tool_cmd.tool_cmd [6] = 0x01;
    tool_control_pub.publish(tool_cmd);
    usleep(100000);
    tool_cmd.tool_cmd [5] = 0x00; tool_cmd.tool_cmd [6] = 0x01;
    tool_control_pub.publish(tool_cmd);
//    usleep(100000);
    init_num1 --;
    std::cout<< "stop----->up---->stop"<<std::endl;
   }      
    for(int i = 0;i<30;i++){
        tool_cmd.tool_cmd [5] = 0x01; tool_cmd.tool_cmd [6] = 0x01;
        tool_control_pub.publish(tool_cmd);
        usleep(100000);
        std::cout<< "inti-----------------taishegng"<<std::endl;
    }
    // static  unsigned char   cmd_toos[] = {0xff,0xff,0xff,0xff,0xff,0x01,0x01,0x00};
    tool_cmd.tool_cmd [0] = 0xff;tool_cmd.tool_cmd [1] = 0xff;tool_cmd.tool_cmd [2] = 0xff;tool_cmd.tool_cmd [3] = 0xff;
    tool_cmd.tool_cmd [4] = 0xff;tool_cmd.tool_cmd [5] = 0x01;tool_cmd.tool_cmd [6] = 0x01;tool_cmd.tool_cmd [7] = 0x00;
}

int  tool_control::get_tool_control_cmd(){
    //寻找距离当前农机位置的最近点的ID
    std::vector<double> dis;
    for(int  i =0;i<path_point.size();i++){
         dis.push_back(sqrt((pose_car.x - path_point[i].x)*(pose_car.x - path_point[i].x)   + (pose_car.y - path_point[i].y) * (pose_car.y -path_point[i].y)));
    }
    int ref_num = dis.size();
    if(ref_num == 0){ ROS_WARN("The number of reference path points received is 0");  return 0;}
    int min_id = min_element(dis.begin(),dis.end()) - dis.begin();
    double L_dis_min_id = sqrt(( path_point[min_id].x - pose_car.x)* (path_point[min_id].x - pose_car.x) + ( path_point[min_id].y - pose_car.y)*( path_point[min_id].y - pose_car.y));
    if(L_dis_min_id  < 0.5){
        if(path_point[min_id].toos==1){
            tool_cmd.tool_cmd[5] = 2;
        }
        else{
              tool_cmd.tool_cmd[5] = 1;
        }
      
        std::cout<<(float)L_dis_min_id<< "   tool_cmd.tool_cmd[5] :"<<(int)tool_cmd.tool_cmd[5] <<std::endl;
     }
     else{
        tool_cmd.tool_cmd[5] = 0x00;
        std::cout<<(float)L_dis_min_id<< "    tool_cmd.tool_cmd[5] :"<<(int)tool_cmd.tool_cmd[5] <<std::endl;
     }
     return 0;
}

