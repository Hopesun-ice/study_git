﻿#include<Control/tool_control.h>
int main(int argc, char** argv){
    ros::init(argc,argv,"Tool_Node" );
    ros::NodeHandle n;
    ros::Rate rate(50);
    tool_control   tool_control_car;
    ros::Publisher   tool_control_pub = n.advertise<vehicle_chassis::tool_1204>("tool_control_cmd",1);  
    ros::Subscriber sub_path = n.subscribe("plan", 1,&tool_control::callback_path, &tool_control_car);
        ros::Subscriber sub_pose = n.subscribe("pose", 1,&tool_control::callback_pose, &tool_control_car);
    tool_control_car.tool_taishengqi_init(tool_control_pub);
    while(ros::ok())
    {
        tool_control_car.get_tool_control_cmd();
        tool_control_pub.publish(tool_control_car.tool_cmd);
        ros::spinOnce();
        rate.sleep();
    }
    return 0;
}