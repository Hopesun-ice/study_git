﻿#include <ros/ros.h>
#include "Control/lon_control.h"
#include "Control/pid.h"
int main(int argc, char** argv)
{
    ros::init(argc,argv,"Lon_Node" );
    ros::NodeHandle n;
    lon_control   lon_control_car;
    lon_control_car.get_lon_params();
    n.setParam("/xielianglihe",0);
    n.setParam("/xieliangtong", 0);
    // std::cout<<"lon_control_car.lon_set_v_keyword:  "<<lon_control_car.set_v<<std::endl;
    // std::cout<<"lon_control_car.source_v_flag_keyword:  "<<lon_control_car.source_v_flag<<std::endl;

    ros::Subscriber sub_path = n.subscribe("plan", 1,&lon_control::callback_path, &lon_control_car);
    ros::Subscriber sub_pose = n.subscribe("pose", 1,&lon_control::callback_pose, &lon_control_car);
    ros::Publisher   lon_control_pub = n.advertise<vehicle_chassis::lon_1204>("lon_control_cmd",1);  
    ros::Publisher   sim_pose_pub = n.advertise<common::Pose>("pose",1);
    ros::Subscriber sub_car_stop = n.subscribe("Topic_Car_stop", 1,&lon_control::callback_car_stop, &lon_control_car);
    ros::Subscriber beiginorpause = n.subscribe("beiginorpause", 1,&lon_control::callback_beiginorpause, &lon_control_car);
    ros::Subscriber sub_car_precetpion = n.subscribe("yolov5/BoundingBoxes", 1,&lon_control::callback_perception, &lon_control_car);
    ros::Subscriber sub_grain_full = n.subscribe("topic_grain_full", 1,&lon_control::callback_grain_full, &lon_control_car);
    ros::Rate rate(10);
    while(ros::ok())
    {
        lon_control_car.get_rosparam(n);
        // lon_control_car.beginorstop_flag = lon_control_car.get_beginorstop_flag();
        std::cout<<"  lon_control_car.beginorstop_flag: "<<  lon_control_car.beginorstop_flag<<std::endl;
        if(lon_control_car.beginorstop_flag  &&  !lon_control_car.perception_flag && !lon_control_car.grain_full_msg.data){
            if(lon_control_car.lon_control_stop){lon_control_car.lon_v_stop();}
            else{ lon_control_car.get_lon_control_cmd();}
            lon_control_car.fun_xieliang();
            lon_control_pub.publish(lon_control_car.lon_cmd);
            std::cout<<"lon_control_car. lon_cmd.v: "<<lon_control_car. lon_cmd.v <<std::endl;
        }
        else{
            lon_control_car.lon_v_stop();
            lon_control_car.fun_xieliang();
            lon_control_pub.publish(lon_control_car.lon_cmd);
        }
        ros::spinOnce();
        rate.sleep();
    }
    return 0;
}