﻿#include "Control/lon_control.h" 
#include <ros/ros.h>
#include <cmath>
#include <vector>
#include "unistd.h"
using namespace std;
/*路径订阅回调函数 */
void lon_control::callback_path(const common::Path &  path_paln){
    path_point.clear();
    for(int i = 0;i<path_paln.path.size();i+=2){
        path_point.push_back(path_paln.path[i]);}
}
void lon_control::callback_pose(const common::Pose & Pose_point){
    pose_car.x = Pose_point.x;
    pose_car.y = Pose_point.y;
    pose_car.heading = Pose_point.heading/180.0*3.1415926;
    pose_car.v = Pose_point.v;
   //std::cout<< "当前农机姿态： ("<<pose_car.x<<" , "<<pose_car.y<<" , "<<pose_car.heading<<")"<<std::endl<<std::endl;
}
void lon_control::callback_car_stop(const std_msgs::Bool & sub_car_stop){
    lon_control_stop = sub_car_stop.data;
}

void lon_control::callback_beiginorpause(const std_msgs::Bool & sub_car_beiginorpause){
    beginorstop_flag = sub_car_beiginorpause.data;
}

void lon_control:: callback_perception(const yolov5_ros_msgs::BoundingBoxes &  car_perception){
    static int num_car_perception = 0;
    static int num_car_perception_false = 0;
    if(car_perception.bounding_boxes[0].num>0){
        num_car_perception++;
        if(num_car_perception > 30){
            num_car_perception = 0;
            perception_flag = true;
            std::cout<< "true"<<std::endl;
        }
    }
    else{
        num_car_perception_false ++ ;
        if(num_car_perception_false > 50){
            perception_flag = false;
           std::cout<< "false"<<std::endl;
        }
    }
}

void lon_control::callback_grain_full(const std_msgs::UInt8& msg){
    if(msg.data == 0x02)  grain_full_msg.data = 1;
    else grain_full_msg.data = 0;
}
void  lon_control::control_init(){
    pid_lon.setK(10.0,0,0); pid_lon.setBound(0.5,-0.5);
    //这里字节（1-N）的内容分别代表：字节1：前进百分比   字节2：后退百分比  字节3：割台高度  字节4：车辆启动熄火指令
    //字节5：车辆动作指令  字节6：割台动作指令  字节7：拨禾轮动作指令  字节8：主离合控制指令 字节9：卸粮桶旋转指令 
    //字节10：卸粮离合控制指令  字节11：割台线性调节或者点动
    lon_cmd.lon_cmd[0] = 0x00;  lon_cmd.lon_cmd[1] = 0x00;lon_cmd.lon_cmd[2] = 0x50;  lon_cmd.lon_cmd[3] = 0x00;
    lon_cmd.lon_cmd[4] = 0x00;  lon_cmd.lon_cmd[5] = 0x00;lon_cmd.lon_cmd[6] = 0x00;  lon_cmd.lon_cmd[7] = 0x00;
    lon_cmd.lon_cmd[8] = 0x00;  lon_cmd.lon_cmd[9] = 0x00; lon_cmd.lon_cmd[10] = 0x01;  
    lon_cmd.lon_cmd[11] = 0xe0; lon_cmd.lon_cmd[12] = 0x2e;
} 

int  lon_control::get_lon_v(){
    std::vector<double> dis;
    for(int  i =0;i<path_point.size();i++){
        dis.push_back(sqrt((pose_car.x - path_point[i].x)*(pose_car.x - path_point[i].x)   + (pose_car.y - path_point[i].y) * (pose_car.y -path_point[i].y)));
    }
    int ref_num = dis.size();
    lon_cmd.v   = set_v;  lon_cmd.gear  =1;
    if(ref_num == 0){ ROS_WARN("The number of reference path points received is 0");  return 0;}
    int min_id = min_element(dis.begin(),dis.end()) - dis.begin();
    int idx = min_id;
    static  int  idx_target,Ld=3;
    float L_steps = 0,average_cur = 0,k_v = 1;
    while(L_steps < Ld && idx < ref_num - 1){
        float x =  path_point[idx+1].x - path_point[idx].x;
        float y =  path_point[idx+1].y - path_point[idx].y;
        float dis_step = sqrt(x*x + y*y);
        L_steps  += dis_step;
        average_cur  +=fabs(path_point[idx].curvature);
        idx++;
    }
    idx_target = idx ;
    average_cur = average_cur /(idx_target - min_id);

    //这里要注意 只有在地里面收割的时候 这个主离合才起作用
    if(path_point[min_id]. toos == 1)   lon_cmd.lon_cmd[7] =0x04;
    else if(path_point[min_id]. toos == 2)   lon_cmd.lon_cmd[7] =0x08; 
    else lon_cmd.lon_cmd[7] = 0;
    
    if(source_v_flag){
        lon_cmd.v  = path_point[min_id].v;
        if(path_point[min_id].gear ==1) lon_cmd.gear  = 0x04;
        else lon_cmd.gear  =0x08;}
    else{
        lon_cmd.v   = set_v;
        lon_cmd.gear  = path_point[min_id].gear;}
    if(!beginorstop_flag) {lon_cmd.gear = 0x00;}
    return 0;
}
void  lon_control::get_lon_control_cmd(){
    get_lon_v(); 
    static int l_rpm = 0;static int  u_rpm=100;;static float inc_rpm=0;static   float temp_rmp=0;
    inc_rpm = (pid_lon.calOutput(lon_cmd.v,pose_car.v));
    temp_rmp = pose_car.v  < 0.1 ? 0 :   (temp_rmp +=  inc_rpm);
    temp_rmp =( (temp_rmp)  < l_rpm ?  l_rpm : temp_rmp);
    temp_rmp = ((temp_rmp)  > u_rpm ?  u_rpm : temp_rmp);
    lon_cmd.lon_cmd[4] = lon_cmd.gear;  //车辆动作指令
    if(lon_cmd.lon_cmd[4] == 0x04) { lon_cmd.lon_cmd[0] = temp_rmp;} //前进百分比
    else if(lon_cmd.lon_cmd[4] == 0x08) { lon_cmd.lon_cmd[1] = temp_rmp;}//后退百分比

    std::cout<< "set_v:"<<lon_cmd.v<< "car_V:"<<pose_car.v<<std::endl;
    std::cout<<"inc_rpm:"<<inc_rpm<<std::endl;
}

void  lon_control::get_lon_params(){
    const char* filename = "/home/nvidia/Am_navigation_SHJ_ROS1/src/common/param/param.txt";
    source_v_flag_keyword = read_txt_file(filename, "source_v_flag");
    source_v_flag =  std::atoi(source_v_flag_keyword.value);
    lon_set_v_keyword = read_txt_file(filename, "set_lon_v");
    set_v =  std::atof(lon_set_v_keyword.value);
}
void  lon_control::lon_v_stop(){
    lon_cmd.lon_cmd[0] = 0;
    lon_cmd.lon_cmd[1] = 0;
    lon_cmd.lon_cmd[4] = 0;
}

bool  lon_control::get_beginorstop_flag(){
        static std::string filename = "/home/nvidia/Am_navagation_version_1.0/output.txt";
        std::string lastLine = ReadLastLine(filename);
        if(std::atoi(lastLine.c_str())){ return true;}
        else{return false;}
}
void lon_control::get_rosparam(ros::NodeHandle nh){
    nh.getParam("/xieliangtong", xieliangtong);
    nh.getParam("/xielianglihe", xielianglihe);
//     std::cout<< nh.getParam("/xieliangtong", xieliangtong)<<std::endl;
//     std::cout<< "xieliangtong: "<<xieliangtong<<std::endl;
//     std::cout<< nh.getParam("/xielianglihe", xielianglihe)<<std::endl;
//     std::cout<< "xielianglehe: "<<xielianglihe<<std::endl;
}
void  lon_control::fun_xieliang(){
    if (xieliangtong == 1)   lon_cmd.lon_cmd[8]  = 0x04;
    else if  (xieliangtong == 2)   lon_cmd.lon_cmd[8]  = 0x08;
    else   lon_cmd.lon_cmd[8]  = 0x00;

    if(xielianglihe == 0)  lon_cmd.lon_cmd[9]  = 0x40;
    else if(xielianglihe == 1)  lon_cmd.lon_cmd[9]  = 0x80;
    else lon_cmd.lon_cmd[9]  = 0x00;
}