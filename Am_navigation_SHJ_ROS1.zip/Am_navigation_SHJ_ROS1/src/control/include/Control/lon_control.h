﻿#ifndef LON_CONTROL_H
#define LON_CONTROL_H
#include <common/Pose.h>
#include <common/Path.h>
#include <common/Pathpoint.h>
#include <Control/pid.h>
#include <iostream>
#include <common/common.h>
#include <std_msgs/Float32.h>
#include<vehicle_chassis/lon_1204.h>
#include <std_msgs/Bool.h>
#include "yolov5_ros_msgs/BoundingBoxes.h"
#include "std_msgs/UInt8.h"
class lon_control
{
public:
    lon_control(){control_init();};
    void control_init();
    void callback_path(const common::Path & path_paln);    //路径回调函数
    void callback_pose(const common::Pose & Pose_point);    //定位回调函数
    void callback_car_stop (const std_msgs::Bool & car_stop); //车辆停止回调函数
    void callback_perception(const yolov5_ros_msgs::BoundingBoxes &  car_perception);//感知回调函数
    int     get_lon_v();
    void  get_lon_control_cmd();
    void  get_lon_params();
    void  lon_v_stop();
    void  get_rosparam(ros::NodeHandle nh);
    void fun_xieliang();
    void callback_grain_full(const std_msgs::UInt8& msg);
    PID_controller pid_lon;
    std::vector <common::Pathpoint> path_point;    //定义路径vector  path_point
    common::Pose  pose_car ;
    vehicle_chassis::lon_1204  lon_cmd;
    bool lon_control_stop = false;

    bool source_v_flag = true;//速度来源标志位
    double set_v = 1;
    Keyword lon_set_v_keyword;Keyword source_v_flag_keyword;
    bool  perception_flag = false;

    //人机交互
    bool  beginorstop_flag = false;
    bool  get_beginorstop_flag();
    void callback_beiginorpause(const std_msgs::Bool & sub_car_beiginorpause);

    int  xieliangtong,xielianglihe;
    std_msgs::UInt8  grain_full_msg;

};
#endif
