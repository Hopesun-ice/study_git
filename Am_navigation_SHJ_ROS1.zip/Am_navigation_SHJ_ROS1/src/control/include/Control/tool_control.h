﻿#ifndef __TOOL_CONTROL_H__
#define __TOOL_CONTROL_H__
#include <iostream>
#include <common/Pose.h>
#include<common/common.h>
#include <common/Pathpoint.h>
#include <common/Path.h>
#include<vehicle_chassis/tool_1204.h>
#include<ros/ros.h>

class tool_control
{
    public:
        tool_control(){tool_control_init();};
        void tool_control_init();
        void tool_taishengqi_init(ros::Publisher   toos_control_pub );
        void callback_pose(const common::Pose & Pose_point);    //定位回调函数
        void callback_path(const common::Path &  path_paln);  //路径回调函数
        int  get_tool_control_cmd();
        common::Pose  pose_car ;
        vehicle_chassis::tool_1204  tool_cmd;
        std::vector <common::Pathpoint> path_point;    //定义路径vector  path_point
};
#endif