﻿#ifndef LAT_CONTROL_H
#define LAT_CONTROL_H
#include <common/Pose.h>
#include <common/Path.h>
#include <common/Pathpoint.h>
#include <Control/pid.h>
#include <iostream>
#include<vehicle_chassis/lat_1204.h>
#include <common/common.h>
#include <std_msgs/Float32.h>
#include <std_msgs/Int32.h>
#include <nav_msgs/Path.h>
#include <ros/package.h>
#include <fstream>
#include <std_msgs/Bool.h>
#include "yolov5_ros_msgs/BoundingBoxes.h"
class lat_control
{
public:
    lat_control(){ control_init();};
    void control_init();
    void callback_path(const common::Path & path_paln);    //路径回调函数
    void callback_pose(const common::Pose & Pose_point);    //定位回调函数
    void callback_delta(const std_msgs::Float32  & deltae ); //前轮转角回调函数
    void callback_car_stop (const std_msgs::Bool & car_stop); //车辆停止回调函数
    void callback_perception(const yolov5_ros_msgs::BoundingBoxes &  car_perception);//感知回调函数

    double  ptca(); //计算前轮转角 delta_f
    void    steer_control();//计算方向盘控制量

    
    PID_controller pid_lat;
    std::vector <common::Pathpoint> path_point;    //定义路径vector  path_point
    common::Pose  pose_car ;
    vehicle_chassis::lat_1204  lat_cmd;
    double delta_f,delta_real,delta_last=0; float Ld0 = 1.2,Ld = 3,k_v = 1.2;
    bool lat_control_stop = false;
    std_msgs::Int32 diretion;


    //仿真相关
    Keyword sim_keyword;
    bool  sim_flag = true;
    int   sim_dead_reckoning();
    common::Pathpoint  plan_point_start;
    void get_plan_point_start();
    int  get_sim_flag();

    //数据保存
    std::ofstream outFile, hmi_file;
    void  data_save_init();

    //人机交互
    bool  beginorstop_flag = false;
    bool  get_beginorstop_flag();
    void callback_beiginorpause(const std_msgs::Bool & sub_car_beiginorpause);
};
#endif