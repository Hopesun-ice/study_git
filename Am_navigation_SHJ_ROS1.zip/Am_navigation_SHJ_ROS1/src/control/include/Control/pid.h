#ifndef PID_H
#define PID_H
#include <iostream>

using namespace std;

/**
 * 位置式PID实现
 */
class PID_controller {
public:
    double kp,  ki, kd, upper,  lower;
    double error=0.0,pre_error=0.0,sum_error=0.0;
public:
    PID_controller(){};
    PID_controller(double kp, double ki, double kd,double upper, double lower);

    void setK(double kp,double ki,double kd );

    void setBound(double upper,double lower);

    double calOutput(double target ,double state);
    
    double calOutput(double err);

    void reset();

    void setSumError(double sum_error);
};
#endif