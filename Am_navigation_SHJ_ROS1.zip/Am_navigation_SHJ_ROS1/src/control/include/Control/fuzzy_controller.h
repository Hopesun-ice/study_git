#ifndef FUZZY_CONTROLLER_H_
#define FUZZY_CONTROLLER_H_
#include<iostream>
#include<string>
using namespace std;

class Fuzzy_controller
{
public:
	const static int N=7;
private:
	float x1;     //模糊控制器输入1
	float x2;     //模糊控制器输入2
	float x1max;  //输入1基本论域上限
	float x2max;  //输入2基本论域上限
	float umax;    //输出u基本论域上限
	float Kx1;    //量化因子
	float Kx2;    
	float Ku;      
	double rule[N][N];//模糊规则
	string mf_t_x1;   //隶属度函数类型
	string mf_t_x2;   
	string mf_t_u;    
	float *x1_mf_paras; //隶属度函数参数
	float *x2_mf_paras; 
	float *u_mf_paras;  

public:
	Fuzzy_controller(){}
	Fuzzy_controller(float x1_max,float x2_max,float u_max);
	~Fuzzy_controller();
	float trimf(float x,float a,float b,float c);                  //三角隶属度函数
	float gaussmf(float x,float ave,float sigma);            //高斯隶属度函数
	float trapmf(float x,float a,float b,float c,float d); //梯形隶属度函数
	void setMf(const string & mf_type_x1,float *x1_mf,const string & mf_type_x2,float *x2_mf,const string & mf_type_u,float *u_mf);//设置模糊隶属度函数参数
	void setRule(double rulelist[N][N]);                            //设置模糊规则
	float realize(float t,float a);								              //实现模糊控制
	void showInfo();                                                                //显示模糊控制器信息
	void showMf(const string & type,float *mf_paras); //显示隶属度函数信息        
};
#endif