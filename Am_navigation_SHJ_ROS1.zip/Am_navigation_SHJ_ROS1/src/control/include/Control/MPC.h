#pragma once
#include <eigen3/Eigen/Dense>
#include <iostream>
#include <vector>
#include <cmath>
#include <ros/ros.h>
#include <common/common.h>
#include <common/Path.h>
#include <common/Pathpoint.h>
#include <Control/pid.h>
#include <std_msgs/Float32.h>
#include <std_msgs/Int32.h>
#include <common/Pose.h>
#include <nav_msgs/Path.h>
#include "yolov5_ros_msgs/BoundingBoxes.h"
#include<vehicle_chassis/lat_1204.h>
#include <std_msgs/Bool.h>
#include <ros/package.h>
#include "Control/fuzzy_controller.h"
#include "OsqpEigen/OsqpEigen.h"

class MPC : public Fuzzy_controller{
public:
	MPC();
    void mpc_init();
	Eigen::VectorXd mpc_control(double x, double y, double yaw, const Eigen::VectorXd& refPos_x, const Eigen::VectorXd& refPos_y, const Eigen::VectorXd& refPos_yaw,
		 const Eigen::VectorXd& refPos_k,const Eigen::VectorXd& refDelta, const double dt, const double L, Eigen::Vector2d& U, const double target_v);

    Eigen::VectorXd mpc_control_osqp(double x, double y, double yaw, const Eigen::VectorXd& refPos_x, const Eigen::VectorXd& refPos_y, const Eigen::VectorXd& refPos_yaw,
	 const Eigen::VectorXd& refPos_k,const Eigen::VectorXd& refDelta, const double dt, const double L, Eigen::VectorXd& U, const double target_v);
	
    int calc_target_index(double x, double y, Eigen::VectorXd refPos_x, Eigen::VectorXd refPos_y);

	void updateState(double& x, double& y, double& yaw, double v, double Delta, double dt, double Length, double max_steer); 


	void callback_path(const common::Path & path_paln);    //路径回调函数
    void callback_pose(const common::Pose & Pose_point);    //定位回调函数
    void callback_delta(const std_msgs::Float32  & delta ); //前轮转角回调函数
    void callback_car_stop (const std_msgs::Bool & car_stop); //车辆停止回调函数
    void callback_perception(const yolov5_ros_msgs::BoundingBoxes &  car_perception);//感知回调函数

    void steer_control();


	    
    PID_controller pid_lat;
     vehicle_chassis::lat_1204  lat_cmd;
	Eigen::Matrix<double, Eigen::Dynamic, 4> refPos;
    common::Pose  pose_car ;
    double delta_f,delta_real,delta_last=0; float Ld0 = 1.2,Ld = 3,k_v = 1.2;
    bool lat_control_stop = false;
	Eigen::VectorXd refPos_x;             // refPos_x
    Eigen::VectorXd refPos_y;             // refPos_y
	Eigen::VectorXd refHeading;                       // refHeading 
	Eigen::VectorXd refDelta ;     // refDelta
    Eigen::VectorXd refPos_k;     // refDelta
    std_msgs::Int32 diretion;

     double Delta_real ;

    //仿真相关
    Keyword sim_keyword;
    bool  sim_flag = true;
    int   sim_dead_reckoning();
    common::Pathpoint  plan_point_start;
    void get_plan_point_start();
    int  get_sim_flag();

    //数据保存
    std::ofstream outFile;
    void  data_save_init();

	    //人机交互
    bool  beginorstop_flag = false;
    bool  get_beginorstop_flag();
    void callback_beiginorpause(const std_msgs::Bool & sub_car_beiginorpause);
};
