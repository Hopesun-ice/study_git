﻿#ifndef __HMI_H__
#define __HMI_H__
#include <iostream>
#include <nav_msgs/Path.h>
#include <common/Pose.h>
#include <common/Path.h>
#include <geometry_msgs/Quaternion.h>
#include <geometry_msgs/PoseStamped.h>
#include<common/common.h>
#include <common/Pathpoint.h>
#include <ros/package.h>
#include <fstream>
#include <chrono>  
#include<common/common.h>
#include "frenet_cpp/CustomMsg.h" 
#include "frenet_cpp/DataArray.h"
#include <visualization_msgs/Marker.h>
#include <cmath>
#include "frenet_cpp/ObstacleArray.h"
#include "frenet_cpp/Obstaclepoint.h"
class hmi
{
public:
    hmi(){};
    void callback_pose(const common::Pose & Pose_point);    //定位回调函数
    void callback_real_plan(const common::Path & Pose_point);
    void callback_obstale(const    frenet_cpp::ObstacleArray & obstacle_point);
    void  pose_car_rviz();  
    void  real_plan_rviz();  
    void get_plan_point_start();
    nav_msgs::Path path; //在rviz中显示车辆轨迹 
    nav_msgs::Path real_plan; //在rviz中显示车辆轨迹 
    common::Pose  pose_car ;
    common::Pathpoint  plan_point_start;
    common::Path  real_plan_call;
    frenet_cpp::ObstacleArray Obstalcle_call;
   
};
#endif