﻿#include<ros/ros.h>
#include <hmi/hmi.h>

// 显示功能没有实质内容
void path2rviz(ros::Publisher& plan_show_pub,  common::Pathpoint& plan_point_start,common::Path& plan)
{
    nav_msgs::Path path;
    path.header.stamp=ros::Time::now();
    path.header.frame_id="/map";
    static int num = 0;
    num = plan.path.size() >1 ?  (plan.path.size()-1): ( plan.path.size());
    std::cout<< "plan.path.size() : "<<plan.path.size() <<std::endl;
    for (uint32_t i = 0; i < num; ++i)
    {
        geometry_msgs::PoseStamped this_pose_stamped;
        this_pose_stamped.pose.position.x = plan.path[i].x -plan_point_start.x;
        this_pose_stamped.pose.position.y = plan.path[i].y - plan_point_start.y;

        //geometry_msgs::Quaternion goal_quat = tf::createQuaternionMsgFromYaw(1);
        this_pose_stamped.pose.orientation.x = 0;
        this_pose_stamped.pose.orientation.y = 0;
        this_pose_stamped.pose.orientation.z = 0;
        this_pose_stamped.pose.orientation.w = 1;

        this_pose_stamped.header.stamp=ros::Time::now();
        this_pose_stamped.header.frame_id="/map";

        path.poses.push_back(this_pose_stamped);
    }
    plan_show_pub.publish(path);
}

void Obstale2rviz(ros::Publisher& plan_show_pub,     frenet_cpp::ObstacleArray Obstalcle_call,  common::Pathpoint& plan_point_start)
{
    visualization_msgs::Marker points, line_strip, line_list;
    points.header.frame_id = line_strip.header.frame_id = line_list.header.frame_id = "/map";
    points.header.stamp = line_strip.header.stamp = line_list.header.stamp = ros::Time::now();
    points.ns = line_strip.ns = line_list.ns = "points_and_lines";
    points.action = line_strip.action = line_list.action = visualization_msgs::Marker::ADD;
    points.pose.orientation.w = line_strip.pose.orientation.w = line_list.pose.orientation.w = 1.0;
    points.id = 0;
    points.type = visualization_msgs::Marker::POINTS;
    // POINTS markers use x and y scale for width/height respectively
    points.scale.x = 2;
    points.scale.y = 2;
    // LINE_STRIP/LINE_LIST markers use only the x component of scale, for the line width
    line_strip.scale.x = 0.1;
    line_list.scale.x = 0.1;
    // Points are green
    points.color.g = 1.0f;
    points.color.a = 1.0;     
    geometry_msgs::Point p1,p2;        
std::cout<< "plan_point_start.x: "<<plan_point_start.x<<"     "<<plan_point_start.y<<std::endl;          
      p1.x = 692993.649759 -plan_point_start.x  ;
      p1.y = 4048352.38532  -plan_point_start.y ;
      p1.z = 0;
      p2.x =692990.453275  -plan_point_start.x;
      p2.y =4048329.882 -plan_point_start.y;
      p2.z = 0;
   std::cout<< "p1.x:  "<< p1.x<<"  "<<p1.y<<std::endl;
    //     p1.x =1 ;
    //   p1.y =1 ;
    //   p1.z = 0;
    //   p2.x =2;
    //   p2.y =2;
    //   p2.z = 0;
    //   points.points.push_back(p1);     points.points.push_back(p2);
     std::vector <geometry_msgs::Point> Obstale(Obstalcle_call.obstaclepoint.size());
     std::cout<< "Obstalcle_call.obstaclepoint.size(): "<<Obstalcle_call.obstaclepoint.size()<<std::endl;
    static int num = 0;
    for(int i = 0;i< Obstalcle_call.obstaclepoint.size();i++)
    {
        Obstale[i].x = Obstalcle_call.obstaclepoint[i].x -plan_point_start.x;
        Obstale[i].y =  Obstalcle_call.obstaclepoint[i].y -plan_point_start.y;
        Obstale[i].z =  0;
        points.points.push_back(Obstale[i]);
    }
    plan_show_pub.publish(points);
}





int main(int argc, char** argv){
    ros::init(argc,argv,"Hmi_Node" );
    ros::NodeHandle n;
    hmi hmi_car;
    ros::Subscriber sub_pose = n.subscribe("pose", 1,&hmi::callback_pose, &hmi_car);
    ros::Subscriber sub_rela_plan = n.subscribe("plan", 1,&hmi::callback_real_plan, &hmi_car);
    ros::Subscriber sub_obstacle = n.subscribe("Obstacle", 1,&hmi::callback_obstale, &hmi_car);    
    ros::Publisher  path_pub = n.advertise<nav_msgs::Path>("car_trajectory",1, true);
    ros::Publisher  rela_paln_pub = n.advertise<nav_msgs::Path>("rela_paln",1, true);
    ros::Publisher marker_pub = n.advertise<visualization_msgs::Marker>("Obstacle_rviz", 10);
    ros::Rate rate(50);
    hmi_car.get_plan_point_start();
    std::cout<<hmi_car.plan_point_start.x<<std::endl;std::cout<<hmi_car.plan_point_start.y<<std::endl;
    while(ros::ok())
    {
        hmi_car.pose_car_rviz();
        path_pub.publish(hmi_car.path);
        path2rviz(rela_paln_pub,  hmi_car.plan_point_start, hmi_car.real_plan_call);
        Obstale2rviz(marker_pub,  hmi_car.Obstalcle_call,    hmi_car.plan_point_start);
        ros::spinOnce();
        rate.sleep();
    }
    return 0;
}