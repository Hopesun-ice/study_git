﻿#include<hmi/hmi.h>
void hmi::callback_pose(const common::Pose & Pose_point){
    pose_car.x = Pose_point.x;
    pose_car.y = Pose_point.y;
    pose_car.heading = Pose_point.heading/180.0*3.1415926;
   //std::cout<< "当前农机姿态： ("<<pose_car.x<<" , "<<pose_car.y<<" , "<<pose_car.heading<<")"<<std::endl<<std::endl;
}

void hmi::callback_real_plan(const common::Path & Pose_point){
        real_plan_call = Pose_point;
}

void hmi::callback_obstale(const    frenet_cpp::ObstacleArray & obstacle_point){
  
        Obstalcle_call = obstacle_point;
        // std::cout<< "callback_obstale!!!!!!!!!!"<<Obstalcle_call.obstaclepoint.size()<<std::endl;
}
void hmi:: pose_car_rviz(){
    pose_car.heading  =   range_angle_PI(pose_car.heading );
    path.header.stamp=ros::Time::now();
    path.header.frame_id="/map";
    geometry_msgs::PoseStamped this_pose_stamped;
    this_pose_stamped.pose.position.x = pose_car.x-      plan_point_start.x;
    this_pose_stamped.pose.position.y = pose_car.y- 	 plan_point_start.y; ;
    this_pose_stamped.pose.orientation.x = 0;
    this_pose_stamped.pose.orientation.y = 0;
    this_pose_stamped.pose.orientation.z = 0;
    this_pose_stamped.pose.orientation.w = 1;
    this_pose_stamped.header.stamp=ros::Time::now();
    this_pose_stamped.header.frame_id="/map";
    static int num =50;
    if(num >0){
        num -- ;
    }
else
    this->path.poses.push_back(this_pose_stamped);
}

void hmi:: real_plan_rviz(){
    // path.header.stamp=ros::Time::now();
    // path.header.frame_id="/map";
    // for(int i = 0;i<real_plan_call.size();i++){
    //     geometry_msgs::PoseStamped this_pose_stamped;
    //     this_pose_stamped.pose.position.x = pose_car.x-      plan_point_start.x;
    //     this_pose_stamped.pose.position.y = pose_car.y- 	 plan_point_start.y; ;
    //     this_pose_stamped.pose.orientation.x = 0;
    //     this_pose_stamped.pose.orientation.y = 0;
    //     this_pose_stamped.pose.orientation.z = 0;
    //     this_pose_stamped.pose.orientation.w = 1;
    //     this_pose_stamped.header.stamp=ros::Time::now();
    //     this_pose_stamped.header.frame_id="/map";
    //     this->path.poses.push_back(this_pose_stamped);
    // }
}

void  hmi:: get_plan_point_start(){
    std::string filename = ros::package::getPath(std::string("planning"));
    filename.append("/data/wp.csv");
    std::ifstream file_in(filename.c_str());
    if (!file_in.is_open()){
        ROS_ERROR("RTKPlanner cannot open trajectory file: [%s]", filename.c_str());
        return;
    }
    std::string line;
  // 跳过表头
    getline(file_in, line);
    getline(file_in, line);
    std::vector<std::string>  tokens = Split(line, ",");
    plan_point_start.x = std::atof(tokens[0].c_str());
    plan_point_start.y = std::atof(tokens[1].c_str());
    plan_point_start.heading = std::atof(tokens[8].c_str());
    file_in.close();
}