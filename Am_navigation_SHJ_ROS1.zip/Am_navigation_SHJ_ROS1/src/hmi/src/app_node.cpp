﻿#include<ros/ros.h>
#include <std_msgs/Bool.h>
#include <fstream>
#include <string>
#include <common/common.h>
int main(int argc, char** argv){
    ros::init(argc,argv,"App_Node" );
    ros::NodeHandle n;
    ros::Publisher   beiginorpause_pub = n.advertise<std_msgs::Bool>("beiginorpause",1);
    ros::Rate rate(10);
    std::string string_beginorpause;
    std_msgs::Bool beiginorpause_value;
    n.setParam("/my_parameter", "stop");
    while(ros::ok())
    {
        std::cout<<n.getParam("my_parameter",string_beginorpause)<<std::endl;
        ROS_INFO("my_parameter loaded: %s", string_beginorpause.c_str());
        if(string_beginorpause == "begin"){beiginorpause_value.data = true;}
        else{beiginorpause_value.data = false;}
        std::cout<<(int)beiginorpause_value.data<<std::endl;
        beiginorpause_pub.publish(beiginorpause_value);
        ros::spinOnce();
        rate.sleep();
    }
    return 0;
}