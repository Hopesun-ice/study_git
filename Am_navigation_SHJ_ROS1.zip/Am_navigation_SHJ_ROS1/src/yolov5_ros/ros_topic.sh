#!/bin/bash

cd /home/beidou/ros_yolov5

source devel/setup.bash

rostopic echo /yolov5/BoundingBoxes


