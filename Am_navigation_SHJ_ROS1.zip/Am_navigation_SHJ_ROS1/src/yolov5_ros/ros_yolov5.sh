#!/bin/bash

cd /home/beidou/ros_yolov5

source devel/setup.bash

roslaunch yolov5_ros yolov5.launch


