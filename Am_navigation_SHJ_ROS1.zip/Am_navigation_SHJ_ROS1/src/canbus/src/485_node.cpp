﻿#include "ros/ros.h"
#include "canbus/485.h"
#include  <common/common.h>
#include<vehicle_chassis/lat_1204.h>
//01 06 01 95 01 F4 98 0D  uint16_t  CRC16_2(unsigned char *buf, int len)
uint8_t  send_data_485[8];
//横向
void lat_control_callback( const vehicle_chassis::lat_1204  & lat_cmd){
    for(int i = 0;i<sizeof(send_data_485);i++){
        send_data_485[i] = lat_cmd.lat_cmd[i];
        std::cout<<(int) lat_cmd.lat_cmd[i]<<"  ";
    }
    std::cout<<std::endl;    std::cout<<std::endl;
    pwm(send_data_485);
}

void test_485_pwm(){
    static uint8_t  send_data_485_pwm1[8]={0x01,0x06,0x01,0x94,0x01,0xf4,0xc9,0xcd};
    static uint8_t  send_data_485_pwm2[8]={0x01,0x06,0x01,0x95,0x00,0x20,0x99,0xc2};


    pwm(send_data_485_pwm2);
    usleep(3000*1000);
    // pwm(send_data_485_pwm1);
    // usleep(3000*1000);
}
int main(int argc, char** argv)
{
    Debug_Info("485_node_start");
    ros::init(argc,argv,"Serial_485_Node" );
    ros::NodeHandle n;
     fun_init_com();
     pwm_init();
    ros::Subscriber sub_lat_control = n.subscribe("lat_control_cmd", 1,&lat_control_callback);
    ros::Rate r(20);
    while(ros::ok()){
        // test_485_pwm();
        r.sleep();  
        ros::spinOnce();
    }
    return 0;
}