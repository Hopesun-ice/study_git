﻿#include "canbus/485.h"
#include <iostream>
#include <cmath>
#include "std_msgs/Float32.h"
#include "location/serial.h"
using namespace std;
const char *dev  = "/dev/ttyUART_485_422_B";
serialPort myserial;

bool fun_init_com(){
    int i,nread,nwrite;
    int LenBuffer;
    myserial.OpenPort(dev);
    myserial.setup(19200,0,8,1,'N'); 
}

void  modbus_wirte(uint8_t *src){
   myserial.writeBuffer( src, 8);
   usleep(10*1000);
}
void pwm_init(){
      static uint8_t pwm_1_open[8] = {0x01,0x06,0x01,0x90,0x00,0x01,0x49,0xDB};
      static uint8_t pwm_2_open[8] = {0x01,0x06,0x01,0x91,0x00,0x01,0x18,0x1B};
      static uint8_t pwm_2_0[8] = {0x01,0x06,0x01,0x95,0x00,0x00,0x98,0x1A};
      static uint8_t pwm_1_0[8] = {0x01,0x06,0x01,0x94,0x00,0x00,0xc9,0xda};
      myserial.writeBuffer( pwm_1_open, 8);
      usleep(50*1000);
      myserial.writeBuffer( pwm_2_open, 8);
      usleep(50*1000);
      myserial.writeBuffer( pwm_2_0, 8);
      usleep(20*1000);
      myserial.writeBuffer( pwm_1_0, 8);
      usleep(20*1000);
}
void pwm(uint8_t *src){
    if(src[3] == 0x94){   //PWM1起作用
    //关闭PWM2   字节为： 01 06 01 91 00 00 D9 DB
    static uint8_t pwm_2_0[8] = {0x01,0x06,0x01,0x95,0x00,0x00,0x98,0x1A};
    myserial.writeBuffer( pwm_2_0, 8);
    usleep(30*1000);
    //设置PWM1占空比 
    myserial.writeBuffer( src, 8);
     usleep(30*1000);
    std::cout<< "0x94"<<std::endl;
    }
    else if(src[3] == 0x95){ //PWM2起作用
    static uint8_t pwm_1_0[8] = {0x01,0x06,0x01,0x94,0x00,0x00,0xc9,0xda};
    myserial.writeBuffer( pwm_1_0, 8);
    usleep(30*1000);
    //设置PWM2占空比 
    myserial.writeBuffer( src, 8);
    usleep(30*1000);
     std::cout<< "0x95"<<std::endl;
    }

}