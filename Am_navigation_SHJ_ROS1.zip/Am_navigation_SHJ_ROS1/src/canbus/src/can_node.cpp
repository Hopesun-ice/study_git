#include "ros/ros.h"
#include "canbus/can.h"
#include<vehicle_chassis/lat_1204.h>
#include<vehicle_chassis/lon_1204.h>
#include<vehicle_chassis/tool_1204.h>
#include  <common/common.h>

Can_Bus  test;
//横向
void lat_control_callback( const vehicle_chassis::lat_1204  & lat_cmd){
    static  unsigned char  pwm_1 [] = {0x21,0x06,0x23,0x51,0x00,0x00,0xAA,0xAA};
    static  unsigned char  pwm_2 [] = {0x21,0x06,0x23,0x52,0x00,0x00,0xAA,0xAA};
    for(int i = 0;i<sizeof(test.CAN0_send_data);i++){
        test.CAN0_send_data[i] = lat_cmd.lat_cmd[i];
    }
    if( test.CAN0_send_data[3] == 0x51 ){
        test.Can_Write(0x200,8,pwm_2,false,test.s_can0);//false 代表标准帧
        usleep(10*1000);

    }
    else if(test.CAN0_send_data[3] == 0x52){
        test.Can_Write(0x200,8,pwm_1,false,test.s_can0);//false 代表标准帧
        usleep(10*1000);
    }
    test.Can_Write(0x200,8,test.CAN0_send_data,false,test.s_can0);//false 代表标准帧
    usleep(10*1000);
    
}
//纵向
void lon_control_callback( const vehicle_chassis::lon_1204  & lon_cmd){
    static  unsigned char  parameter_1 [] = {0x00,0x00,0x00,0x00,0x00,0x00,0x50,0x00}; //收获机前进后退速度百分比
    static  unsigned char  parameter_2 [] = {0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00}; //收获机其他参数
    static  unsigned char  parameter_3 [] = {0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00}; //发动机转速
    parameter_1[2] = lon_cmd.lon_cmd[0];  parameter_1[3] = lon_cmd.lon_cmd[1]; //前进后退速度百分比
    parameter_1[6] = lon_cmd.lon_cmd[2];

    parameter_2[0] = lon_cmd.lon_cmd[3] | lon_cmd.lon_cmd[4]| lon_cmd.lon_cmd[5] ;  
    parameter_2[1] = lon_cmd.lon_cmd[6] | lon_cmd.lon_cmd[7] | lon_cmd.lon_cmd[9];
    parameter_2[2] = lon_cmd.lon_cmd[8]  ;
    parameter_2[3] = lon_cmd.lon_cmd[10];
    parameter_3[1] =  lon_cmd.lon_cmd[11]; parameter_3[2] =  lon_cmd.lon_cmd[12];
   test.Can_Write(0x18FF02F2,8,parameter_2,true,test.s_can1);
   usleep(5*1000);
   test.Can_Write(0x18FF01F2,8,parameter_1,true,test.s_can1);
   usleep(5*1000);

   test.Can_Write(0x0c000003,8,parameter_3,true,test.s_can1);
   usleep(5*1000);
   Debug_Info("lon_control_callback_cansend");
}
//机具
void tool_control_callback( const vehicle_chassis::tool_1204  & tool_cmd){
    for(int i = 0;i<sizeof(test.CAN1_send_data);i++){
        test.CAN1_send_data[i] = tool_cmd.tool_cmd[i];
        std::cout<< "   "<< (int) test.CAN1_send_data[i] ;
    }
    std::cout<<std::endl;   std::cout<<std::endl;
   test.Can_Write(0x18FF9dF1,8,test.CAN1_send_data,true,test.s_can1);
   Debug_Info("toos_cansend");
}
int main(int argc, char** argv)
{
    Debug_Info("can_node_start");
    ros::init(argc,argv,"Can_Node" );
    ros::NodeHandle n;
    test.Can_Init_can0();
    test.Can_Init_can1();
    // ros::Subscriber sub_lat_control = n.subscribe("lat_control_cmd", 1,&lat_control_callback);
    ros::Subscriber sub_lon_control = n.subscribe("lon_control_cmd", 1,&lon_control_callback);
    ros::Subscriber sub_tool_control = n.subscribe("tool_control_cmd", 1,&tool_control_callback);
    ros::Publisher pub_grain_full = n.advertise<std_msgs::UInt8>("topic_grain_full", 1);
    ros::Rate r(200);
    while(ros::ok()){
        pub_grain_full.publish(test.grain_full_msg);
        r.sleep();
        ros::spinOnce();
    }
    close(test.s_can0);
    close(test.s_can1);
    return 0;
}