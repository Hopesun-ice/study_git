﻿#ifndef  __485_MODBUS__H
#define __485_MODBUS__H
#include <iostream>
bool fun_init_com();
void  modbus_wirte(uint8_t *src);
uint16_t  CRC16_2(unsigned char *buf, int len);
void pwm(uint8_t *src);
void pwm_init();
#endif 