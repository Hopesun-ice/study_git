#ifndef CAN_H
#define CAN_H
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <net/if.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <linux/can.h>
#include <linux/can/raw.h>
#include <iostream>
#include <string>
#include <fcntl.h>
#include "std_msgs/UInt8.h"
class Can_Bus
{
public:
    Can_Bus(/* args */){};
    Can_Bus(std::string);
    void Can_Init_can0();
    void Can_Init_can1();
    bool Can_Write(int Id,int Can_Dlc,unsigned char* data,bool EX,int  s_can);
    void  Can_Read(unsigned char *,uint64_t *);
    
    ~Can_Bus();
public:
    std::string  sel_can;
    int s_can0,s_can1;
    struct can_frame frame[2]= {{0}};
    struct can_frame frame_can1[2]= {{0}};
    unsigned char CAN0_send_data[8];
    unsigned char CAN1_send_data[8];
    std_msgs::UInt8  grain_full_msg;
    
};



#endif