#include "vehicle_chassis/front_angle.h"

using namespace std;

static  float const    left_delat  = 29.98/180*3.14,right_delat =-33.36/180*3.14;    //33.54   33.69
double   get_front_angle()
{
    static  float const    mid_v =1.92,left_v = 0.65,right_v = 3.2;

    double    delta_v,delta;
    uint8_t data_buf [9];
    // cout<< "data_v_";
    modbus_read_register_3054(1,data_buf);
    
    delta_v = (float(data_buf[3]*256 + data_buf[4]))/65536.0* 5 ;
    cout<< "data_v_orign:  "<< delta_v;
    if(delta_v >= mid_v){
        delta =  ( delta_v - mid_v )/(left_v - mid_v ) * left_delat;
    }
    else {
        delta =  (delta_v - mid_v )/(right_v - mid_v ) * right_delat;
    }
    std::cout<< "       delta: "<<delta<<  "    "<<delta*57.3<<std::endl<<std::endl;
    memset(data_buf,'\0',sizeof(data_buf));
    return delta;
}

double  filter_get_front_angle(){
    //    cout<< "11111111111111111111:  ";
    double  prv_angle = process_data( get_front_angle(), left_delat, right_delat, 0.1);
    return slide_mean_filter(prv_angle, 5);
}

double  test(){
    cout<< "11111111111111111111:  "<<std::endl;
}