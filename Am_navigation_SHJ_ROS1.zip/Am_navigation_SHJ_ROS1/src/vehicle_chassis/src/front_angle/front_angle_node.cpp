#include <vehicle_chassis/modbus.h>
#include <vehicle_chassis/front_angle.h>
#include "std_msgs/Float32.h"
int main(int argc, char *argv[])
{ 
	ros::init(argc,argv,"delta_node");
	ros::NodeHandle n;
    ros::Rate r(50);
    std_msgs::Float32   delta;
    ros::Publisher pub_delat = n.advertise<std_msgs::Float32>("delta",1);
    fun_init_com();
    // Debug_Info(delta.data );
    while(1){
      // test();
      // // std::cout<< "2222222222222222:  "<<std::endl;
        // delta.data = get_front_angle();
        // Debug_Info(delta.data );
        delta.data = filter_get_front_angle();
        pub_delat.publish(delta);
        r.sleep();
    }
}