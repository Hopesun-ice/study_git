#include "vehicle_chassis/modbus.h"
#include <iostream>
#include <cmath>
#include "std_msgs/Float32.h"
#include "location/serial.h"
#include "common/common.h"
using namespace std;
const char *dev  = "/dev/ttyUART_485_422_A";
serialPort myserial;

bool fun_init_com(){
    int i,nread,nwrite;
    int LenBuffer;
    myserial.OpenPort(dev);
    myserial.setup(115200,0,8,1,'N'); 
}
int modbus_read_registers(int addr,int nb,uint8_t *src){
    uint8_t cmd_read_registers[8]={0x01,0x04};
    uint8_t *data_buf = new uint8_t[nb*2+5];
    cmd_read_registers[2] = 0x01;cmd_read_registers[3] = 0x00;
    cmd_read_registers[4] =0x00;cmd_read_registers[5] = 0x01;
    CRC16_2(cmd_read_registers,6);
    myserial.writeBuffer( cmd_read_registers, 8);
    usleep(20*1000);
    int n = myserial.readBuffer( src, 7);
    delete [] data_buf;
}
int modbus_read_register_3054(int  addr,uint8_t *src){
//01 03 00 05 00 02 D4 0A
   static  uint8_t cmd_read_registers[8]={0x01,0x04,0x01,0x00,0x00,0x02,0x70,0x37};
   myserial.writeBuffer( cmd_read_registers, 8);
    usleep(10*1000);
    int n = myserial.readBuffer( src, 9);
      
}