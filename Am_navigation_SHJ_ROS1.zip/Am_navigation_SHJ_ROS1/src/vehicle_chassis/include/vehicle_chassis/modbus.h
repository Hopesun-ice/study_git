#ifndef  __MODBUS__H
#define __MODBUS__H
#include <iostream>

bool serial_init();
int modbus_read_register(int addr,uint8_t *src);
int modbus_read_register_3054(int  addr,uint8_t *src);
bool fun_init_com();
#endif 

