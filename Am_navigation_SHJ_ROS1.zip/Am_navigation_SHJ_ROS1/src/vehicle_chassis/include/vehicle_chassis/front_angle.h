#ifndef __FRONT_ANGLE_H__
#define __FRONT_ANGLE_H__
#include <iostream>
#include<string.h>
#include "vehicle_chassis/modbus.h"
#include "common/common.h"

double get_front_angle();

double  filter_get_front_angle();
double  test();

#endif