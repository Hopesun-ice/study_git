#!/bin/bash
# 将参数值设置为ROS参数
rosparam set my_parameter  stop
