#!/bin/bash

# 传递的参数
param="$1"
# 使用if语句进行比较
if [ "$param" = "xieliangtong_0" ]; then
    echo "卸粮筒_停止"
    rosparam set xieliangtong  0
elif [ "$param" = "xieliangtong_1" ]; then
    echo "卸粮筒_外摆"
    rosparam set xieliangtong  1
elif [ "$param" = "xieliangtong_2" ]; then
    echo "卸粮筒_内合"
    rosparam set xieliangtong  2
elif [ "$param" = "xielianglihe_0" ]; then
    echo "卸粮离合松开"
    rosparam set xielianglihe  0
elif [ "$param" = "xielianglihe_1" ]; then
    echo "卸粮离合结合"
    rosparam set xielianglihe  1
else
    echo "参数错误"
fi

# 
